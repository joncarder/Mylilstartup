import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { MapPin, Tag, Heart } from 'lucide-react-native';
import { colors } from '@/constants/colors';

export interface GlobalSale {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  city: string;
  product: string;
  amount: number;
  date: string;
  highFives: number;
  hasGivenHighFive: boolean;
}

interface GlobalSaleItemProps {
  sale: GlobalSale;
  onHighFive: (saleId: string, isRemoving?: boolean) => void;
}

export default function GlobalSaleItem({ sale, onHighFive }: GlobalSaleItemProps) {
  // Format date for display
  const formatSaleDate = (dateString: string) => {
    const saleDate = new Date(dateString);
    const now = new Date();
    
    // Calculate time difference in milliseconds
    const diffMs = now.getTime() - saleDate.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    // Format based on time difference
    if (diffMins < 1) {
      return 'Just now';
    } else if (diffMins < 60) {
      return `${diffMins}m ago`;
    } else if (diffHours < 24) {
      return `${diffHours}h ago`;
    } else if (diffDays < 7) {
      return `${diffDays}d ago`;
    } else {
      // For older dates, show the month and day
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const month = monthNames[saleDate.getMonth()];
      const day = saleDate.getDate();
      return `${month} ${day}`;
    }
  };

  const handleHeartPress = () => {
    onHighFive(sale.id, sale.hasGivenHighFive);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.userInfo}>
          <Image 
            source={{ uri: sale.userAvatar }} 
            style={styles.avatar}
            defaultSource={require('@/assets/images/icon.png')}
          />
          <View style={styles.userTextInfo}>
            <Text style={styles.userName}>{sale.userName}</Text>
            <View style={styles.cityContainer}>
              <MapPin size={12} color={colors.textLight} />
              <Text style={styles.cityText}>{sale.city}</Text>
            </View>
          </View>
        </View>
        
        <TouchableOpacity 
          style={styles.heartContainer}
          onPress={handleHeartPress}
        >
          <Heart 
            size={22} 
            color={sale.hasGivenHighFive ? colors.secondary : colors.textLight} 
            fill={sale.hasGivenHighFive ? colors.secondary : 'transparent'}
          />
          <Text style={[
            styles.heartCount,
            sale.hasGivenHighFive && styles.heartCountActive
          ]}>
            {sale.highFives}
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.saleDetails}>
        <View style={styles.productContainer}>
          <Tag size={16} color={colors.primary} />
          <Text style={styles.productText}>{sale.product}</Text>
          <Text style={styles.timeAgo}>{formatSaleDate(sale.date)}</Text>
        </View>
        
        <View style={styles.amountContainer}>
          <Text style={styles.amountText}>${sale.amount.toFixed(2)}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  userTextInfo: {
    flex: 1,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.backgroundDark + '20',
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 2,
  },
  cityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  cityText: {
    fontSize: 13,
    color: colors.textLight,
  },
  heartContainer: {
    alignItems: 'center',
  },
  heartCount: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 2,
  },
  heartCountActive: {
    color: colors.secondary,
    fontWeight: '500',
  },
  timeAgo: {
    fontSize: 13,
    color: colors.textLight,
    marginLeft: 8,
  },
  saleDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  productContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  productText: {
    fontSize: 15,
    fontWeight: '500',
    color: colors.primary,
  },
  amountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  amountText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.secondary,
  },
});