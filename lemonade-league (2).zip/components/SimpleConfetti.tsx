import React, { useEffect, useState, useRef } from 'react';
import { View, StyleSheet } from 'react-native';
import { colors } from '@/constants/colors';

interface SimpleConfettiProps {
  count?: number;
  duration?: number;
}

// Confetti colors
const confettiColors = [
  colors.primary,
  colors.secondary,
  colors.accent,
  '#FFFFFF',
  '#FFD700', // Gold
];

export default function SimpleConfetti({ count = 50, duration = 3000 }: SimpleConfettiProps) {
  const [pieces, setPieces] = useState<Array<{
    id: number;
    left: string;
    top: string;
    color: string;
    size: number;
    isCircle: boolean;
  }>>([]);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isMounted = useRef(true);

  useEffect(() => {
    // Generate confetti pieces - limit count for performance
    const actualCount = Math.min(count, 30); // Reduced for better performance
    
    const newPieces = Array(actualCount).fill(0).map((_, i) => {
      return {
        id: i,
        left: `${Math.random() * 100}%`,
        top: `${Math.random() * 100}%`,
        color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
        size: Math.random() * 8 + 4, // Smaller pieces for better performance
        isCircle: Math.random() > 0.5,
      };
    });
    
    if (isMounted.current) {
      setPieces(newPieces);
    }
    
    // Clean up after duration
    timerRef.current = setTimeout(() => {
      if (isMounted.current) {
        setPieces([]);
      }
    }, duration);
    
    return () => {
      isMounted.current = false;
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [count, duration]);

  return (
    <View style={styles.container} pointerEvents="none">
      {pieces.map((piece) => (
        <View
          key={piece.id}
          style={[
            styles.piece,
            {
              left: piece.left,
              top: piece.top,
              width: piece.size,
              height: piece.size,
              backgroundColor: piece.color,
              borderRadius: piece.isCircle ? piece.size / 2 : 0,
            }
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1000,
    pointerEvents: 'none',
  },
  piece: {
    position: 'absolute',
    opacity: 0.8,
  },
});