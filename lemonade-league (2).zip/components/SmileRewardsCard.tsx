import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, ScrollView, Image, ActivityIndicator } from 'react-native';
import { Award, Gift, Star, X, ChevronRight, AlertCircle, Check } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { useSmileRewardsStore } from '@/store/smile-rewards-store';
import { LinearGradient } from 'expo-linear-gradient';

interface SmileRewardsCardProps {
  onPress?: () => void;
  compact?: boolean;
}

export default function SmileRewardsCard({ onPress, compact = false }: SmileRewardsCardProps) {
  const { 
    pointsBalance, 
    vipTier, 
    availableRewards, 
    isLoading, 
    error,
    fetchAvailableRewards,
    redeemReward,
    clearError
  } = useSmileRewardsStore();
  
  const [showRewardsModal, setShowRewardsModal] = useState(false);
  const [selectedReward, setSelectedReward] = useState<string | null>(null);
  const [isRedeeming, setIsRedeeming] = useState(false);
  const [redeemSuccess, setRedeemSuccess] = useState(false);
  const [redeemError, setRedeemError] = useState<string | null>(null);
  
  const handleOpenRewards = async () => {
    // Fetch latest rewards before opening modal
    await fetchAvailableRewards();
    setShowRewardsModal(true);
  };
  
  const handleRedeemReward = async (rewardId: string) => {
    setIsRedeeming(true);
    setSelectedReward(rewardId);
    setRedeemError(null);
    
    try {
      await redeemReward(rewardId);
      setRedeemSuccess(true);
      
      // Reset after 3 seconds
      setTimeout(() => {
        setRedeemSuccess(false);
        setSelectedReward(null);
      }, 3000);
    } catch (error: any) {
      setRedeemError(error.message || 'Failed to redeem reward');
    } finally {
      setIsRedeeming(false);
    }
  };
  
  if (compact) {
    return (
      <TouchableOpacity 
        style={styles.compactContainer}
        onPress={onPress || handleOpenRewards}
      >
        <View style={styles.compactContent}>
          <View style={styles.compactIconContainer}>
            <Star size={18} color={colors.primary} />
          </View>
          <View style={styles.compactTextContainer}>
            <Text style={styles.compactTitle}>Smile Rewards</Text>
            <Text style={styles.compactPoints}>{pointsBalance} points</Text>
          </View>
          <ChevronRight size={18} color={colors.textLight} />
        </View>
      </TouchableOpacity>
    );
  }
  
  return (
    <>
      <TouchableOpacity 
        style={styles.container}
        onPress={onPress || handleOpenRewards}
      >
        <LinearGradient
          colors={[colors.primary, colors.secondary]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradientBackground}
        >
          <View style={styles.content}>
            <View style={styles.header}>
              <View style={styles.logoContainer}>
                <Image 
                  source={{ uri: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=120&h=120&q=80' }}
                  style={styles.logo}
                />
              </View>
              <View style={styles.titleContainer}>
                <Text style={styles.title}>Smile Rewards</Text>
                {vipTier && (
                  <View style={styles.tierBadge}>
                    <Award size={12} color="#FFD700" />
                    <Text style={styles.tierText}>{vipTier}</Text>
                  </View>
                )}
              </View>
            </View>
            
            <View style={styles.pointsContainer}>
              <Text style={styles.pointsLabel}>Your Points</Text>
              <Text style={styles.pointsValue}>{pointsBalance}</Text>
            </View>
            
            <View style={styles.rewardsPreview}>
              <Text style={styles.rewardsLabel}>Available Rewards</Text>
              {isLoading ? (
                <ActivityIndicator color={colors.background} size="small" />
              ) : error ? (
                <Text style={styles.errorText}>{error}</Text>
              ) : availableRewards.length > 0 ? (
                <View style={styles.rewardsList}>
                  {availableRewards.slice(0, 2).map(reward => (
                    <View key={reward.id} style={styles.rewardItem}>
                      <Gift size={14} color={colors.background} />
                      <Text style={styles.rewardName} numberOfLines={1}>
                        {reward.name}
                      </Text>
                    </View>
                  ))}
                  {availableRewards.length > 2 && (
                    <Text style={styles.moreRewards}>+{availableRewards.length - 2} more</Text>
                  )}
                </View>
              ) : (
                <Text style={styles.noRewardsText}>No rewards available</Text>
              )}
            </View>
            
            <TouchableOpacity 
              style={styles.viewButton}
              onPress={handleOpenRewards}
            >
              <Text style={styles.viewButtonText}>View Rewards</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </TouchableOpacity>
      
      {/* Rewards Modal */}
      <Modal
        visible={showRewardsModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowRewardsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Smile Rewards</Text>
              <TouchableOpacity 
                style={styles.closeButton}
                onPress={() => {
                  setShowRewardsModal(false);
                  clearError();
                }}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalPointsContainer}>
              <Text style={styles.modalPointsLabel}>Your Points</Text>
              <Text style={styles.modalPointsValue}>{pointsBalance}</Text>
              {vipTier && (
                <View style={styles.modalTierBadge}>
                  <Award size={14} color="#FFD700" />
                  <Text style={styles.modalTierText}>{vipTier} Member</Text>
                </View>
              )}
            </View>
            
            <ScrollView style={styles.rewardsScrollView}>
              <Text style={styles.rewardsListTitle}>Available Rewards</Text>
              
              {isLoading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator color={colors.primary} size="large" />
                  <Text style={styles.loadingText}>Loading rewards...</Text>
                </View>
              ) : error ? (
                <View style={styles.errorContainer}>
                  <AlertCircle size={40} color={colors.error} />
                  <Text style={styles.errorMessage}>{error}</Text>
                  <TouchableOpacity 
                    style={styles.retryButton}
                    onPress={fetchAvailableRewards}
                  >
                    <Text style={styles.retryButtonText}>Retry</Text>
                  </TouchableOpacity>
                </View>
              ) : availableRewards.length > 0 ? (
                <View style={styles.modalRewardsList}>
                  {availableRewards.map(reward => (
                    <View key={reward.id} style={styles.modalRewardItem}>
                      <View style={styles.rewardDetails}>
                        <Text style={styles.modalRewardName}>{reward.name}</Text>
                        <Text style={styles.modalRewardDescription}>{reward.description}</Text>
                        <View style={styles.pointsCostContainer}>
                          <Star size={14} color={colors.primary} />
                          <Text style={styles.pointsCost}>{reward.pointsCost} points</Text>
                        </View>
                      </View>
                      
                      {selectedReward === reward.id && isRedeeming ? (
                        <ActivityIndicator color={colors.primary} size="small" />
                      ) : selectedReward === reward.id && redeemSuccess ? (
                        <View style={styles.successIcon}>
                          <Check size={20} color={colors.background} />
                        </View>
                      ) : (
                        <TouchableOpacity 
                          style={[
                            styles.redeemButton,
                            pointsBalance < reward.pointsCost && styles.redeemButtonDisabled
                          ]}
                          onPress={() => handleRedeemReward(reward.id)}
                          disabled={pointsBalance < reward.pointsCost || isRedeeming}
                        >
                          <Text style={[
                            styles.redeemButtonText,
                            pointsBalance < reward.pointsCost && styles.redeemButtonTextDisabled
                          ]}>
                            {pointsBalance < reward.pointsCost ? 'Not Enough Points' : 'Redeem'}
                          </Text>
                        </TouchableOpacity>
                      )}
                      
                      {selectedReward === reward.id && redeemError && (
                        <Text style={styles.redeemErrorText}>{redeemError}</Text>
                      )}
                    </View>
                  ))}
                </View>
              ) : (
                <View style={styles.noRewardsContainer}>
                  <Gift size={50} color={colors.border} />
                  <Text style={styles.noRewardsTitle}>No Rewards Available</Text>
                  <Text style={styles.noRewardsSubtext}>
                    Keep earning points to unlock exciting rewards!
                  </Text>
                </View>
              )}
            </ScrollView>
            
            <TouchableOpacity 
              style={styles.closeModalButton}
              onPress={() => setShowRewardsModal(false)}
            >
              <Text style={styles.closeModalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    overflow: 'hidden',
    marginHorizontal: 16,
    marginVertical: 8,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  gradientBackground: {
    borderRadius: 16,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  logoContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  logo: {
    width: 30,
    height: 30,
    borderRadius: 15,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.background,
  },
  tierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    alignSelf: 'flex-start',
    marginTop: 4,
    gap: 4,
  },
  tierText: {
    fontSize: 12,
    color: colors.background,
    fontWeight: '500',
  },
  pointsContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  pointsLabel: {
    fontSize: 14,
    color: colors.background,
    opacity: 0.8,
  },
  pointsValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: colors.background,
  },
  rewardsPreview: {
    marginBottom: 16,
  },
  rewardsLabel: {
    fontSize: 14,
    color: colors.background,
    opacity: 0.8,
    marginBottom: 8,
  },
  rewardsList: {
    gap: 8,
  },
  rewardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    gap: 8,
  },
  rewardName: {
    fontSize: 12,
    color: colors.background,
    flex: 1,
  },
  moreRewards: {
    fontSize: 12,
    color: colors.background,
    opacity: 0.8,
    textAlign: 'center',
    marginTop: 4,
  },
  noRewardsText: {
    fontSize: 12,
    color: colors.background,
    opacity: 0.8,
    fontStyle: 'italic',
  },
  errorText: {
    fontSize: 12,
    color: '#FFD700',
    fontStyle: 'italic',
  },
  viewButton: {
    backgroundColor: colors.background,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
  },
  viewButtonText: {
    color: colors.primary,
    fontWeight: '600',
    fontSize: 14,
  },
  // Compact styles
  compactContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginVertical: 8,
  },
  compactContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  compactIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  compactTextContainer: {
    flex: 1,
  },
  compactTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  compactPoints: {
    fontSize: 14,
    color: colors.primary,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '90%',
    maxHeight: '80%',
    backgroundColor: colors.background,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeButton: {
    padding: 5,
  },
  modalPointsContainer: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: colors.primary + '10',
  },
  modalPointsLabel: {
    fontSize: 14,
    color: colors.textLight,
  },
  modalPointsValue: {
    fontSize: 36,
    fontWeight: 'bold',
    color: colors.primary,
  },
  modalTierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 8,
    gap: 6,
  },
  modalTierText: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: '500',
  },
  rewardsScrollView: {
    maxHeight: 400,
  },
  rewardsListTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    padding: 20,
    paddingBottom: 10,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    color: colors.textLight,
    fontSize: 16,
  },
  errorContainer: {
    padding: 40,
    alignItems: 'center',
  },
  errorMessage: {
    marginTop: 16,
    color: colors.error,
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: colors.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    color: colors.background,
    fontWeight: '600',
  },
  modalRewardsList: {
    padding: 20,
    paddingTop: 0,
  },
  modalRewardItem: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  rewardDetails: {
    marginBottom: 12,
  },
  modalRewardName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  modalRewardDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 8,
  },
  pointsCostContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  pointsCost: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  redeemButton: {
    backgroundColor: colors.accent,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  redeemButtonDisabled: {
    backgroundColor: colors.border,
  },
  redeemButtonText: {
    color: colors.background,
    fontWeight: '600',
  },
  redeemButtonTextDisabled: {
    color: colors.textLight,
  },
  successIcon: {
    backgroundColor: colors.primary,
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  redeemErrorText: {
    color: colors.error,
    fontSize: 12,
    marginTop: 8,
    textAlign: 'center',
  },
  noRewardsContainer: {
    padding: 40,
    alignItems: 'center',
  },
  noRewardsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  noRewardsSubtext: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
  },
  closeModalButton: {
    backgroundColor: colors.accent,
    padding: 16,
    alignItems: 'center',
  },
  closeModalButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: 'bold',
  },
});