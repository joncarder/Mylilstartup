import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Calendar, Award, X, Check, Rocket } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { Challenge } from '@/constants/challenges';

interface ChallengeCardProps {
  challenge: Challenge;
  onAccept?: () => void;
  onDecline?: () => void;
  onViewDetails?: () => void;
}

export default function ChallengeCard({ 
  challenge, 
  onAccept, 
  onDecline, 
  onViewDetails 
}: ChallengeCardProps) {
  const isChallenger = challenge.challengerName === 'You';
  const opponent = isChallenger ? challenge.opponentName : challenge.challengerName;
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    // Format to show day of week and month/day without year
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric'
    });
  };
  
  const renderStatusBadge = () => {
    switch (challenge.status) {
      case 'pending':
        return (
          <View style={[styles.badge, styles.pendingBadge]}>
            <Text style={styles.badgeText}>Pending</Text>
          </View>
        );
      case 'active':
        return (
          <View style={[styles.badge, styles.activeBadge]}>
            <Text style={styles.badgeText}>Active</Text>
          </View>
        );
      case 'completed':
        const isWinner = challenge.winnerId === 'user_1';
        return (
          <View style={[styles.badge, isWinner ? styles.winBadge : styles.loseBadge]}>
            <Text style={styles.badgeText}>{isWinner ? 'Won' : 'Lost'}</Text>
          </View>
        );
      case 'cancelled':
        return (
          <View style={[styles.badge, styles.cancelledBadge]}>
            <Text style={styles.badgeText}>Cancelled</Text>
          </View>
        );
      default:
        return null;
    }
  };
  
  const renderActions = () => {
    if (challenge.status === 'pending' && !isChallenger) {
      return (
        <View style={styles.actions}>
          <TouchableOpacity 
            style={[styles.actionButton, styles.declineButton]}
            onPress={onDecline}
          >
            <X size={16} color={colors.error} />
            <Text style={styles.declineButtonText}>Decline</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionButton, styles.acceptButton]}
            onPress={onAccept}
          >
            <Check size={16} color={colors.primary} />
            <Text style={styles.acceptButtonText}>Accept</Text>
          </TouchableOpacity>
        </View>
      );
    }
    
    if (challenge.status === 'completed') {
      return (
        <View style={styles.resultContainer}>
          <View style={styles.resultItem}>
            <Text style={styles.resultLabel}>{challenge.challengerName}</Text>
            <Text style={styles.resultValue}>${challenge.challengerSales?.toFixed(2)}</Text>
          </View>
          <View style={styles.resultItem}>
            <Text style={styles.resultLabel}>{challenge.opponentName}</Text>
            <Text style={styles.resultValue}>${challenge.opponentSales?.toFixed(2)}</Text>
          </View>
        </View>
      );
    }
    
    return null;
  };
  
  return (
    <TouchableOpacity 
      style={styles.container}
      onPress={onViewDetails}
      disabled={!onViewDetails}
    >
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Award size={18} color={colors.primary} />
          <Text style={styles.title}>
            {isChallenger ? `You challenged ${opponent}` : `${opponent} challenged you`}
          </Text>
        </View>
        {renderStatusBadge()}
      </View>
      
      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Calendar size={16} color={colors.textLight} />
          <Text style={styles.detailText}>
            {formatDate(challenge.startDate)}
          </Text>
        </View>
        
        <View style={styles.wagerContainer}>
          <Text style={styles.wagerLabel}>Wager:</Text>
          <View style={styles.wagerAmount}>
            <Rocket size={14} color={colors.primary} />
            <Text style={styles.wagerText}>{challenge.wagerAmount} rockets</Text>
          </View>
        </View>
      </View>
      
      {renderActions()}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  pendingBadge: {
    backgroundColor: colors.secondary + '20',
  },
  activeBadge: {
    backgroundColor: colors.primary + '20',
  },
  winBadge: {
    backgroundColor: colors.success + '20',
  },
  loseBadge: {
    backgroundColor: colors.error + '20',
  },
  cancelledBadge: {
    backgroundColor: colors.textLight + '20',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '500',
    color: colors.text,
  },
  details: {
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    color: colors.textLight,
  },
  wagerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  wagerLabel: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
  },
  wagerAmount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  wagerText: {
    fontSize: 14,
    color: colors.accent,
    fontWeight: '600',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  acceptButton: {
    backgroundColor: colors.primary + '20',
  },
  declineButton: {
    backgroundColor: colors.error + '20',
  },
  acceptButtonText: {
    color: colors.secondary,
    fontWeight: '500',
  },
  declineButtonText: {
    color: colors.error,
    fontWeight: '500',
  },
  resultContainer: {
    marginTop: 8,
    backgroundColor: colors.background,
    borderRadius: 8,
    padding: 8,
  },
  resultItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  resultLabel: {
    fontSize: 14,
    color: colors.text,
  },
  resultValue: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
});