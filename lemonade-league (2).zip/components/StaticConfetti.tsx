import React, { useEffect, useState, useRef } from 'react';
import { View, StyleSheet } from 'react-native';
import { colors } from '@/constants/colors';

interface StaticConfettiProps {
  count?: number;
}

export default function StaticConfetti({ count = 100 }: StaticConfettiProps) {
  const [confettiPieces, setConfettiPieces] = useState<Array<{
    id: number;
    top: number;
    left: string;
    size: number;
    color: string;
    isCircle: boolean;
    rotation: number;
  }>>([]);
  
  const isMounted = useRef(true);

  useEffect(() => {
    // Set up cleanup
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    const pieces = [];
    const confettiColors = [
      colors.primary,
      colors.secondary,
      colors.accent,
      '#FFFFFF',
      '#FFD700', // Gold
    ];

    // Limit count to prevent performance issues
    const actualCount = Math.min(count, 100);

    for (let i = 0; i < actualCount; i++) {
      pieces.push({
        id: i,
        top: Math.random() * 500 - 100, // Some above, some below
        left: `${Math.random() * 100}%`,
        size: Math.random() * 10 + 5,
        color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
        isCircle: Math.random() > 0.5,
        rotation: Math.random() * 360,
      });
    }

    if (isMounted.current) {
      setConfettiPieces(pieces);
    }
  }, [count]);

  return (
    <View style={styles.container} pointerEvents="none">
      {confettiPieces.map(piece => (
        <View
          key={piece.id}
          style={[
            styles.piece,
            {
              top: piece.top,
              left: piece.left,
              width: piece.size,
              height: piece.size,
              backgroundColor: piece.color,
              borderRadius: piece.isCircle ? piece.size / 2 : 0,
              transform: [{ rotate: `${piece.rotation}deg` }],
            },
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
    zIndex: 1,
  },
  piece: {
    position: 'absolute',
    opacity: 0.7,
  },
});