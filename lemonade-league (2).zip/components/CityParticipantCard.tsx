import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { Rocket } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { CityParticipant } from '@/constants/city-challenges';

interface CityParticipantCardProps {
  participant: CityParticipant;
  rank: number;
  isCurrentUser?: boolean;
}

export default function CityParticipantCard({ 
  participant, 
  rank, 
  isCurrentUser = false 
}: CityParticipantCardProps) {
  return (
    <View style={[
      styles.container,
      isCurrentUser && styles.currentUserContainer
    ]}>
      <View style={styles.rankContainer}>
        <Text style={styles.rankText}>{rank}</Text>
      </View>
      
      <Image 
        source={{ uri: participant.avatar }}
        style={styles.avatar}
        defaultSource={require('@/assets/images/icon.png')}
      />
      
      <View style={styles.infoContainer}>
        <Text style={[
          styles.name,
          isCurrentUser && styles.currentUserText
        ]}>
          {participant.name}
        </Text>
        
        <View style={styles.rocketsContainer}>
          <Rocket size={14} color={colors.background} />
          <Text style={styles.rocketsText}>{participant.rockets}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 10,
    marginBottom: 8,
  },
  currentUserContainer: {
    backgroundColor: colors.primary + '15',
    borderWidth: 1,
    borderColor: colors.primary,
  },
  rankContainer: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  rankText: {
    color: colors.background,
    fontWeight: 'bold',
    fontSize: 14,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 12,
  },
  infoContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  name: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 4,
  },
  currentUserText: {
    fontWeight: 'bold',
  },
  rocketsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.secondary,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    alignSelf: 'flex-start',
    gap: 4,
  },
  rocketsText: {
    color: colors.background,
    fontSize: 12,
    fontWeight: 'bold',
  },
});