import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, Modal } from 'react-native';
import { MapPin, Clock, Trophy, Rocket, Users, X, Info } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { CityChallenge, CityParticipant } from '@/constants/city-challenges';
import CityParticipantCard from './CityParticipantCard';
import { LinearGradient } from 'expo-linear-gradient';
import { cityRewards } from '@/constants/rewards';

interface CityVsCityProps {
  challenge: CityChallenge;
  timeRemaining: string;
}

export default function CityVsCity({ challenge, timeRemaining }: CityVsCityProps) {
  const { city1, city2 } = challenge;
  const city1Leading = city1.totalRockets > city2.totalRockets;
  const city2Leading = city2.totalRockets > city1.totalRockets;
  
  const [showCity1Modal, setShowCity1Modal] = useState(false);
  const [showCity2Modal, setShowCity2Modal] = useState(false);
  const [showRewardsModal, setShowRewardsModal] = useState(false);
  
  // Calculate the prize for the winning city (2 bonus rockets per rocket earned)
  const estimatedPrize = Math.round(Math.max(city1.totalRockets, city2.totalRockets) * 0.2);
  
  // Limit participants to first 10
  const city1TopParticipants = city1.participants.slice(0, 10);
  const city2TopParticipants = city2.participants.slice(0, 10);
  
  const renderParticipantsModal = (
    city: { name: string, participants: CityParticipant[] },
    visible: boolean,
    onClose: () => void
  ) => (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>{city.name} Contributors</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          
          <Text style={styles.modalSubtitle}>
            All contributors with at least 1 rocket this week
          </Text>
          
          <ScrollView style={styles.modalContent}>
            {city.participants.map((participant, index) => (
              <CityParticipantCard
                key={participant.id}
                participant={participant}
                rank={index + 1}
                isCurrentUser={participant.id === 'user_1'}
              />
            ))}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const renderRewardsModal = () => (
    <Modal
      visible={showRewardsModal}
      transparent={true}
      animationType="slide"
      onRequestClose={() => setShowRewardsModal(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>City Challenge Rewards</Text>
            <TouchableOpacity onPress={() => setShowRewardsModal(false)} style={styles.closeButton}>
              <X size={24} color={colors.text} />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.modalContent}>
            <View style={styles.rewardItem}>
              <View style={styles.rewardBadge}>
                <Trophy size={18} color={colors.background} />
                <Text style={styles.rewardBadgeText}>1st</Text>
              </View>
              <View style={styles.rewardInfo}>
                <Text style={styles.rewardTitle}>First Place City</Text>
                <Text style={styles.rewardDescription}>
                  Each contributor receives {cityRewards.firstPlace} bonus rockets
                </Text>
              </View>
            </View>
            
            <View style={styles.rewardItem}>
              <View style={[styles.rewardBadge, styles.secondPlaceBadge]}>
                <Trophy size={18} color={colors.background} />
                <Text style={styles.rewardBadgeText}>2nd</Text>
              </View>
              <View style={styles.rewardInfo}>
                <Text style={styles.rewardTitle}>Second Place City</Text>
                <Text style={styles.rewardDescription}>
                  Each contributor receives {cityRewards.secondPlace} bonus rockets
                </Text>
              </View>
            </View>
            
            <View style={styles.rewardDivider} />
            
            <View style={styles.rewardItem}>
              <View style={[styles.rewardBadge, styles.topContributorBadge]}>
                <Rocket size={18} color={colors.background} />
              </View>
              <View style={styles.rewardInfo}>
                <Text style={styles.rewardTitle}>Top 3 Contributors</Text>
                <Text style={styles.rewardDescription}>
                  Top 3 contributors in each city receive an additional {cityRewards.topContributor} bonus rockets
                </Text>
              </View>
            </View>
            
            <View style={styles.rewardItem}>
              <View style={[styles.rewardBadge, styles.participantBadge]}>
                <Users size={18} color={colors.background} />
              </View>
              <View style={styles.rewardInfo}>
                <Text style={styles.rewardTitle}>All Contributors</Text>
                <Text style={styles.rewardDescription}>
                  Everyone who contributes at least 1 rocket during the week receives {cityRewards.participant} bonus rockets
                </Text>
              </View>
            </View>
            
            <Text style={styles.rewardNote}>
              Note: Rewards are distributed at the end of the weekly challenge period. The more rockets your city earns, the bigger the bonus!
            </Text>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
  
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Weekly City Battles</Text>
        <View style={styles.countdownContainer}>
          <Clock size={16} color={colors.primary} />
          <Text style={styles.countdownText}>
            Ends in: {timeRemaining}
          </Text>
        </View>
      </View>
      
      <View style={styles.citiesContainer}>
        {/* City 1 */}
        <View style={[
          styles.cityContainer,
          city1Leading && styles.leadingCityContainer
        ]}>
          <View style={styles.cityImageContainer}>
            <Image 
              source={{ uri: city1.image }}
              style={styles.cityImage}
              defaultSource={require('@/assets/images/icon.png')}
            />
            {city1Leading && (
              <View style={styles.leadingBadge}>
                <Trophy size={12} color={colors.background} />
                <Text style={styles.leadingText}>Leading</Text>
              </View>
            )}
          </View>
          <Text style={styles.cityName}>{city1.name}</Text>
          <View style={styles.cityRocketsContainer}>
            <Rocket size={16} color={colors.secondary} />
            <Text style={styles.cityRockets}>{city1.totalRockets}</Text>
          </View>
        </View>
        
        {/* VS */}
        <View style={styles.vsContainer}>
          <Text style={styles.vsText}>VS</Text>
        </View>
        
        {/* City 2 */}
        <View style={[
          styles.cityContainer,
          city2Leading && styles.leadingCityContainer
        ]}>
          <View style={styles.cityImageContainer}>
            <Image 
              source={{ uri: city2.image }}
              style={styles.cityImage}
              defaultSource={require('@/assets/images/icon.png')}
            />
            {city2Leading && (
              <View style={styles.leadingBadge}>
                <Trophy size={12} color={colors.background} />
                <Text style={styles.leadingText}>Leading</Text>
              </View>
            )}
          </View>
          <Text style={styles.cityName}>{city2.name}</Text>
          <View style={styles.cityRocketsContainer}>
            <Rocket size={16} color={colors.secondary} />
            <Text style={styles.cityRockets}>{city2.totalRockets}</Text>
          </View>
        </View>
      </View>
      
      <TouchableOpacity 
        style={styles.prizeContainer}
        onPress={() => setShowRewardsModal(true)}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={[colors.primary, colors.secondary]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.prizeGradient}
        >
          <View style={styles.prizeContent}>
            <Trophy size={20} color={colors.background} />
            <Text style={styles.prizeText}>
              Winning city earns bonus rockets. (i)
            </Text>
          </View>
        </LinearGradient>
      </TouchableOpacity>
      
      <View style={styles.participantsContainer}>
        <View style={styles.cityColumn}>
          <View style={styles.cityHeader}>
            <MapPin size={16} color={colors.primary} />
            <Text style={styles.cityHeaderText}>{city1.name} Top Contributors</Text>
          </View>
          <ScrollView style={styles.participantsList}>
            {city1TopParticipants.map((participant, index) => (
              <CityParticipantCard
                key={participant.id}
                participant={participant}
                rank={index + 1}
                isCurrentUser={participant.id === 'user_1'}
              />
            ))}
            
            {city1.participants.length > 10 && (
              <TouchableOpacity 
                style={styles.seeAllButton}
                onPress={() => setShowCity1Modal(true)}
              >
                <Users size={16} color={colors.background} />
                <Text style={styles.seeAllButtonText}>
                  See All Contributors
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        </View>
        
        <View style={styles.cityColumn}>
          <View style={styles.cityHeader}>
            <MapPin size={16} color={colors.primary} />
            <Text style={styles.cityHeaderText}>{city2.name} Top Contributors</Text>
          </View>
          <ScrollView style={styles.participantsList}>
            {city2TopParticipants.map((participant, index) => (
              <CityParticipantCard
                key={participant.id}
                participant={participant}
                rank={index + 1}
                isCurrentUser={participant.id === 'user_1'}
              />
            ))}
            
            {city2.participants.length > 10 && (
              <TouchableOpacity 
                style={styles.seeAllButton}
                onPress={() => setShowCity2Modal(true)}
              >
                <Users size={16} color={colors.background} />
                <Text style={styles.seeAllButtonText}>
                  See All Contributors
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        </View>
      </View>
      
      {/* City 1 Participants Modal */}
      {renderParticipantsModal(
        city1,
        showCity1Modal,
        () => setShowCity1Modal(false)
      )}
      
      {/* City 2 Participants Modal */}
      {renderParticipantsModal(
        city2,
        showCity2Modal,
        () => setShowCity2Modal(false)
      )}

      {/* Rewards Info Modal */}
      {renderRewardsModal()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 16,
    paddingBottom: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  countdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  countdownText: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: '500',
  },
  citiesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  cityContainer: {
    flex: 2,
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    elevation: 2,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  leadingCityContainer: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  cityImageContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  cityImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  leadingBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  leadingText: {
    color: colors.background,
    fontSize: 10,
    fontWeight: 'bold',
  },
  cityName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  cityRocketsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.secondary + '15',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  cityRockets: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.secondary,
  },
  vsContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vsText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.accent,
  },
  prizeContainer: {
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  prizeGradient: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  prizeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 8,
  },
  prizeText: {
    color: colors.background,
    fontSize: 14,
    fontWeight: '600',
  },
  participantsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    flex: 1,
  },
  cityColumn: {
    flex: 1,
  },
  cityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  cityHeaderText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  participantsList: {
    flex: 1,
  },
  seeAllButton: {
    backgroundColor: colors.secondary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 12,
    marginTop: 8,
    marginBottom: 16,
    gap: 8,
  },
  seeAllButtonText: {
    color: colors.background,
    fontSize: 14,
    fontWeight: '600',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '90%',
    maxHeight: '80%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  modalSubtitle: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 16,
  },
  modalContent: {
    flex: 1,
  },
  closeButton: {
    padding: 5,
  },
  // Reward modal styles
  rewardItem: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-start',
  },
  rewardBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    flexDirection: 'row',
  },
  secondPlaceBadge: {
    backgroundColor: colors.secondary,
  },
  topContributorBadge: {
    backgroundColor: colors.accent,
  },
  participantBadge: {
    backgroundColor: colors.textLight,
  },
  rewardBadgeText: {
    color: colors.background,
    fontWeight: 'bold',
    fontSize: 12,
    marginLeft: 2,
  },
  rewardInfo: {
    flex: 1,
  },
  rewardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  rewardDescription: {
    fontSize: 14,
    color: colors.textLight,
    lineHeight: 20,
  },
  rewardDivider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 16,
  },
  rewardNote: {
    fontSize: 14,
    fontStyle: 'italic',
    color: colors.textLight,
    marginTop: 16,
    lineHeight: 20,
  },
});