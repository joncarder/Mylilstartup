import React, { useEffect, useState, useRef } from 'react';
import { View, StyleSheet, Dimensions, Platform } from 'react-native';
import { colors } from '@/constants/colors';

interface ConfettiPiece {
  id: number;
  left: number;
  top: number;
  color: string;
  size: number;
  shape: 'circle' | 'square' | 'rectangle';
  rotation: number;
  speed: number;
}

interface ConfettiOverlayProps {
  active: boolean;
  count?: number;
}

const { width, height } = Dimensions.get('window');

export default function ConfettiOverlay({ active, count = 100 }: ConfettiOverlayProps) {
  // For web, use a simplified version to avoid stack overflow
  if (Platform.OS === 'web') {
    return <WebConfettiOverlay active={active} count={Math.min(count, 50)} />;
  }
  
  const [confetti, setConfetti] = useState<ConfettiPiece[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isMounted = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMounted.current = false;
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
  }, []);

  // Generate confetti pieces when active changes to true
  useEffect(() => {
    if (active) {
      // Clear any existing timer
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      
      const pieces: ConfettiPiece[] = [];
      const colors = [colors.primary, colors.secondary, colors.accent, '#FFFFFF', '#FFD700'];
      const shapes: ('circle' | 'square' | 'rectangle')[] = ['circle', 'square', 'rectangle'];
      
      // Limit count to prevent performance issues
      const actualCount = Math.min(count, 100);
      
      for (let i = 0; i < actualCount; i++) {
        pieces.push({
          id: i,
          left: Math.random() * width,
          top: -20 - Math.random() * 100, // Start above the screen
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 10 + 5,
          shape: shapes[Math.floor(Math.random() * shapes.length)],
          rotation: Math.random() * 360,
          speed: Math.random() * 3 + 2,
        });
      }
      
      if (isMounted.current) {
        setConfetti(pieces);
      }
      
      // Clear confetti after animation
      timerRef.current = setTimeout(() => {
        if (isMounted.current) {
          setConfetti([]);
        }
      }, 5000);
    } else {
      if (isMounted.current) {
        setConfetti([]);
      }
      
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    }
  }, [active, count, width]);

  if (!active || confetti.length === 0) return null;

  return (
    <View style={styles.container} pointerEvents="none">
      {confetti.map((piece) => (
        <View
          key={piece.id}
          style={[
            styles.piece,
            {
              left: piece.left,
              top: piece.top,
              width: piece.shape === 'rectangle' ? piece.size * 2 : piece.size,
              height: piece.size,
              backgroundColor: piece.color,
              borderRadius: piece.shape === 'circle' ? piece.size / 2 : 0,
              transform: [{ rotate: `${piece.rotation}deg` }],
            },
          ]}
        />
      ))}
    </View>
  );
}

// Simplified version for web to avoid stack overflow
function WebConfettiOverlay({ active, count = 50 }: { active: boolean; count?: number }) {
  const [pieces, setPieces] = useState<Array<{
    id: number;
    left: string;
    top: number;
    color: string;
    size: number;
    isCircle: boolean;
    rotation: number;
  }>>([]);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isMounted = useRef(true);
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMounted.current = false;
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };
  }, []);
  
  // Generate confetti pieces when active changes to true
  useEffect(() => {
    if (active) {
      // Clear any existing timer
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      
      const confettiColors = [
        colors.primary,
        colors.secondary,
        colors.accent,
        '#FFFFFF',
        '#FFD700',
      ];
      
      // Generate pieces
      const newPieces = Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: `${Math.random() * 100}%`,
        top: Math.random() * -100 - 20, // Start above the screen
        color: confettiColors[Math.floor(Math.random() * confettiColors.length)],
        size: Math.random() * 10 + 5,
        isCircle: Math.random() > 0.5,
        rotation: Math.random() * 360,
      }));
      
      if (isMounted.current) {
        setPieces(newPieces);
      }
      
      // Clear confetti after animation
      timerRef.current = setTimeout(() => {
        if (isMounted.current) {
          setPieces([]);
        }
      }, 5000);
    } else {
      if (isMounted.current) {
        setPieces([]);
      }
      
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    }
  }, [active, count]);
  
  if (!active || pieces.length === 0) return null;
  
  return (
    <View style={styles.container} pointerEvents="none">
      {pieces.map((piece) => (
        <View
          key={piece.id}
          style={{
            position: 'absolute',
            left: piece.left,
            top: piece.top,
            width: piece.size,
            height: piece.size,
            backgroundColor: piece.color,
            borderRadius: piece.isCircle ? piece.size / 2 : 0,
            transform: [{ rotate: `${piece.rotation}deg` }],
            opacity: 0.8,
            zIndex: 1000,
          }}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1000,
  },
  piece: {
    position: 'absolute',
    opacity: 0.8,
  },
});