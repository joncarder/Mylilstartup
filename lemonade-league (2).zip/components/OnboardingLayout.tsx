import React, { ReactNode } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ArrowRight } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { useRouter } from 'expo-router';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, { 
  useSharedValue, 
  withTiming, 
  runOnJS,
  useAnimatedStyle
} from 'react-native-reanimated';

const { height, width } = Dimensions.get('window');

interface OnboardingLayoutProps {
  children: ReactNode;
  title: string;
  description: string;
  currentStep?: number;
  totalSteps?: number;
  nextScreen?: string;
  showSkip?: boolean;
  buttonText?: string;
}

export default function OnboardingLayout({
  children,
  title,
  description,
  currentStep = 1,
  totalSteps = 6,
  nextScreen = '/auth/onboarding-rewards',
  showSkip = true,
  buttonText = 'Next',
}: OnboardingLayoutProps) {
  const router = useRouter();
  const translateX = useSharedValue(0);

  const handleNext = () => {
    router.push(nextScreen);
  };

  const handleSkip = () => {
    router.push('/auth/signup');
  };

  const swipeGesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = e.translationX;
    })
    .onEnd((e) => {
      if (e.translationX < -50) {
        // Swiped left - go to next screen
        translateX.value = withTiming(-100, { duration: 250 }, () => {
          runOnJS(handleNext)();
        });
      } else if (e.translationX > 50 && currentStep > 1) {
        // Swiped right - go to previous screen (if not on first screen)
        translateX.value = withTiming(100, { duration: 250 }, () => {
          // Navigate to previous screen based on current step
          const previousScreens = [
            '/auth/onboarding-payments',
            '/auth/onboarding-rewards',
            '/auth/onboarding-levels',
            '/auth/onboarding-competitions',
            '/auth/onboarding-challenges',
            '/auth/onboarding-coach',
          ];
          runOnJS(router.push)(previousScreens[currentStep - 2]);
        });
      } else {
        // Not enough swipe distance, reset position
        translateX.value = withTiming(0);
      }
    });

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateX: translateX.value }],
    };
  });

  // Don't use gesture detector on web as it's not fully supported
  const ContentWrapper = Platform.OS === 'web' ? View : Animated.View;
  const content = (
    <ContentWrapper style={[styles.content, Platform.OS !== 'web' ? animatedStyle : {}]}>
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          {Array.from({ length: totalSteps }).map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressSegment,
                index < currentStep ? styles.progressIndicator : styles.progressEmpty,
              ]}
            />
          ))}
        </View>
      </View>

      <View style={styles.contentBody}>
        <View style={styles.childrenContainer}>{children}</View>

        <View style={styles.textContainer}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.description}>{description}</Text>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={handleNext}>
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.buttonGradient}
            >
              <Text style={styles.buttonText}>{buttonText}</Text>
              <ArrowRight size={20} color={colors.background} />
            </LinearGradient>
          </TouchableOpacity>

          {showSkip && (
            <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </ContentWrapper>
  );

  return (
    <SafeAreaView style={styles.container}>
      {Platform.OS === 'web' ? (
        content
      ) : (
        <GestureDetector gesture={swipeGesture}>{content}</GestureDetector>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    flex: 1,
  },
  progressContainer: {
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  progressBar: {
    flexDirection: 'row',
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressSegment: {
    flex: 1,
    marginHorizontal: 1,
  },
  progressIndicator: {
    backgroundColor: colors.primary,
  },
  progressEmpty: {
    backgroundColor: 'transparent',
  },
  contentBody: {
    flex: 1,
    padding: 24,
    justifyContent: 'space-between',
  },
  childrenContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    maxHeight: height * 0.5,
  },
  textContainer: {
    marginVertical: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  description: {
    fontSize: 18,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 26,
  },
  buttonContainer: {
    marginTop: 'auto',
    paddingBottom: 16,
  },
  button: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  buttonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  buttonText: {
    color: colors.background,
    fontSize: 18,
    fontWeight: 'bold',
  },
  skipButton: {
    alignItems: 'center',
    padding: 16,
    marginTop: 8,
  },
  skipText: {
    color: colors.textLight,
    fontSize: 16,
  },
});