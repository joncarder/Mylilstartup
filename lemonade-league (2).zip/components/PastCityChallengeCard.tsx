import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { Trophy, Rocket } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { CityChallenge } from '@/constants/city-challenges';

interface PastCityChallengeCardProps {
  challenge: CityChallenge;
}

export default function PastCityChallengeCard({ challenge }: PastCityChallengeCardProps) {
  const { city1, city2, winnerId } = challenge;
  
  // Format date to display in a readable format
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };
  
  const startDate = formatDate(challenge.startDate);
  const endDate = formatDate(challenge.endDate);
  
  // Determine which city won
  const city1Won = winnerId === city1.id;
  const city2Won = winnerId === city2.id;
  
  return (
    <View style={styles.container}>
      <View style={styles.dateContainer}>
        <Text style={styles.dateText}>{startDate} - {endDate}</Text>
      </View>
      
      <View style={styles.citiesContainer}>
        {/* City 1 */}
        <View style={[
          styles.cityContainer,
          city1Won && styles.winnerContainer
        ]}>
          <View style={styles.cityImageContainer}>
            <Image 
              source={{ uri: city1.image }}
              style={styles.cityImage}
              defaultSource={require('@/assets/images/icon.png')}
            />
            {city1Won && (
              <View style={styles.trophyBadge}>
                <Trophy size={14} color={colors.background} />
              </View>
            )}
          </View>
          <Text style={styles.cityName}>{city1.name}</Text>
          <View style={styles.rocketsContainer}>
            <Rocket size={14} color={colors.primary} />
            <Text style={styles.rocketsText}>{city1.totalRockets}</Text>
          </View>
        </View>
        
        {/* VS */}
        <View style={styles.vsContainer}>
          <Text style={styles.vsText}>VS</Text>
        </View>
        
        {/* City 2 */}
        <View style={[
          styles.cityContainer,
          city2Won && styles.winnerContainer
        ]}>
          <View style={styles.cityImageContainer}>
            <Image 
              source={{ uri: city2.image }}
              style={styles.cityImage}
              defaultSource={require('@/assets/images/icon.png')}
            />
            {city2Won && (
              <View style={styles.trophyBadge}>
                <Trophy size={14} color={colors.background} />
              </View>
            )}
          </View>
          <Text style={styles.cityName}>{city2.name}</Text>
          <View style={styles.rocketsContainer}>
            <Rocket size={14} color={colors.primary} />
            <Text style={styles.rocketsText}>{city2.totalRockets}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  dateContainer: {
    marginBottom: 12,
  },
  dateText: {
    fontSize: 14,
    color: colors.textLight,
    fontWeight: '500',
  },
  citiesContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cityContainer: {
    flex: 2,
    alignItems: 'center',
  },
  winnerContainer: {
    // Subtle highlight for the winner
  },
  cityImageContainer: {
    position: 'relative',
    marginBottom: 8,
  },
  cityImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  trophyBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: colors.primary,
    borderRadius: 10,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.background,
  },
  cityName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  rocketsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rocketsText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.primary,
  },
  vsContainer: {
    flex: 1,
    alignItems: 'center',
  },
  vsText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.textLight,
  },
});