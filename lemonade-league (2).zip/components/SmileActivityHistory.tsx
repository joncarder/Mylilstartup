import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useSmileRewardsStore } from '@/store/smile-rewards-store';
import { colors } from '@/constants/colors';
import { Star, Gift, Clock, ArrowDown, ArrowUp, Share2 } from 'lucide-react-native';

interface SmileActivityHistoryProps {
  limit?: number;
}

export default function SmileActivityHistory({ limit }: SmileActivityHistoryProps) {
  const { activityHistory, isLoading, error, fetchActivityHistory } = useSmileRewardsStore();
  
  React.useEffect(() => {
    fetchActivityHistory();
  }, []);
  
  const getActivityIcon = (type: string, points: number) => {
    if (type === 'points_earned' || type === 'purchase') {
      return <ArrowUp size={16} color={colors.primary} />;
    } else if (type === 'reward_redeemed') {
      return <Gift size={16} color={colors.secondary} />;
    } else if (type === 'referral') {
      return <Share2 size={16} color={colors.primary} />;
    } else {
      return points >= 0 
        ? <ArrowUp size={16} color={colors.primary} />
        : <ArrowDown size={16} color={colors.error} />;
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };
  
  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color={colors.primary} size="small" />
        <Text style={styles.loadingText}>Loading activity...</Text>
      </View>
    );
  }
  
  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }
  
  const displayActivities = limit 
    ? activityHistory.slice(0, limit) 
    : activityHistory;
  
  if (displayActivities.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Clock size={24} color={colors.textLight} />
        <Text style={styles.emptyText}>No activity yet</Text>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      {displayActivities.map(activity => (
        <View key={activity.id} style={styles.activityItem}>
          <View style={styles.activityIconContainer}>
            {getActivityIcon(activity.type, activity.points)}
          </View>
          <View style={styles.activityDetails}>
            <Text style={styles.activityDescription}>{activity.description}</Text>
            <Text style={styles.activityDate}>{formatDate(activity.createdAt)}</Text>
          </View>
          <Text style={[
            styles.activityPoints,
            activity.points >= 0 ? styles.pointsPositive : styles.pointsNegative
          ]}>
            {activity.points >= 0 ? '+' : ''}{activity.points}
          </Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    overflow: 'hidden',
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  activityIconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  activityDetails: {
    flex: 1,
  },
  activityDescription: {
    fontSize: 14,
    color: colors.text,
  },
  activityDate: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 2,
  },
  activityPoints: {
    fontSize: 14,
    fontWeight: '600',
  },
  pointsPositive: {
    color: colors.primary,
  },
  pointsNegative: {
    color: colors.error,
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  loadingText: {
    marginTop: 8,
    color: colors.textLight,
    fontSize: 14,
  },
  errorContainer: {
    padding: 20,
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    textAlign: 'center',
  },
  emptyContainer: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  emptyText: {
    marginTop: 8,
    color: colors.textLight,
    fontSize: 14,
  },
});