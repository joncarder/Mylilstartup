import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Smile } from 'lucide-react-native';
import { colors } from '@/constants/colors';

interface MoneyMouthIconProps {
  size?: number;
  color?: string;
  style?: any;
}

export default function MoneyMouthIcon({ size = 50, color = colors.background, style }: MoneyMouthIconProps) {
  return (
    <View style={[styles.container, style]}>
      <Smile size={size} color={color} strokeWidth={2} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});