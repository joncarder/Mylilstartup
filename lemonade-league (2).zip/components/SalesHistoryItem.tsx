import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Tag, Rocket, Clock, RefreshCcw } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { Sale } from '@/store/user-store';

interface SalesHistoryItemProps {
  sale: Sale;
  onRefund: (sale: Sale) => void;
  highlight?: boolean;
  searchTerm?: string;
}

export default function SalesHistoryItem({ sale, onRefund, highlight = false, searchTerm = '' }: SalesHistoryItemProps) {
  // Format date for display (without year)
  const formatSaleDate = (dateString: string) => {
    const saleDate = new Date(dateString);
    
    // Format date: Jan 1 (no year)
    const options: Intl.DateTimeFormatOptions = { 
      month: 'short', 
      day: 'numeric'
    };
    const dateFormatted = saleDate.toLocaleDateString(undefined, options);
    
    // Format time: 2:30 PM
    const timeOptions: Intl.DateTimeFormatOptions = { 
      hour: 'numeric', 
      minute: 'numeric', 
      hour12: true 
    };
    const timeFormatted = saleDate.toLocaleTimeString(undefined, timeOptions);
    
    return `${dateFormatted} at ${timeFormatted}`;
  };

  // Don't show refund button if already refunded
  const isRefunded = sale.refunded;

  // Highlight matching text if search is active
  const highlightText = (text: string, term: string) => {
    if (!highlight || !term || !text) return text;
    
    const lowerText = text.toLowerCase();
    const lowerTerm = term.toLowerCase();
    
    if (!lowerText.includes(lowerTerm)) return text;
    
    const startIndex = lowerText.indexOf(lowerTerm);
    const endIndex = startIndex + lowerTerm.length;
    
    return (
      <>
        {text.substring(0, startIndex)}
        <Text style={styles.highlightedText}>
          {text.substring(startIndex, endIndex)}
        </Text>
        {text.substring(endIndex)}
      </>
    );
  };

  // Check if this item should be highlighted based on search term
  const shouldHighlight = () => {
    if (!highlight || !searchTerm) return false;
    
    const term = searchTerm.toLowerCase();
    const customerName = (sale.customerName || '').toLowerCase();
    const product = (sale.product || '').toLowerCase();
    const amount = sale.amount.toString();
    
    return customerName.includes(term) || 
           product.includes(term) || 
           amount.includes(term);
  };

  return (
    <View style={[
      styles.container, 
      isRefunded && styles.refundedContainer,
      shouldHighlight() && styles.highlightedContainer
    ]}>
      <View style={styles.header}>
        <View style={styles.productContainer}>
          <Tag size={16} color={isRefunded ? colors.textLight : colors.primary} />
          <Text style={[styles.productText, isRefunded && styles.refundedText]}>
            {highlight && searchTerm ? 
              highlightText(sale.product || 'Product', searchTerm) : 
              (sale.product || 'Product')}
            {isRefunded && ' (Refunded)'}
          </Text>
        </View>
        
        <View style={styles.amountContainer}>
          <Text style={[styles.amountText, isRefunded && styles.refundedText]}>
            ${highlight && searchTerm ? 
              highlightText(sale.amount.toFixed(2), searchTerm) : 
              sale.amount.toFixed(2)}
          </Text>
        </View>
      </View>
      
      <View style={styles.details}>
        <View style={styles.detailRow}>
          <View style={styles.detailItem}>
            <Clock size={14} color={colors.textLight} />
            <Text style={styles.detailText}>{formatSaleDate(sale.date)}</Text>
          </View>
          
          <View style={styles.customerContainer}>
            <Text style={styles.customerText}>
              Bought by {highlight && searchTerm ? 
                highlightText(sale.customerName || 'Jane Z', searchTerm) : 
                (sale.customerName || 'Jane Z')}
            </Text>
          </View>
        </View>
        
        {!isRefunded && sale.rocketsEarned !== undefined && sale.rocketsEarned > 0 && (
          <View style={styles.rocketsContainer}>
            <Rocket size={14} color={colors.secondary} />
            <Text style={styles.rocketsText}>
              +{sale.rocketsEarned} {sale.rewardEarned ? '(includes bonus!)' : ''}
            </Text>
          </View>
        )}
      </View>

      {!isRefunded && (
        <TouchableOpacity 
          style={styles.refundButton}
          onPress={() => onRefund(sale)}
        >
          <RefreshCcw size={14} color={colors.error} />
          <Text style={styles.refundButtonText}>Issue Refund</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 10,
    marginBottom: 8,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  refundedContainer: {
    opacity: 0.7,
    backgroundColor: colors.card + '80',
  },
  highlightedContainer: {
    borderWidth: 1,
    borderColor: colors.primary,
    backgroundColor: colors.primary + '08',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  productContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  productText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.primary,
  },
  refundedText: {
    color: colors.textLight,
  },
  amountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  amountText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.secondary,
  },
  details: {
    gap: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  detailText: {
    fontSize: 14,
    color: colors.textLight,
  },
  rocketsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginTop: 2,
  },
  rocketsText: {
    fontSize: 14,
    color: colors.secondary,
    fontWeight: '500',
  },
  customerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  customerText: {
    fontSize: 14,
    color: colors.textLight,
  },
  refundButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.error + '15',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginTop: 6,
    alignSelf: 'flex-end',
    gap: 6,
  },
  refundButtonText: {
    fontSize: 14,
    color: colors.error,
    fontWeight: '500',
  },
  highlightedText: {
    backgroundColor: colors.primary + '30',
    color: colors.primary,
    fontWeight: '700',
  },
});