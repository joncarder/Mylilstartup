import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, Animated } from 'react-native';
import { Star, CircleDot, Award, X, Rocket, Ticket, Sparkles } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/constants/colors';

interface LevelProgressBarProps {
  level: number;
  title: string;
  progress: number;
  rockets: number;
  rocketsToNextLevel: number;
}

export default function LevelProgressBar({
  level,
  title,
  progress,
  rockets,
  rocketsToNextLevel
}: LevelProgressBarProps) {
  const [showExplanation, setShowExplanation] = useState(false);
  const [scaleAnim] = useState(new Animated.Value(1));
  
  // Extract just the role name without the level number
  // Add a fallback in case title is undefined
  const roleName = title ? title.split(' ')[0] : 'Assistant';
  
  const handlePress = () => {
    // Small pulse animation when pressed
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.03,
        duration: 150,
        useNativeDriver: true
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true
      })
    ]).start();
    
    setShowExplanation(true);
  };
  
  return (
    <>
      <TouchableOpacity activeOpacity={0.8} onPress={handlePress}>
        <Animated.View 
          style={[
            styles.container,
            { transform: [{ scale: scaleAnim }] }
          ]}
        >
          <View style={styles.levelHeader}>
            <View style={styles.levelBadge}>
              <Star size={20} color={colors.primary} />
              <Text style={styles.levelText}>Level {level}: {roleName}</Text>
            </View>
          </View>
          
          <View style={styles.progressContainer}>
            {/* Use LinearGradient for the progress bar */}
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.progressBar, { width: `${progress * 100}%` }]}
            />
            
            {/* Wheel icon at the end of the progress bar */}
            <View style={styles.wheelIconContainer}>
              <CircleDot size={18} color={colors.primary} strokeWidth={2.5} />
            </View>
          </View>
          
          <Text style={styles.nextLevel}>
            {rocketsToNextLevel} more rockets to spin the wheel!
          </Text>
        </Animated.View>
      </TouchableOpacity>
      
      {/* Level Explanation Modal */}
      <Modal
        visible={showExplanation}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowExplanation(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowExplanation(false)}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.levelHeaderGradient}
            >
              <View style={styles.levelIconContainer}>
                <Award size={40} color="#FFFFFF" />
              </View>
              <Text style={styles.levelTitle}>You are Level {level}!</Text>
              <Text style={styles.levelRole}>Your role: {roleName}</Text>
            </LinearGradient>
            
            <View style={styles.explanationContent}>
              <View style={styles.infoRow}>
                <Rocket size={24} color={colors.primary} />
                <Text style={styles.infoText}>
                  You need <Text style={styles.highlightText}>{rocketsToNextLevel} more rockets</Text> to reach Level {level + 1}
                </Text>
              </View>
              
              <View style={styles.divider} />
              
              <View style={styles.rewardSection}>
                <Text style={styles.rewardTitle}>Level Up Rewards:</Text>
                
                <View style={styles.rewardItem}>
                  <View style={styles.rewardIconContainer}>
                    <CircleDot size={24} color={colors.primary} />
                  </View>
                  <Text style={styles.rewardText}>
                    Free spin of the wheel to win rockets
                  </Text>
                </View>
                
                <View style={styles.rewardItem}>
                  <View style={styles.specialRewardIconContainer}>
                    <Ticket size={24} color="#FFD700" />
                    <Sparkles size={14} color="#FFD700" style={styles.sparklesIcon} />
                  </View>
                  <Text style={styles.rewardText}>
                    Chance to win a rare <Text style={styles.goldenText}>Golden Ticket</Text>!
                  </Text>
                </View>
              </View>
              
              <View style={styles.tipContainer}>
                <Award size={20} color={colors.secondary} />
                <Text style={styles.tipText}>
                  Every $2 in sales earns you 1 rocket. Keep selling to level up faster!
                </Text>
              </View>
            </View>
            
            <TouchableOpacity 
              style={styles.closeModalButton}
              onPress={() => setShowExplanation(false)}
            >
              <Text style={styles.closeModalButtonText}>Got it!</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.background,
    padding: 16,
    borderRadius: 12,
  },
  levelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  levelText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.secondary,
  },
  progressContainer: {
    height: 8,
    backgroundColor: colors.border,
    borderRadius: 4,
    overflow: 'visible',
    position: 'relative',
  },
  progressBar: {
    height: '100%',
    borderRadius: 4,
  },
  wheelIconContainer: {
    position: 'absolute',
    right: -8,
    top: -5,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.secondary,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  nextLevel: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 8,
    textAlign: 'center',
    fontWeight: '500',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 15,
    padding: 5,
  },
  levelHeaderGradient: {
    padding: 24,
    alignItems: 'center',
  },
  levelIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  levelTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  levelRole: {
    fontSize: 18,
    color: '#FFFFFF',
    opacity: 0.9,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 0.5, height: 0.5 },
    textShadowRadius: 1,
  },
  explanationContent: {
    padding: 20,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  infoText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  highlightText: {
    color: colors.secondary,
    fontWeight: 'bold',
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 16,
  },
  rewardSection: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  rewardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  rewardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  rewardIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  specialRewardIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 215, 0, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  sparklesIcon: {
    position: 'absolute',
    top: -5,
    right: -5,
  },
  rewardText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  goldenText: {
    color: '#FFD700',
    fontWeight: 'bold',
  },
  tipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.backgroundDark + '15',
    padding: 12,
    borderRadius: 12,
    gap: 10,
  },
  tipText: {
    fontSize: 14,
    color: colors.secondary,
    flex: 1,
  },
  closeModalButton: {
    backgroundColor: colors.accent,
    paddingVertical: 16,
    alignItems: 'center',
  },
  closeModalButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: 'bold',
  },
});