import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated, Easing, Dimensions, Platform } from 'react-native';
import { colors } from '@/constants/colors';

interface ConfettiPiece {
  id: number;
  x: Animated.Value;
  y: Animated.Value;
  rotate: Animated.Value;
  scale: Animated.Value;
  color: string;
  size: number;
  shape: 'circle' | 'square' | 'rectangle' | 'triangle';
  opacity: Animated.Value;
}

interface ConfettiAnimationProps {
  duration?: number;
  pieces?: number;
  colors?: string[];
  density?: 'low' | 'medium' | 'high';
}

const { width, height } = Dimensions.get('window');

export default function ConfettiAnimation({ 
  duration = 3000, 
  pieces = 100,
  colors: customColors,
  density = 'medium'
}: ConfettiAnimationProps) {
  // For web, use a simplified version to avoid stack overflow
  if (Platform.OS === 'web') {
    return null; // Don't render confetti on web to avoid stack overflow
  }
  
  const confetti = useRef<ConfettiPiece[]>([]);
  const animationsRef = useRef<Animated.CompositeAnimation | null>(null);
  const isMounted = useRef(true);
  
  // Default colors from brand palette
  const defaultColors = [
    colors.primary,      // Mint Green
    colors.secondary,    // Purple
    colors.accent,       // Blue
    '#FFFFFF',          // White
    '#FFD700',          // Gold for special effect
  ];
  
  const actualColors = customColors || defaultColors;
  
  // Adjust pieces based on density
  const actualPieces = density === 'low' ? pieces / 2 : 
                      density === 'high' ? pieces * 2 : 
                      pieces;

  // Generate confetti pieces
  useEffect(() => {
    // Create confetti pieces with varied properties
    confetti.current = Array(Math.min(actualPieces, 100)).fill(0).map((_, i) => {
      // Randomize starting position across the width
      const startX = Math.random() * width;
      
      // Randomize starting position above the screen
      const startY = -20 - Math.random() * 100;
      
      return {
        id: i,
        x: new Animated.Value(startX),
        y: new Animated.Value(startY),
        rotate: new Animated.Value(0),
        scale: new Animated.Value(Math.random() * 0.5 + 0.5),
        color: actualColors[Math.floor(Math.random() * actualColors.length)],
        size: Math.random() * 10 + 5, // Slightly larger pieces
        shape: ['circle', 'square', 'rectangle', 'triangle'][Math.floor(Math.random() * 4)] as 'circle' | 'square' | 'rectangle' | 'triangle',
        opacity: new Animated.Value(1),
      };
    });

    // Start animation
    const animations = confetti.current.map(piece => {
      // Randomize horizontal movement
      const xDestination = piece.x._value + (Math.random() * 300 - 150);
      
      // Create a sequence of animations for each piece
      return Animated.parallel([
        // Vertical movement
        Animated.timing(piece.y, {
          toValue: height * 0.8, // Fall to 80% of screen height
          duration,
          easing: Easing.bezier(0.1, 0.25, 0.1, 1), // More natural falling motion
          useNativeDriver: true,
        }),
        
        // Horizontal drift
        Animated.timing(piece.x, {
          toValue: xDestination,
          duration,
          easing: Easing.bezier(0.1, 0.25, 0.1, 1),
          useNativeDriver: true,
        }),
        
        // Rotation
        Animated.timing(piece.rotate, {
          toValue: Math.random() * 10 + 5, // More rotation
          duration,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        
        // Fade out near the end
        Animated.sequence([
          Animated.timing(piece.opacity, {
            toValue: 1,
            duration: duration * 0.7, // Stay visible for 70% of the animation
            useNativeDriver: true,
          }),
          Animated.timing(piece.opacity, {
            toValue: 0,
            duration: duration * 0.3, // Fade out for the last 30%
            useNativeDriver: true,
          }),
        ]),
      ]);
    });

    // Stagger the start of each piece's animation for a more natural effect
    if (animations.length > 0) {
      const staggeredAnimation = Animated.stagger(20, animations);
      animationsRef.current = staggeredAnimation;
      
      if (isMounted.current) {
        staggeredAnimation.start();
      }
    }

    return () => {
      // Clean up animations on unmount
      isMounted.current = false;
      
      if (animationsRef.current) {
        animationsRef.current.stop();
        animationsRef.current = null;
      }
      
      // Reset all animated values to prevent memory leaks
      confetti.current.forEach(piece => {
        piece.x.stopAnimation();
        piece.y.stopAnimation();
        piece.rotate.stopAnimation();
        piece.opacity.stopAnimation();
        piece.scale.stopAnimation();
      });
      
      confetti.current = [];
    };
  }, [duration, actualPieces, actualColors, density, height, width]);

  // Render the confetti pieces
  return (
    <View style={styles.container} pointerEvents="none">
      {confetti.current.map(piece => (
        <Animated.View
          key={piece.id}
          style={[
            styles.confetti,
            {
              width: piece.shape === 'rectangle' ? piece.size * 2 : piece.size,
              height: piece.size,
              backgroundColor: piece.color,
              borderRadius: piece.shape === 'circle' ? piece.size / 2 : 0,
              opacity: piece.opacity,
              transform: [
                { translateX: piece.x },
                { translateY: piece.y },
                { rotate: piece.rotate.interpolate({
                  inputRange: [0, 10],
                  outputRange: ['0deg', '360deg'],
                })},
                { scale: piece.scale },
              ],
            },
            // Special styling for triangle shape
            piece.shape === 'triangle' && styles.triangle,
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1000,
  },
  confetti: {
    position: 'absolute',
  },
  triangle: {
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 5,
    borderRightWidth: 5,
    borderBottomWidth: 10,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
  },
});