import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Modal, 
  TouchableOpacity, 
  ScrollView 
} from 'react-native';
import { X, Lock, Check, Trophy, Info } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { Badge } from '@/constants/badges';

interface BadgeDetailModalProps {
  visible: boolean;
  badge: Badge | null;
  isUnlocked: boolean;
  onClose: () => void;
}

export default function BadgeDetailModal({ 
  visible, 
  badge, 
  isUnlocked, 
  onClose 
}: BadgeDetailModalProps) {
  if (!badge) return null;

  const getBadgeTypeColor = (type: string) => {
    switch (type) {
      case 'milestone':
        return colors.secondary;
      case 'achievement':
        return colors.secondary;
      case 'special':
        return colors.accent;
      default:
        return colors.textLight;
    }
  };

  const getBadgeCategoryLabel = (category: string) => {
    switch (category) {
      case 'sales':
        return 'Sales';
      case 'social':
        return 'Social';
      case 'learning':
        return 'Learning';
      case 'consistency':
        return 'Consistency';
      case 'special':
        return 'Special';
      default:
        return category.charAt(0).toUpperCase() + category.slice(1);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="fade"
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <TouchableOpacity 
            style={styles.closeButton} 
            onPress={onClose}
          >
            <X size={24} color={colors.text} />
          </TouchableOpacity>

          <ScrollView style={styles.scrollContent}>
            <View style={styles.badgeIconContainer}>
              <View style={[
                styles.badgeIcon, 
                isUnlocked ? styles.unlockedBadgeIcon : styles.lockedBadgeIcon
              ]}>
                <Text style={[
                  styles.badgeEmoji,
                  !isUnlocked && styles.lockedBadgeEmoji
                ]}>
                  {badge.icon}
                </Text>
                {!isUnlocked && (
                  <View style={styles.lockIconContainer}>
                    <Lock size={20} color={colors.textLight} />
                  </View>
                )}
              </View>
            </View>

            <Text style={styles.badgeName}>{badge.name}</Text>
            
            <View style={styles.badgeMetaContainer}>
              <View style={[
                styles.badgeTypeTag, 
                { backgroundColor: getBadgeTypeColor(badge.type) + '20' }
              ]}>
                <Text style={[
                  styles.badgeTypeText, 
                  { color: getBadgeTypeColor(badge.type) }
                ]}>
                  {badge.type.charAt(0).toUpperCase() + badge.type.slice(1)}
                </Text>
              </View>
              
              <View style={styles.badgeCategoryTag}>
                <Text style={styles.badgeCategoryText}>
                  {getBadgeCategoryLabel(badge.category)}
                </Text>
              </View>
            </View>

            <View style={styles.statusContainer}>
              {isUnlocked ? (
                <View style={styles.unlockedStatus}>
                  <Check size={16} color={colors.primary} />
                  <Text style={styles.unlockedText}>Unlocked</Text>
                </View>
              ) : (
                <View style={styles.lockedStatus}>
                  <Lock size={16} color={colors.textLight} />
                  <Text style={styles.lockedText}>Locked</Text>
                </View>
              )}
            </View>

            <View style={styles.descriptionContainer}>
              <Text style={styles.descriptionTitle}>Description</Text>
              <Text style={styles.descriptionText}>
                {badge.detailedDescription}
              </Text>
            </View>

            <View style={styles.requirementContainer}>
              <View style={styles.requirementHeader}>
                <Trophy size={18} color={colors.primary} />
                <Text style={styles.requirementTitle}>How to Earn</Text>
              </View>
              <Text style={styles.requirementText}>
                {badge.requirement}
              </Text>
            </View>

            {badge.unlockedAt > 0 && (
              <View style={styles.levelRequirementContainer}>
                <Info size={16} color={colors.textLight} />
                <Text style={styles.levelRequirementText}>
                  Unlocks at level {badge.unlockedAt}
                </Text>
              </View>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '85%',
    maxHeight: '80%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  closeButton: {
    alignSelf: 'flex-end',
    padding: 5,
  },
  scrollContent: {
    flexGrow: 0,
  },
  badgeIconContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  badgeIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: colors.backgroundDark + '15',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  unlockedBadgeIcon: {
    backgroundColor: colors.primary + '20',
    borderWidth: 3,
    borderColor: colors.primary,
  },
  lockedBadgeIcon: {
    backgroundColor: colors.border,
    opacity: 0.7,
  },
  badgeEmoji: {
    fontSize: 50,
  },
  lockedBadgeEmoji: {
    opacity: 0.5,
  },
  lockIconContainer: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: colors.background,
    borderRadius: 15,
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.border,
  },
  badgeName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
    marginBottom: 10,
  },
  badgeMetaContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
    marginBottom: 20,
  },
  badgeTypeTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  badgeTypeText: {
    fontSize: 14,
    fontWeight: '500',
  },
  badgeCategoryTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: colors.backgroundDark + '15',
  },
  badgeCategoryText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.secondary,
  },
  statusContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  unlockedStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  unlockedText: {
    color: colors.secondary,
    fontWeight: '500',
  },
  lockedStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: colors.border + '50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  lockedText: {
    color: colors.textLight,
    fontWeight: '500',
  },
  descriptionContainer: {
    marginBottom: 20,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  descriptionText: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 24,
  },
  requirementContainer: {
    marginBottom: 20,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
  },
  requirementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  requirementTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  requirementText: {
    fontSize: 15,
    color: colors.text,
    lineHeight: 22,
  },
  levelRequirementContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginBottom: 10,
  },
  levelRequirementText: {
    fontSize: 14,
    color: colors.textLight,
    fontStyle: 'italic',
  },
});