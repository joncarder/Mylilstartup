import React, { useRef, useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, Easing, Platform } from 'react-native';
import { Rocket } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { wheelRewards } from '@/constants/rewards';

interface SpinWheelProps {
  onSpin: () => void;
  onRewardSelected: (rewardIndex: number) => void;
  spinsAvailable: number;
  demoMode?: boolean;
  autoSpin?: boolean;
  fixedRewardIndex?: number; // Add option to force a specific reward index
}

const SpinWheel = forwardRef(({ 
  onSpin, 
  onRewardSelected, 
  spinsAvailable, 
  demoMode = false,
  autoSpin = false,
  fixedRewardIndex
}: SpinWheelProps, ref) => {
  const [spinning, setSpinning] = useState(false);
  const [selectedReward, setSelectedReward] = useState<number | null>(null);
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const animationRef = useRef<Animated.CompositeAnimation | null>(null);
  
  // Number of segments in the wheel
  const numSegments = wheelRewards.length;
  const segmentAngle = 360 / numSegments;
  
  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    getCurrentReward: () => selectedReward !== null ? wheelRewards[selectedReward] : null,
    resetWheel: () => {
      if (animationRef.current) {
        animationRef.current.stop();
        animationRef.current = null;
      }
      rotateAnim.setValue(0);
      setSelectedReward(null);
    }
  }));
  
  // Auto-spin for demo mode
  useEffect(() => {
    if ((demoMode && autoSpin) && !spinning && selectedReward === null) {
      handleSpin();
    }
    
    // Clean up animation on unmount
    return () => {
      if (animationRef.current) {
        animationRef.current.stop();
        animationRef.current = null;
      }
    };
  }, [demoMode, autoSpin, spinning, selectedReward]);
  
  const handleSpin = () => {
    if (spinning || (spinsAvailable <= 0 && !demoMode)) return;
    
    setSpinning(true);
    if (!demoMode) onSpin();
    
    // For demo mode or when fixedRewardIndex is provided, use that specific reward
    let winningIndex = fixedRewardIndex !== undefined ? fixedRewardIndex : 0;
    
    if (!demoMode && fixedRewardIndex === undefined) {
      // In real mode, use weighted random selection
      const random = Math.random() * 100;
      let cumulativeProbability = 0;
      
      for (let i = 0; i < wheelRewards.length; i++) {
        cumulativeProbability += wheelRewards[i].chance;
        if (random <= cumulativeProbability) {
          winningIndex = i;
          break;
        }
      }
    }
    
    // Calculate rotation to land on the winning segment
    // We add 5-10 full rotations for effect, then position to the winning segment
    const rotations = 5 + Math.random() * 5; // 5-10 rotations
    const targetRotation = rotations * 360 + (360 - (winningIndex * segmentAngle));
    
    console.log(`Spinning wheel to land on index ${winningIndex}: ${wheelRewards[winningIndex].name}`);
    
    // Store animation reference so we can stop it if needed
    animationRef.current = Animated.timing(rotateAnim, {
      toValue: targetRotation,
      duration: 3000,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: Platform.OS !== 'web',
    });
    
    animationRef.current.start(() => {
      setSelectedReward(winningIndex);
      setSpinning(false);
      onRewardSelected(winningIndex);
      animationRef.current = null;
      
      // For demo mode, reset after a delay
      if (demoMode) {
        setTimeout(() => {
          rotateAnim.setValue(0);
          setSelectedReward(null);
        }, 3000);
      }
    });
  };
  
  // Reset animation when done
  useEffect(() => {
    if (!spinning && selectedReward !== null && !demoMode) {
      const timer = setTimeout(() => {
        rotateAnim.setValue(0);
        setSelectedReward(null);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [spinning, selectedReward, demoMode]);
  
  const spin = rotateAnim.interpolate({
    inputRange: [0, 360],
    outputRange: ['0deg', '360deg'],
  });
  
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Spin to Win!</Text>
      {!demoMode && (
        <Text style={styles.subtitle}>Spins available: {spinsAvailable}</Text>
      )}
      
      <View style={styles.wheelContainer}>
        <Animated.View
          style={[
            styles.wheel,
            { transform: [{ rotate: spin }] }
          ]}
        >
          {wheelRewards.map((reward, index) => (
            <View
              key={reward.id}
              style={[
                styles.segment,
                {
                  transform: [{ rotate: `${index * segmentAngle}deg` }],
                  backgroundColor: getSegmentColor(index, reward.rarity),
                }
              ]}
            >
              <View style={[
                styles.segmentTextContainer,
                { transform: [{ rotate: `${segmentAngle / 2}deg` }] }
              ]}>
                <Text style={styles.segmentText}>
                  {reward.name}
                </Text>
              </View>
            </View>
          ))}
        </Animated.View>
        
        {/* Center pin */}
        <View style={styles.centerPin}>
          <Rocket size={24} color={colors.primary} />
        </View>
        
        {/* Pointer */}
        <View style={styles.pointer} />
      </View>
      
      {!demoMode && (
        <TouchableOpacity
          style={[
            styles.spinButton,
            (spinning || spinsAvailable <= 0) && styles.spinButtonDisabled
          ]}
          onPress={handleSpin}
          disabled={spinning || spinsAvailable <= 0}
        >
          <Text style={styles.spinButtonText}>
            {spinning ? 'Spinning...' : spinsAvailable <= 0 ? 'No Spins Left' : 'SPIN!'}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
});

// Helper function to get segment colors based on rarity
function getSegmentColor(index: number, rarity: string): string {
  const baseColors = [
    colors.primary + '80', // Common with opacity
    colors.secondary + '80', // Uncommon with opacity
  ];
  
  // Special colors for rare and legendary
  if (rarity === 'rare') return colors.accent + '80';
  if (rarity === 'legendary') return '#FFD700' + '80'; // Gold with opacity
  
  return baseColors[index % baseColors.length];
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textLight,
    marginBottom: 20,
  },
  wheelContainer: {
    width: 280,
    height: 280,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
  },
  wheel: {
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: colors.card,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 2,
    borderColor: colors.border,
  },
  segment: {
    position: 'absolute',
    width: '50%',
    height: '50%',
    left: '50%',
    top: 0,
    transformOrigin: 'bottom left',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 10,
  },
  segmentTextContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 10,
    marginTop: 15,
    borderWidth: 1,
    borderColor: colors.border,
  },
  segmentText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.text,
    textAlign: 'center',
  },
  centerPin: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.background,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.border,
    zIndex: 10,
  },
  pointer: {
    position: 'absolute',
    top: 0,
    width: 20,
    height: 20,
    backgroundColor: colors.accent,
    transform: [{ rotate: '45deg' }],
    zIndex: 5,
  },
  spinButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 30,
    marginTop: 20,
  },
  spinButtonDisabled: {
    backgroundColor: colors.textLight,
    opacity: 0.7,
  },
  spinButtonText: {
    color: colors.background,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default SpinWheel;