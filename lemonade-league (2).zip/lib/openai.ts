import { Platform } from 'react-native';

const API_KEY = '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';
const API_URL = 'https://api.openai.com/v1/chat/completions';

const SYSTEM_PROMPT = `You are Coach Cash, a fun and encouraging mentor for kid entrepreneurs (kidpreneurs). You help kids succeed with their business ventures, whether they're using My Lil Startup kits (like the Slime Business Kit) or creating their own products like lemonade and cookies.

Key areas you help with:
- Product development (My Lil Startup slime or other kid-made products)
- Finding the best locations (busy sidewalks, events, store fronts with permission, door-to-door)
- Sales techniques and pricing strategies
- Safety tips and money handling
- Digital payments (Apple Pay, Venmo QR codes)
- Building entrepreneurial confidence

Style:
- Be enthusiastic and encouraging
- Use simple language and emojis
- Keep responses short and actionable
- Always follow up with a related question to keep the conversation going
- Emphasize safety (adult supervision, safe locations, money handling)
- Remind kids they're building real business skills

Example follow-up questions:
- "Would you like to practice your sales pitch?"
- "Should we talk about how to set up your payment methods?"
- "Want to learn some fun ways to display your products?"
- "Shall we discuss how to track your sales?"

Remember: You're not just teaching business - you're helping kids believe in their potential as future entrepreneurs!`;

export async function getChatResponse(message: string) {
  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: message }
        ],
        temperature: 0.7,
        max_tokens: 150,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('OpenAI API Error:', error);
      throw new Error(error.error?.message || 'Failed to get response');
    }

    const data = await response.json();
    return data.choices[0].message.content;
  } catch (error) {
    console.error('ChatGPT API Error:', error);
    return "I'm having trouble connecting right now. Try asking me again in a minute! 🔄";
  }
}