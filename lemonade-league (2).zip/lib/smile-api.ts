import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

// Smile.io API configuration
const SMILE_API_BASE_URL = 'https://api.smile.io/v1';
const SMILE_API_KEY = 'YOUR_SMILE_API_KEY'; // Replace with your actual API key
const SMILE_CHANNEL_KEY = 'YOUR_SMILE_CHANNEL_KEY'; // Replace with your actual channel key
const SMILE_MERCHANT_ID = 'YOUR_SMILE_MERCHANT_ID'; // Replace with your actual merchant ID

// Customer token management
const getSmileCustomerToken = async () => {
  try {
    return await AsyncStorage.getItem('smile_customer_token');
  } catch (error) {
    console.error('Error getting Smile customer token:', error);
    return null;
  }
};

const setSmileCustomerToken = async (token: string) => {
  try {
    await AsyncStorage.setItem('smile_customer_token', token);
  } catch (error) {
    console.error('Error setting Smile customer token:', error);
  }
};

const clearSmileCustomerToken = async () => {
  try {
    await AsyncStorage.removeItem('smile_customer_token');
  } catch (error) {
    console.error('Error clearing Smile customer token:', error);
  }
};

// Helper for making authenticated API requests to Smile.io
const smileApiRequest = async (
  endpoint: string,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' = 'GET',
  data?: any,
  requiresAuth: boolean = true
) => {
  try {
    const url = `${SMILE_API_BASE_URL}${endpoint}`;
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      'X-Smile-Api-Key': SMILE_API_KEY,
      'X-Smile-Channel-Key': SMILE_CHANNEL_KEY,
      'X-Smile-Merchant-Id': SMILE_MERCHANT_ID,
    };

    if (requiresAuth) {
      const token = await getSmileCustomerToken();
      if (!token) {
        throw new Error('Smile authentication required');
      }
      headers['X-Smile-Customer-Token'] = token;
    }

    const options: RequestInit = {
      method,
      headers,
      body: data ? JSON.stringify(data) : undefined,
    };

    const response = await fetch(url, options);
    const responseData = await response.json();

    if (!response.ok) {
      throw new Error(responseData.message || 'Smile API request failed');
    }

    return responseData;
  } catch (error: any) {
    console.error(`Smile API Error (${endpoint}):`, error);
    throw error;
  }
};

// Smile.io API client
export const smileApi = {
  // Initialize a customer with Smile.io
  initializeCustomer: async (email: string, firstName?: string, lastName?: string) => {
    try {
      const response = await smileApiRequest('/customers', 'POST', {
        customer: {
          email,
          first_name: firstName,
          last_name: lastName
        }
      }, false);

      if (response.customer && response.customer.token) {
        await setSmileCustomerToken(response.customer.token);
      }

      return response.customer;
    } catch (error) {
      throw error;
    }
  },

  // Get customer profile from Smile.io
  getCustomerProfile: async () => {
    return await smileApiRequest('/customer');
  },

  // Get customer points balance
  getPointsBalance: async () => {
    const response = await smileApiRequest('/customer/points_balance');
    return response.points_balance;
  },

  // Get customer rewards
  getCustomerRewards: async () => {
    const response = await smileApiRequest('/customer/rewards');
    return response.rewards;
  },

  // Get available rewards catalog
  getRewardsCatalog: async () => {
    const response = await smileApiRequest('/rewards');
    return response.rewards;
  },

  // Redeem a reward
  redeemReward: async (rewardId: string) => {
    const response = await smileApiRequest(`/rewards/${rewardId}/redeem`, 'POST');
    return response.redemption;
  },

  // Award points to a customer
  awardPoints: async (points: number, reason: string) => {
    const response = await smileApiRequest('/customer/points', 'POST', {
      points: {
        amount: points,
        reason
      }
    });
    return response.points_transaction;
  },

  // Record a purchase to earn points
  recordPurchase: async (orderId: string, amount: number, products?: any[]) => {
    const response = await smileApiRequest('/customer/purchases', 'POST', {
      purchase: {
        order_id: orderId,
        subtotal: amount,
        line_items: products || []
      }
    });
    return response.purchase;
  },

  // Get customer activity history
  getActivityHistory: async () => {
    const response = await smileApiRequest('/customer/activities');
    return response.activities;
  },

  // Get customer referral code
  getReferralCode: async () => {
    const response = await smileApiRequest('/customer/referral');
    return response.referral;
  },

  // Apply a referral
  applyReferral: async (referralCode: string) => {
    const response = await smileApiRequest('/customer/referral/apply', 'POST', {
      referral: {
        code: referralCode
      }
    });
    return response.referral_application;
  },

  // Sync with our existing rewards system
  syncWithAppRewards: async (rockets: number) => {
    // Convert rockets to Smile points (example: 1 rocket = 10 Smile points)
    const pointsToAward = rockets * 10;
    
    try {
      const response = await smileApiRequest('/customer/points', 'POST', {
        points: {
          amount: pointsToAward,
          reason: 'Synced from My Lil Startup app rockets'
        }
      });
      return response.points_transaction;
    } catch (error) {
      console.error('Failed to sync rockets with Smile points:', error);
      throw error;
    }
  },

  // Clear customer session
  logout: async () => {
    await clearSmileCustomerToken();
  }
};

// Mock implementation for development/testing
if (process.env.NODE_ENV === 'development') {
  console.log('Using mock Smile.io API for development');
  
  // Mock data
  const mockCustomerData = {
    id: 'cust_123456',
    email: 'demo@example.com',
    first_name: 'Alex',
    last_name: 'Demo',
    points_balance: 1375,
    vip_tier: 'Silver',
    token: 'mock_smile_token_12345'
  };
  
  const mockRewards = [
    {
      id: 'reward_1',
      name: '$5 Off Your Next Purchase',
      description: 'Get $5 off your next purchase in the My Lil Startup store',
      points_cost: 500,
      is_available: true
    },
    {
      id: 'reward_2',
      name: 'Free Shipping',
      description: 'Free shipping on your next order',
      points_cost: 300,
      is_available: true
    },
    {
      id: 'reward_3',
      name: 'Exclusive Product Access',
      description: 'Early access to new products',
      points_cost: 1000,
      is_available: true
    },
    {
      id: 'reward_4',
      name: 'VIP Status Upgrade',
      description: 'Upgrade to Gold VIP status',
      points_cost: 2500,
      is_available: false
    }
  ];
  
  const mockActivities = [
    {
      id: 'activity_1',
      type: 'points_earned',
      points: 50,
      description: 'Purchase at My Lil Startup store',
      created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'activity_2',
      type: 'points_earned',
      points: 100,
      description: 'Completed weekly challenge',
      created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: 'activity_3',
      type: 'reward_redeemed',
      points: -300,
      description: 'Redeemed Free Shipping reward',
      created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString()
    }
  ];
  
  const mockReferral = {
    code: 'ALEX2024',
    url: 'https://mylilstartup.com/refer/ALEX2024',
    rewards: {
      referrer: '500 points',
      referee: '$5 off first purchase'
    }
  };
  
  // Override the API methods with mock implementations
  smileApi.initializeCustomer = async (email, firstName, lastName) => {
    await setSmileCustomerToken('mock_smile_token_12345');
    return {
      ...mockCustomerData,
      email: email || mockCustomerData.email,
      first_name: firstName || mockCustomerData.first_name,
      last_name: lastName || mockCustomerData.last_name
    };
  };
  
  smileApi.getCustomerProfile = async () => {
    return mockCustomerData;
  };
  
  smileApi.getPointsBalance = async () => {
    return mockCustomerData.points_balance;
  };
  
  smileApi.getCustomerRewards = async () => {
    return mockRewards.filter(reward => reward.is_available);
  };
  
  smileApi.getRewardsCatalog = async () => {
    return mockRewards;
  };
  
  smileApi.redeemReward = async (rewardId) => {
    const reward = mockRewards.find(r => r.id === rewardId);
    if (!reward) {
      throw new Error('Reward not found');
    }
    
    if (reward.points_cost > mockCustomerData.points_balance) {
      throw new Error('Not enough points to redeem this reward');
    }
    
    mockCustomerData.points_balance -= reward.points_cost;
    
    return {
      id: `redemption_${Date.now()}`,
      reward_id: rewardId,
      reward_name: reward.name,
      points_cost: reward.points_cost,
      created_at: new Date().toISOString()
    };
  };
  
  smileApi.awardPoints = async (points, reason) => {
    mockCustomerData.points_balance += points;
    
    const newActivity = {
      id: `activity_${Date.now()}`,
      type: 'points_earned',
      points,
      description: reason,
      created_at: new Date().toISOString()
    };
    
    mockActivities.unshift(newActivity);
    
    return {
      id: `transaction_${Date.now()}`,
      points,
      reason,
      created_at: new Date().toISOString()
    };
  };
  
  smileApi.recordPurchase = async (orderId, amount) => {
    // Calculate points (example: $1 = 10 points)
    const pointsEarned = Math.floor(amount * 10);
    mockCustomerData.points_balance += pointsEarned;
    
    const newActivity = {
      id: `activity_${Date.now()}`,
      type: 'purchase',
      points: pointsEarned,
      description: `Purchase #${orderId} - $${amount.toFixed(2)}`,
      created_at: new Date().toISOString()
    };
    
    mockActivities.unshift(newActivity);
    
    return {
      id: `purchase_${Date.now()}`,
      order_id: orderId,
      subtotal: amount,
      points_earned: pointsEarned,
      created_at: new Date().toISOString()
    };
  };
  
  smileApi.getActivityHistory = async () => {
    return mockActivities;
  };
  
  smileApi.getReferralCode = async () => {
    return mockReferral;
  };
  
  smileApi.applyReferral = async (referralCode) => {
    // Simulate applying a referral code
    if (referralCode === 'INVALID') {
      throw new Error('Invalid referral code');
    }
    
    // Award points for using a valid referral
    mockCustomerData.points_balance += 500;
    
    return {
      id: `referral_application_${Date.now()}`,
      referral_code: referralCode,
      points_awarded: 500,
      created_at: new Date().toISOString()
    };
  };
  
  smileApi.syncWithAppRewards = async (rockets) => {
    const pointsToAward = rockets * 10;
    mockCustomerData.points_balance += pointsToAward;
    
    return {
      id: `transaction_${Date.now()}`,
      points: pointsToAward,
      reason: 'Synced from My Lil Startup app rockets',
      created_at: new Date().toISOString()
    };
  };
}

export default {
  name: 'smile-api',
};