import { Platform } from 'react-native';

/**
 * Simulates speech recognition in Expo Go environment
 * In a real app with a development build, this would use actual speech recognition
 */
export const startSpeechToText = async (
  onResult: (text: string) => void,
  onSimulationMessage?: (message: string) => void
) => {
  console.log('Starting simulated speech recognition');
  
  // Show a simulation message to the user
  if (onSimulationMessage) {
    onSimulationMessage("Voice recognition requires a development build. Showing a simulation instead.");
  }
  
  // Show a simulated "listening" state for 2 seconds
  setTimeout(() => {
    // Provide a realistic simulated response
    const simulatedResponses = [
      "I want to sell lemonade",
      "How do I set my prices?",
      "Where's the best place to sell?",
      "How can I accept payments?",
      "What should I do if someone doesn't want to buy?",
      "How much money can I make?",
      "Can I sell online too?"
    ];
    
    const randomResponse = simulatedResponses[Math.floor(Math.random() * simulatedResponses.length)];
    console.log('Simulated speech recognition result:', randomResponse);
    onResult(randomResponse);
  }, 2000);
};

/**
 * Simulates stopping speech recognition
 */
export const stopSpeechToText = async () => {
  console.log('Stopping simulated speech recognition');
  // No actual implementation needed for simulation
};