// Mock API service for Express API
// In a real app, this would make actual HTTP requests to your backend

import { UserProfile } from '@/store/user-store';
import { Reward } from '@/constants/rewards';
import { Challenge, ChallengeResult } from '@/constants/challenges';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock user data
const mockUser: UserProfile = {
  id: 'user_1',
  name: 'John Doe',
  email: 'john.doe@example.com',
  phone: '+1 (555) 123-4567',
  avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=120&h=120&q=80',
  city: 'San Diego',
  state: 'CA',
  rockets: 1375,
  rocketsSpent: 250,
  totalSales: 12500,
  dailySales: 750,
  badges: ['first_sale', 'level_5', 'weekend_warrior'],
  goldenTickets: 1,
  referralCode: 'JOHNDOE25',
  referrals: 3,
  createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days ago
  updatedAt: new Date().toISOString(),
};

// User API
export const userApi = {
  // Get user profile
  getProfile: async (): Promise<UserProfile> => {
    await delay(500); // Simulate network delay
    return { ...mockUser };
  },
  
  // Update user profile
  updateProfile: async (data: Partial<UserProfile>): Promise<UserProfile> => {
    await delay(700); // Simulate network delay
    
    // In a real app, this would send the data to your backend
    return {
      ...mockUser,
      ...data,
      updatedAt: new Date().toISOString()
    };
  },
  
  // Get user's transaction history
  getTransactions: async () => {
    await delay(600); // Simulate network delay
    
    return {
      transactions: [
        {
          id: 'txn_1',
          type: 'earn',
          amount: 50,
          source: 'sale',
          description: 'Sale to Customer A',
          createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
        },
        {
          id: 'txn_2',
          type: 'spend',
          amount: 100,
          source: 'store',
          description: 'Discount on Product X',
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
        },
        {
          id: 'txn_3',
          type: 'earn',
          amount: 500,
          source: 'referral',
          description: 'Referral: Jane Smith',
          createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
        },
      ]
    };
  }
};

// Rewards API
export const rewardsApi = {
  // Get available rewards
  getRewards: async (): Promise<{ rewards: Reward[] }> => {
    await delay(500); // Simulate network delay
    
    return {
      rewards: [
        { id: 'reward_1', type: 'discount', value: 5, label: '$5 Off' },
        { id: 'reward_2', type: 'discount', value: 10, label: '$10 Off' },
        { id: 'reward_3', type: 'shipping', value: 'free', label: 'Free Shipping' },
        { id: 'reward_4', type: 'badge', value: 'special_badge', label: 'Special Badge' },
      ]
    };
  },
  
  // Redeem a reward
  redeemReward: async (rewardId: string): Promise<{ success: boolean; message: string }> => {
    await delay(700); // Simulate network delay
    
    // In a real app, this would actually redeem the reward
    return {
      success: true,
      message: 'Reward redeemed successfully'
    };
  },
  
  // Spin the wheel
  spinWheel: async (): Promise<{ reward: Reward }> => {
    await delay(1000); // Simulate network delay
    
    // In a real app, this would determine the reward based on probabilities
    const rewards = [
      { id: 'wheel_1', type: 'rockets', value: 10, label: '10 Rockets' },
      { id: 'wheel_2', type: 'rockets', value: 25, label: '25 Rockets' },
      { id: 'wheel_3', type: 'discount', value: 5, label: '$5 Off' },
      { id: 'wheel_4', type: 'shipping', value: 'free', label: 'Free Shipping' },
    ] as Reward[];
    
    const randomIndex = Math.floor(Math.random() * rewards.length);
    return { reward: rewards[randomIndex] };
  }
};

// Challenges API
export const challengesApi = {
  // Get challenges
  getChallenges: async (): Promise<{ challenges: Challenge[], results: ChallengeResult[] }> => {
    await delay(600); // Simulate network delay
    
    return {
      challenges: [],
      results: []
    };
  },
  
  // Create a challenge
  createChallenge: async (data: any): Promise<{ challenge: Challenge }> => {
    await delay(700); // Simulate network delay
    
    const challenge: Challenge = {
      id: `challenge_${Date.now()}`,
      challengerId: 'user_1',
      challengerName: 'You',
      opponentId: data.opponentId,
      opponentName: data.opponentName,
      wagerAmount: data.wagerAmount,
      startDate: data.startDate,
      endDate: data.endDate,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    
    return { challenge };
  },
  
  // Accept a challenge
  acceptChallenge: async (challengeId: string): Promise<{ success: boolean }> => {
    await delay(500); // Simulate network delay
    
    return { success: true };
  },
  
  // Decline a challenge
  declineChallenge: async (challengeId: string): Promise<{ success: boolean }> => {
    await delay(500); // Simulate network delay
    
    return { success: true };
  },
  
  // Complete a challenge
  completeChallenge: async (
    challengeId: string, 
    challengerSales: number, 
    opponentSales: number
  ): Promise<{ result: ChallengeResult }> => {
    await delay(800); // Simulate network delay
    
    // Determine winner
    const winnerId = challengerSales > opponentSales ? 'user_1' : 'opponent_1';
    const winnerName = winnerId === 'user_1' ? 'You' : 'Opponent';
    
    // Calculate total rockets won (both wagers)
    const totalRocketsWon = 100; // Example amount
    
    const result: ChallengeResult = {
      challengeId,
      winnerId,
      winnerName,
      totalRocketsWon,
      salesDifference: Math.abs(challengerSales - opponentSales)
    };
    
    return { result };
  }
};

// Sales API
export const salesApi = {
  // Get sales history
  getSalesHistory: async () => {
    await delay(600); // Simulate network delay
    
    return {
      sales: [
        {
          id: 'sale_1',
          amount: 125.99,
          customer: 'Jane Smith',
          item: 'Premium Widget',
          date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
          rocketsEarned: 63
        },
        {
          id: 'sale_2',
          amount: 49.99,
          customer: 'Bob Johnson',
          item: 'Basic Widget',
          date: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
          rocketsEarned: 25
        },
        {
          id: 'sale_3',
          amount: 199.99,
          customer: 'Alice Brown',
          item: 'Deluxe Widget',
          date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
          rocketsEarned: 100
        },
      ]
    };
  },
  
  // Process a sale
  processSale: async (data: any) => {
    await delay(800); // Simulate network delay
    
    // Calculate rockets earned (1 rocket per $2 in sales)
    const rocketsEarned = Math.floor(data.amount / 2);
    
    // 20% chance to earn bonus rockets
    const bonusRockets = Math.random() < 0.2 ? 5 : 0;
    
    return {
      success: true,
      sale: {
        id: `sale_${Date.now()}`,
        amount: data.amount,
        customer: data.customer,
        item: data.item,
        date: new Date().toISOString(),
        rocketsEarned: rocketsEarned + bonusRockets
      },
      rocketsEarned,
      bonusRockets
    };
  },
  
  // Refund a sale
  refundSale: async (saleId: string) => {
    await delay(700); // Simulate network delay
    
    return {
      success: true,
      message: 'Sale refunded successfully'
    };
  }
};