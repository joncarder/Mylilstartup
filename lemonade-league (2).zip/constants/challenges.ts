export interface Challenge {
  id: string;
  challengerId: string;
  challengerName: string;
  opponentId: string;
  opponentName: string;
  wagerAmount: number; // Rockets wagered by each participant (max 100)
  startDate: string; // ISO date string
  endDate: string; // ISO date string
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  challengerSales?: number;
  opponentSales?: number;
  winnerId?: string;
  createdAt: string;
}

export interface ChallengeResult {
  challengeId: string;
  winnerId: string;
  winnerName: string;
  totalRocketsWon: number;
  salesDifference: number;
}

// Maximum rockets that can be wagered in a challenge
export const MAX_CHALLENGE_WAGER = 100;

// Sample challenges for UI development
export const sampleChallenges: Challenge[] = [
  {
    id: 'challenge_1',
    challengerId: 'user_1',
    challengerName: 'You',
    opponentId: 'user_2',
    opponentName: 'Emma S.',
    wagerAmount: 50,
    startDate: new Date(Date.now() + 86400000).toISOString(), // Tomorrow
    endDate: new Date(Date.now() + 86400000 + 43200000).toISOString(), // Tomorrow + 12 hours
    status: 'pending',
    createdAt: new Date().toISOString()
  },
  {
    id: 'challenge_2',
    challengerId: 'user_3',
    challengerName: 'Lucas M.',
    opponentId: 'user_1',
    opponentName: 'You',
    wagerAmount: 75,
    startDate: new Date(Date.now() + 172800000).toISOString(), // Day after tomorrow
    endDate: new Date(Date.now() + 172800000 + 43200000).toISOString(), // Day after tomorrow + 12 hours
    status: 'pending',
    createdAt: new Date().toISOString()
  },
  {
    id: 'challenge_3',
    challengerId: 'user_1',
    challengerName: 'You',
    opponentId: 'user_4',
    opponentName: 'Sophia K.',
    wagerAmount: 100,
    startDate: new Date(Date.now() - 86400000).toISOString(), // Yesterday
    endDate: new Date(Date.now() - 43200000).toISOString(), // Yesterday + 12 hours
    status: 'completed',
    challengerSales: 45.50,
    opponentSales: 32.75,
    winnerId: 'user_1',
    createdAt: new Date(Date.now() - 172800000).toISOString()
  }
];