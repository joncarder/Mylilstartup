import { LeaderboardEntry } from '@/types/sales';

export interface CityChallenge {
  id: string;
  city1: City;
  city2: City;
  startDate: string;
  endDate: string;
  status: 'active' | 'completed';
  winnerId?: string;
}

export interface City {
  id: string;
  name: string;
  image: string;
  totalRockets: number;
  participants: CityParticipant[];
}

export interface CityParticipant {
  id: string;
  name: string;
  avatar: string;
  rockets: number;
}

// Sample city challenge data
export const currentCityChallenge: CityChallenge = {
  id: 'city_challenge_1',
  city1: {
    id: 'san_diego',
    name: 'San Diego',
    image: 'https://images.unsplash.com/photo-1538970272646-f61fabb3a8a2?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2FuJTIwZGllZ298ZW58MHx8MHx8fDA%3D',
    totalRockets: 2345,
    participants: [
      {
        id: 'user_1',
        name: 'You',
        avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=120&h=120&q=80',
        rockets: 250
      },
      {
        id: 'user_2',
        name: 'Alex M.',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&h=120&q=80',
        rockets: 196
      },
      {
        id: 'user_3',
        name: 'Jamie L.',
        avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=120&h=120&q=80',
        rockets: 175
      },
      {
        id: 'user_4',
        name: 'Taylor K.',
        avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&h=120&q=80',
        rockets: 150
      },
      {
        id: 'user_5',
        name: 'Jordan P.',
        avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=120&h=120&q=80',
        rockets: 131
      },
      {
        id: 'user_6',
        name: 'Morgan B.',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&q=80',
        rockets: 117
      },
      {
        id: 'user_7',
        name: 'Sam R.',
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&q=80',
        rockets: 104
      },
      {
        id: 'user_8',
        name: 'Casey T.',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&q=80',
        rockets: 97
      },
      {
        id: 'user_9',
        name: 'Drew H.',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
        rockets: 91
      },
      {
        id: 'user_10',
        name: 'Avery J.',
        avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=120&h=120&q=80',
        rockets: 84
      },
      {
        id: 'user_11',
        name: 'Robin S.',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
        rockets: 77
      },
      {
        id: 'user_12',
        name: 'Parker W.',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&q=80',
        rockets: 71
      },
      {
        id: 'user_13',
        name: 'Quinn N.',
        avatar: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=120&h=120&q=80',
        rockets: 64
      },
      {
        id: 'user_14',
        name: 'Riley F.',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&q=80',
        rockets: 57
      },
      {
        id: 'user_15',
        name: 'Blake D.',
        avatar: 'https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?w=120&h=120&q=80',
        rockets: 51
      }
    ]
  },
  city2: {
    id: 'san_francisco',
    name: 'San Francisco',
    image: 'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8c2FuJTIwZnJhbmNpc2NvfGVufDB8fDB8fHww',
    totalRockets: 2567,
    participants: [
      {
        id: 'sf_user_1',
        name: 'Riley S.',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
        rockets: 291
      },
      {
        id: 'sf_user_2',
        name: 'Casey T.',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
        rockets: 265
      },
      {
        id: 'sf_user_3',
        name: 'Morgan W.',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&q=80',
        rockets: 220
      },
      {
        id: 'sf_user_4',
        name: 'Avery J.',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&q=80',
        rockets: 191
      },
      {
        id: 'sf_user_5',
        name: 'Quinn R.',
        avatar: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=120&h=120&q=80',
        rockets: 170
      },
      {
        id: 'sf_user_6',
        name: 'Jordan B.',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&q=80',
        rockets: 157
      },
      {
        id: 'sf_user_7',
        name: 'Taylor P.',
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&q=80',
        rockets: 144
      },
      {
        id: 'sf_user_8',
        name: 'Alex M.',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&q=80',
        rockets: 137
      },
      {
        id: 'sf_user_9',
        name: 'Jamie L.',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
        rockets: 131
      },
      {
        id: 'sf_user_10',
        name: 'Drew H.',
        avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=120&h=120&q=80',
        rockets: 124
      },
      {
        id: 'sf_user_11',
        name: 'Robin S.',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
        rockets: 117
      },
      {
        id: 'sf_user_12',
        name: 'Parker W.',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&q=80',
        rockets: 111
      },
      {
        id: 'sf_user_13',
        name: 'Blake N.',
        avatar: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=120&h=120&q=80',
        rockets: 104
      },
      {
        id: 'sf_user_14',
        name: 'Sam F.',
        avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&q=80',
        rockets: 97
      },
      {
        id: 'sf_user_15',
        name: 'Morgan D.',
        avatar: 'https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?w=120&h=120&q=80',
        rockets: 91
      }
    ]
  },
  startDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
  endDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(), // 4 days from now
  status: 'active'
};

// Past city challenges
export const pastCityChallenges: CityChallenge[] = [
  {
    id: 'city_challenge_2',
    city1: {
      id: 'san_diego',
      name: 'San Diego',
      image: 'https://images.unsplash.com/photo-1538970272646-f61fabb3a8a2?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2FuJTIwZGllZ298ZW58MHx8MHx8fDA%3D',
      totalRockets: 2145,
      participants: []
    },
    city2: {
      id: 'los_angeles',
      name: 'Los Angeles',
      image: 'https://images.unsplash.com/photo-1580655653885-65763b2597d0?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8bG9zJTIwYW5nZWxlc3xlbnwwfHwwfHx8MA%3D%3D',
      totalRockets: 1987,
      participants: []
    },
    startDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days ago
    endDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days ago
    status: 'completed',
    winnerId: 'san_diego'
  },
  {
    id: 'city_challenge_3',
    city1: {
      id: 'san_diego',
      name: 'San Diego',
      image: 'https://images.unsplash.com/photo-1538970272646-f61fabb3a8a2?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2FuJTIwZGllZ298ZW58MHx8MHx8fDA%3D',
      totalRockets: 1845,
      participants: []
    },
    city2: {
      id: 'seattle',
      name: 'Seattle',
      image: 'https://images.unsplash.com/photo-1502175353174-a7a70e73b362?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8c2VhdHRsZXxlbnwwfHwwfHx8MA%3D%3D',
      totalRockets: 1925,
      participants: []
    },
    startDate: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(), // 21 days ago
    endDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days ago
    status: 'completed',
    winnerId: 'seattle'
  }
];