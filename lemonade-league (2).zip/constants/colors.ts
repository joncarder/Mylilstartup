export const colors = {
  primary: '#03FF9E', // Mint Green from brand
  secondary: '#AB75FF', // Purple from brand
  secondaryDark: '#8A5AE0', // Darker purple for contrast
  accent: '#0000FF', // Blue from brand
  background: '#FFFFFF',
  backgroundDark: '#00005E', // Dark Blue from brand
  text: '#000000',
  textLight: '#666666',
  success: '#03FF9E',
  warning: '#AB75FF',
  error: '#FF5252',
  card: '#F8F9FA',
  border: '#E5E5E5',
};