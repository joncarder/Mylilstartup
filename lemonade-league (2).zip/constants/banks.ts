export interface BankAccount {
  id: string;
  bankName: string;
  logoUrl: string;
  lastFourDigits: string;
  isDefault: boolean;
  accountType: 'checking' | 'savings';
}

export const linkedBankAccounts: BankAccount[] = [
  {
    id: 'bank_1',
    bankName: 'Chase',
    logoUrl: 'https://images.unsplash.com/photo-1629654297299-c8506221ca97?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8Y2hhc2UlMjBiYW5rfGVufDB8fDB8fHww',
    lastFourDigits: '4321',
    isDefault: true,
    accountType: 'checking'
  },
  {
    id: 'bank_2',
    bankName: 'Bank of America',
    logoUrl: 'https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YmFuayUyMG9mJTIwYW1lcmljYXxlbnwwfHwwfHx8MA%3D%3D',
    lastFourDigits: '8765',
    isDefault: false,
    accountType: 'savings'
  },
  {
    id: 'bank_3',
    bankName: 'Wells Fargo',
    logoUrl: 'https://images.unsplash.com/photo-1620912189865-1e8a33da4c5e?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8d2VsbHMlMjBmYXJnb3xlbnwwfHwwfHx8MA%3D%3D',
    lastFourDigits: '5432',
    isDefault: false,
    accountType: 'checking'
  }
];