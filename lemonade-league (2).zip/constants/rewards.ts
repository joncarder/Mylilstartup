export interface Reward {
  id: string;
  name: string;
  type: 'rockets' | 'discount' | 'shipping' | 'golden_ticket' | 'badge';
  value: number | string;
  label: string;
  chance?: number; // Percentage chance (for wheel rewards)
}

// Wheel rewards with probabilities (should sum to 100%)
export const wheelRewards: Reward[] = [
  {
    id: 'wheel_1',
    name: '5 Rockets',
    type: 'rockets',
    value: 5,
    label: '5',
    chance: 30
  },
  {
    id: 'wheel_2',
    name: '10 Rockets',
    type: 'rockets',
    value: 10,
    label: '10',
    chance: 25
  },
  {
    id: 'wheel_3',
    name: '15 Rockets',
    type: 'rockets',
    value: 15,
    label: '15',
    chance: 20
  },
  {
    id: 'wheel_4',
    name: '20 Rockets',
    type: 'rockets',
    value: 20,
    label: '20',
    chance: 15
  },
  {
    id: 'wheel_5',
    name: '25 Rockets',
    type: 'rockets',
    value: 25,
    label: '25',
    chance: 8
  },
  {
    id: 'wheel_6',
    name: 'Golden Ticket',
    type: 'golden_ticket',
    value: 1,
    label: '🎫',
    chance: 2
  }
];

// Competition rewards
export const competitionRewards = {
  // National competition rewards
  national: [
    { rank: 1, type: 'rockets', value: 2500, label: '2500 Rockets + Golden Ticket' },
    { rank: 2, type: 'rockets', value: 1000, label: '1000 Rockets' },
    { rank: 3, type: 'rockets', value: 500, label: '500 Rockets' },
    { rank: 4, type: 'rockets', value: 250, label: '250 Rockets' },
    { rank: 5, type: 'rockets', value: 100, label: '100 Rockets' }
  ],
  
  // Regional competition rewards
  regional: [
    { rank: 1, type: 'rockets', value: 1000, label: '1000 Rockets' },
    { rank: 2, type: 'rockets', value: 500, label: '500 Rockets' },
    { rank: 3, type: 'rockets', value: 250, label: '250 Rockets' }
  ],
  
  // City competition rewards
  city: [
    { rank: 1, type: 'rockets', value: 500, label: '500 Rockets' },
    { rank: 2, type: 'rockets', value: 250, label: '250 Rockets' },
    { rank: 3, type: 'rockets', value: 100, label: '100 Rockets' }
  ]
};

// City battle rewards
export const cityRewards = {
  firstPlace: 100, // Bonus rockets for each contributor in winning city
  secondPlace: 25, // Consolation rockets for each contributor in losing city
  topContributor: 200, // Additional bonus for top 3 contributors in each city
  participant: 10 // Minimum reward for any contributor (at least 1 rocket)
};

// Store rewards (what rockets can be redeemed for)
export const storeRewards: Reward[] = [
  {
    id: 'store_1',
    name: '$5 Off',
    type: 'discount',
    value: 5,
    label: '$5 Off Your Order'
  },
  {
    id: 'store_2',
    name: '$10 Off',
    type: 'discount',
    value: 10,
    label: '$10 Off Your Order'
  },
  {
    id: 'store_3',
    name: '$25 Off',
    type: 'discount',
    value: 25,
    label: '$25 Off Your Order'
  },
  {
    id: 'store_4',
    name: 'Free Shipping',
    type: 'shipping',
    value: 'free',
    label: 'Free Shipping'
  }
];