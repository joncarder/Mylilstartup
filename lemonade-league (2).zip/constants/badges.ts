export interface Badge {
  id: string;
  name: string;
  description: string;
  detailedDescription: string;
  icon: string;
  unlockedAt: number; // level required or 0 if not level-based
  type: 'achievement' | 'milestone' | 'special';
  category: 'sales' | 'social' | 'learning' | 'consistency' | 'special';
  requirement: string;
}

export const badges: Badge[] = [
  {
    id: 'first_sale',
    name: 'First Sip',
    description: 'Made your first sale!',
    detailedDescription: 'Every entrepreneur starts with a single sale. You\'ve taken your first step into the world of business!',
    icon: '🥤',
    unlockedAt: 1,
    type: 'milestone',
    category: 'sales',
    requirement: 'Complete your first sale transaction'
  },
  {
    id: 'weekend_warrior',
    name: 'Weekend Warrior',
    description: 'Sold lemonade for 3 weekends in a row',
    detailedDescription: 'Consistency is key in business! You\'ve shown dedication by selling on three consecutive weekends.',
    icon: '🏆',
    unlockedAt: 5,
    type: 'achievement',
    category: 'consistency',
    requirement: 'Record sales on 3 consecutive weekends'
  },
  {
    id: 'local_legend',
    name: 'Local Legend',
    description: 'Top seller in your city',
    detailedDescription: 'Your reputation is growing! You\'ve become the #1 seller in your city for a week.',
    icon: '👑',
    unlockedAt: 10,
    type: 'special',
    category: 'sales',
    requirement: 'Reach #1 on your city\'s weekly leaderboard'
  },
  {
    id: 'master_mixer',
    name: 'Master Mixer',
    description: 'Created 5 different lemonade recipes',
    detailedDescription: 'Innovation drives business growth! You\'ve created 5 unique product variations to delight your customers.',
    icon: '🍋',
    unlockedAt: 15,
    type: 'achievement',
    category: 'learning',
    requirement: 'Add 5 different product variations to your inventory'
  },
  {
    id: 'super_seller',
    name: 'Super Seller',
    description: 'Made 100 sales',
    detailedDescription: 'Triple digits! You\'ve completed 100 individual sales transactions. That\'s a lot of happy customers!',
    icon: '⭐️',
    unlockedAt: 20,
    type: 'milestone',
    category: 'sales',
    requirement: 'Complete 100 sales transactions'
  },
  {
    id: 'money_maker',
    name: 'Money Maker',
    description: 'Earned $500 in total sales',
    detailedDescription: 'You\'ve hit the $500 mark in total sales! Your business is really taking off now.',
    icon: '💰',
    unlockedAt: 25,
    type: 'milestone',
    category: 'sales',
    requirement: 'Reach $500 in total sales'
  },
  {
    id: 'customer_favorite',
    name: 'Customer Favorite',
    description: 'Got 50 five-star ratings',
    detailedDescription: 'Your customers love you! You\'ve received 50 five-star ratings for your excellent service and products.',
    icon: '❤️',
    unlockedAt: 30,
    type: 'achievement',
    category: 'social',
    requirement: 'Receive 50 five-star ratings from customers'
  },
  {
    id: 'business_guru',
    name: 'Business Guru',
    description: 'Reached level 50',
    detailedDescription: 'You\'ve reached the highest level! You\'re now a true business guru with all the skills of a seasoned entrepreneur.',
    icon: '🌟',
    unlockedAt: 50,
    type: 'special',
    category: 'special',
    requirement: 'Reach Level 50'
  },
  {
    id: 'digital_pioneer',
    name: 'Digital Pioneer',
    description: 'Accepted 10 digital payments',
    detailedDescription: 'You\'ve embraced modern technology by accepting 10 digital payments through Apple Pay or other digital methods.',
    icon: '📱',
    unlockedAt: 0,
    type: 'achievement',
    category: 'learning',
    requirement: 'Accept 10 payments through digital methods'
  },
  {
    id: 'social_butterfly',
    name: 'Social Butterfly',
    description: 'Referred 5 friends to the app',
    detailedDescription: 'Your network is growing! You\'ve successfully referred 5 friends who have joined My Lil Startup.',
    icon: '🦋',
    unlockedAt: 0,
    type: 'achievement',
    category: 'social',
    requirement: 'Refer 5 friends who join My Lil Startup'
  },
  {
    id: 'golden_ticket_winner',
    name: 'Golden Ticket Winner',
    description: 'Won a Golden Ticket',
    detailedDescription: 'Lucky you! You\'ve won a Golden Ticket that can be redeemed for a free item from the My Lil Startup store.',
    icon: '🎫',
    unlockedAt: 0,
    type: 'special',
    category: 'special',
    requirement: 'Win a Golden Ticket from the prize wheel or competition'
  },
  {
    id: 'challenge_champion',
    name: 'Challenge Champion',
    description: 'Won 5 kid vs. kid challenges',
    detailedDescription: 'You\'re a competitive force! You\'ve won 5 challenges against other kidpreneurs.',
    icon: '🏅',
    unlockedAt: 0,
    type: 'achievement',
    category: 'social',
    requirement: 'Win 5 challenges against other users'
  },
  {
    id: 'location_scout',
    name: 'Location Scout',
    description: 'Sold in 5 different locations',
    detailedDescription: 'You know where the customers are! You\'ve successfully sold your products in 5 different locations.',
    icon: '🗺️',
    unlockedAt: 0,
    type: 'achievement',
    category: 'learning',
    requirement: 'Record sales in 5 different locations'
  },
  {
    id: 'consistent_earner',
    name: 'Consistent Earner',
    description: 'Made sales for 30 consecutive days',
    detailedDescription: 'Your dedication is impressive! You\'ve recorded sales every day for a full month.',
    icon: '📆',
    unlockedAt: 0,
    type: 'achievement',
    category: 'consistency',
    requirement: 'Record at least one sale every day for 30 consecutive days'
  },
  {
    id: 'national_champion',
    name: 'National Champion',
    description: 'Ranked #1 nationwide for a week',
    detailedDescription: 'You\'re the best in the country! You\'ve reached the #1 position on the national leaderboard for a full week.',
    icon: '🏆',
    unlockedAt: 0,
    type: 'special',
    category: 'special',
    requirement: 'Reach #1 on the nationwide leaderboard for one week'
  }
];