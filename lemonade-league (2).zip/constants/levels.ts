export interface Level {
  level: number;
  title: string;
  salesRequired: number;
  rocketsRequired: number;
  reward?: {
    type: 'spin' | 'golden_ticket' | 'badge' | 'special';
    value: string | number;
    description: string;
  };
}

// Thematic level groupings
const LEVEL_THEMES = [
  'Intern',        // 1-5
  'Assistant',     // 6-10
  'Manager',       // 11-15
  'Director',      // 16-20
  'Vice President', // 21-25
  'President',     // 26-30
  'CEO',           // 31-35
  'Founder',       // 36-40
  'Visionary',     // 41-45
  'Empire Builder' // 46-50
];

// Generate levels based on the requirements
export const levels: Level[] = Array.from({ length: 50 }, (_, i) => {
  const level = i + 1;
  const themeIndex = Math.floor((level - 1) / 5);
  const theme = LEVEL_THEMES[themeIndex];
  
  // Calculate sales required based on level range
  let salesRequired = 0;
  if (level <= 10) salesRequired = level * 100;
  else if (level <= 20) salesRequired = 1000 + (level - 10) * 200;
  else if (level <= 30) salesRequired = 3000 + (level - 20) * 300;
  else if (level <= 40) salesRequired = 6000 + (level - 30) * 400;
  else salesRequired = 10000 + (level - 40) * 500;
  
  // Rockets required (1 rocket per $2 in sales)
  const rocketsRequired = salesRequired / 2;
  
  // Special rewards for milestone levels
  let reward = {
    type: 'spin' as const,
    value: 'standard',
    description: 'Spin the wheel for a chance to win rockets!'
  };
  
  // Enhanced rewards for milestone levels (10, 20, 30, 40, 50)
  if (level % 10 === 0) {
    reward = {
      type: 'golden_ticket' as const,
      value: 'chance',
      description: 'Enhanced chance to win a Golden Ticket!'
    };
  }
  
  return {
    level,
    title: `${theme} ${level}`,
    salesRequired,
    rocketsRequired,
    reward
  };
});

/**
 * Calculate user level based on rockets
 * @param rockets User's current rockets
 * @returns Object containing level, progress to next level, and title
 */
export const calculateLevel = (rockets: number): { 
  level: number; 
  progress: number; 
  title: string;
  nextLevelRockets: number;
} => {
  let currentLevel = 0;
  let nextLevelRockets = 0;
  
  for (let i = 0; i < levels.length; i++) {
    if (rockets >= levels[i].rocketsRequired) {
      currentLevel = i + 1;
    } else {
      const prevRockets = i > 0 ? levels[i - 1].rocketsRequired : 0;
      nextLevelRockets = levels[i].rocketsRequired;
      const progress = (rockets - prevRockets) / (levels[i].rocketsRequired - prevRockets);
      return { 
        level: currentLevel, 
        progress, 
        title: levels[currentLevel - 1]?.title || 'Intern 1',
        nextLevelRockets
      };
    }
  }
  
  // Max level reached
  return { 
    level: 50, 
    progress: 1, 
    title: 'Empire Builder 50',
    nextLevelRockets: levels[49].rocketsRequired
  };
};

/**
 * Get the level for a given number of rockets
 * @param rockets User's current rockets
 * @returns The user's level
 */
export const getLevelForRockets = (rockets: number): number => {
  let level = 1;
  
  for (let i = 0; i < levels.length; i++) {
    if (rockets >= levels[i].rocketsRequired) {
      level = i + 1;
    } else {
      break;
    }
  }
  
  return level;
};

/**
 * Get the progress towards the next level
 * @param rockets User's current rockets
 * @returns Progress as a number between 0 and 1
 */
export const getLevelProgress = (rockets: number): number => {
  const level = getLevelForRockets(rockets);
  
  // If max level, return 1
  if (level >= levels.length) {
    return 1;
  }
  
  // Calculate progress to next level
  const currentLevelRockets = level > 1 ? levels[level - 2].rocketsRequired : 0;
  const nextLevelRockets = levels[level - 1].rocketsRequired;
  
  return (rockets - currentLevelRockets) / (nextLevelRockets - currentLevelRockets);
};