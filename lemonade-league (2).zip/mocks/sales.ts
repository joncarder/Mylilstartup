import { GlobalSale } from '@/components/GlobalSaleItem';

// Generate sample global sales data
export const generateMockSales = (): GlobalSale[] => {
  const cities = ['San Francisco', 'New York', 'Chicago', 'Los Angeles', 'Miami', 'Seattle', 'Austin', 'Boston'];
  const names = ['Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Jackson', 'Sophia', 'Lucas', 'Isabella', 'Mason'];
  const products = ['Lemonade', 'Cookies', 'Bracelets', 'Slime', 'Keychains', 'Cupcakes', 'Bookmarks', 'Paintings'];
  const avatars = [
    'https://images.unsplash.com/photo-1491013516836-7db643ee125a?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&h=120&q=80'
  ];
  
  const sales: GlobalSale[] = [];
  const now = Date.now();
  
  // Generate 20 sample sales with unique IDs
  for (let i = 0; i < 20; i++) {
    const minutesAgo = Math.floor(Math.random() * 60 * 24); // Random time in the last 24 hours
    const date = new Date(now - (minutesAgo * 60 * 1000));
    const amount = Math.round((Math.random() * 15 + 2) * 100) / 100; // $2.00 - $17.00
    const highFives = Math.floor(Math.random() * 15);
    
    // Ensure unique IDs by using timestamp + random number + index to avoid collisions
    const uniqueId = `global_sale_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`;
    
    sales.push({
      id: uniqueId,
      userId: `user_${i}`,
      userName: names[Math.floor(Math.random() * names.length)],
      userAvatar: avatars[Math.floor(Math.random() * avatars.length)],
      city: cities[Math.floor(Math.random() * cities.length)],
      product: products[Math.floor(Math.random() * products.length)],
      amount,
      date: date.toISOString(),
      highFives,
      hasGivenHighFive: false
    });
  }
  
  // Sort by date, newest first
  return sales.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};