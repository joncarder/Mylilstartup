import React from 'react';
import { View, Image, StyleSheet, Dimensions, Text } from 'react-native';
import OnboardingLayout from '@/components/OnboardingLayout';

const { width } = Dimensions.get('window');

export default function OnboardingChallenges() {
  return (
    <OnboardingLayout
      title="1v1 Challenges"
      description="Challenge your friends to 1v1 money-earning competitions and win bonus rockets!"
      currentStep={5}
      totalSteps={6}
      nextScreen="/auth/onboarding-coach"
    >
      <View style={styles.imageContainer}>
        <View style={styles.challengeCard}>
          <View style={styles.challengeHeader}>
            <Text style={styles.challengeTitle}>Rocket Challenge</Text>
            <Text style={styles.challengeSubtitle}>Who can earn the most in 1 day?</Text>
          </View>
          
          <View style={styles.vsContainer}>
            <View style={styles.playerContainer}>
              <Image
                source={{ uri: 'https://images.unsplash.com/photo-1491308056676-205b7c9a7dc1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
                style={styles.playerAvatar}
              />
              <Text style={styles.playerName}>Alex</Text>
              <Text style={styles.playerScore}>24 🚀</Text>
            </View>
            
            <View style={styles.vsCircle}>
              <Text style={styles.vsText}>VS</Text>
            </View>
            
            <View style={styles.playerContainer}>
              <Image
                source={{ uri: 'https://images.unsplash.com/photo-1490138139357-fc819d02e344?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
                style={styles.playerAvatar}
              />
              <Text style={styles.playerName}>Jamie</Text>
              <Text style={styles.playerScore}>19 🚀</Text>
            </View>
          </View>
          
          <View style={styles.challengeFooter}>
            <Text style={styles.timeRemaining}>4 hours 35 minutes remaining</Text>
            <View style={styles.progressBar}>
              <View style={styles.progressFill}></View>
            </View>
          </View>
        </View>
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  imageContainer: {
    width: width * 0.9,
    height: width * 0.8,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#6366F1',
  },
  challengeCard: {
    width: '100%',
    height: '100%',
    backgroundColor: '#F8FAFC',
    padding: 16,
    justifyContent: 'space-between',
  },
  challengeHeader: {
    alignItems: 'center',
  },
  challengeTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  challengeSubtitle: {
    fontSize: 14,
    color: '#64748B',
  },
  vsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginVertical: 16,
  },
  playerContainer: {
    alignItems: 'center',
  },
  playerAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: '#6366F1',
  },
  playerName: {
    marginTop: 8,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  playerScore: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#6366F1',
  },
  vsCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#6366F1',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vsText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
  },
  challengeFooter: {
    marginTop: 16,
  },
  timeRemaining: {
    fontSize: 14,
    color: '#64748B',
    textAlign: 'center',
    marginBottom: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E2E8F0',
    borderRadius: 4,
  },
  progressFill: {
    width: '60%',
    height: '100%',
    backgroundColor: '#6366F1',
    borderRadius: 4,
  }
});