import React from 'react';
import { View, Image, StyleSheet, Dimensions, Text } from 'react-native';
import OnboardingLayout from '@/components/OnboardingLayout';
import { colors } from '@/constants/colors';

const { width } = Dimensions.get('window');

export default function OnboardingCoach() {
  return (
    <OnboardingLayout
      title="Meet Coach Cash"
      description="Your personal mentor who helps you earn as much money as possible as a kidpreneur!"
      currentStep={6}
      totalSteps={6}
      nextScreen="/auth/signup"
      buttonText="Let's Get Started"
      showSkip={false}
    >
      <View style={styles.container}>
        <View style={styles.imageContainer}>
          <Image
            // Using a Wall-E like robot image
            source={{ uri: 'https://images.unsplash.com/photo-1589254065878-42c9da997008?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
            style={styles.image}
            resizeMode="cover"
          />
        </View>
        <View style={styles.speechBubble}>
          <Text style={styles.speechText}>
            "I'll help you build your business and make money like a pro!"
          </Text>
          <View style={styles.speechTail}></View>
        </View>
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    position: 'relative',
  },
  imageContainer: {
    width: width * 0.7,
    height: width * 0.7,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: width * 0.35,
    overflow: 'hidden',
    borderWidth: 3,
    borderColor: colors.primary,
    backgroundColor: colors.background,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  speechBubble: {
    backgroundColor: colors.primary,
    borderRadius: 16,
    padding: 16,
    maxWidth: width * 0.8,
    marginTop: 20,
    position: 'relative',
  },
  speechText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 22,
  },
  speechTail: {
    position: 'absolute',
    top: -15,
    left: '50%',
    marginLeft: -15,
    borderLeftWidth: 15,
    borderRightWidth: 15,
    borderBottomWidth: 15,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: colors.primary,
  }
});