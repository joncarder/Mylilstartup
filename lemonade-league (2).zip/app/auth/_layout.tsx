import { Stack } from 'expo-router';
import { useEffect } from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { View, StyleSheet } from 'react-native';
import { useAuthStore } from '@/store/auth-store';
import { useSmileRewardsStore } from '@/store/smile-rewards-store';

export default function AuthLayout() {
  const { user } = useAuthStore();
  const { initializeSmileCustomer } = useSmileRewardsStore();
  
  // Initialize Smile rewards when user signs up or logs in
  useEffect(() => {
    if (user) {
      // Initialize Smile rewards with user data
      initializeSmileCustomer(user.email, user.displayName);
    }
  }, [user]);
  
  return (
    <GestureHandlerRootView style={styles.container}>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="login" />
        <Stack.Screen name="signup" />
        <Stack.Screen name="reset-password" />
        <Stack.Screen name="onboarding-coach" />
        <Stack.Screen name="onboarding-rewards" />
        <Stack.Screen name="onboarding-levels" />
        <Stack.Screen name="onboarding-challenges" />
        <Stack.Screen name="onboarding-competitions" />
        <Stack.Screen name="onboarding-payments" />
      </Stack>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});