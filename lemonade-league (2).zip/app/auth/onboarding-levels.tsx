import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions, Text, Platform } from 'react-native';
import OnboardingLayout from '@/components/OnboardingLayout';
import SpinWheel from '@/components/SpinWheel';
import { wheelRewards } from '@/constants/rewards';
import { colors } from '@/constants/colors';

const { width } = Dimensions.get('window');

export default function OnboardingLevels() {
  const [rewardIndex, setRewardIndex] = useState<number | null>(null);
  const [autoSpin, setAutoSpin] = useState(false);
  const wheelRef = useRef<any>(null);
  
  // For onboarding, we'll always show the first reward (5 rockets)
  const DEMO_REWARD_INDEX = 0;
  
  useEffect(() => {
    // Auto spin after a short delay for demo purposes
    const timer = setTimeout(() => {
      setAutoSpin(true);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleRewardSelected = (index: number) => {
    console.log("Reward selected:", index, wheelRewards[index].name);
    setRewardIndex(index);
  };
  
  // Use a simpler wheel for web to avoid stack overflow
  if (Platform.OS === 'web') {
    return (
      <OnboardingLayout
        title="Level Up & Earn Rewards"
        description="Every time you reach a new level, you get to spin the wheel to win rockets or even a golden ticket!"
        currentStep={3}
        totalSteps={6}
        nextScreen="/auth/onboarding-competitions"
      >
        <View style={styles.container}>
          <View style={styles.webWheelContainer}>
            <View style={styles.webWheel}>
              {wheelRewards.map((reward, index) => (
                <View 
                  key={reward.id}
                  style={[
                    styles.webSegment,
                    {
                      transform: [{ rotate: `${index * (360 / wheelRewards.length)}deg` }],
                      backgroundColor: index % 2 === 0 ? colors.primary + '80' : colors.secondary + '80',
                    }
                  ]}
                >
                  <Text style={styles.webSegmentText}>{reward.name}</Text>
                </View>
              ))}
              <View style={styles.webCenterPin}>
                <Text style={styles.webCenterText}>SPIN</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>
              You won: {wheelRewards[0].name}!
            </Text>
          </View>
        </View>
      </OnboardingLayout>
    );
  }
  
  return (
    <OnboardingLayout
      title="Level Up & Earn Rewards"
      description="Every time you reach a new level, you get to spin the wheel to win rockets or even a golden ticket!"
      currentStep={3}
      totalSteps={6}
      nextScreen="/auth/onboarding-competitions"
    >
      <View style={styles.container}>
        <View style={styles.wheelContainer}>
          <SpinWheel 
            ref={wheelRef}
            onSpin={() => {}} 
            onRewardSelected={handleRewardSelected} 
            spinsAvailable={1}
            demoMode={true}
            autoSpin={autoSpin}
            fixedRewardIndex={DEMO_REWARD_INDEX} // Force it to always land on 5 rockets for demo
          />
        </View>
        
        {rewardIndex !== null && (
          <View style={styles.resultContainer}>
            <Text style={styles.resultText}>
              You won: {wheelRewards[rewardIndex].name}!
            </Text>
          </View>
        )}
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    width: width * 0.9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  wheelContainer: {
    transform: [{ scale: 0.9 }],
  },
  resultContainer: {
    marginTop: 20,
    padding: 15,
    backgroundColor: colors.primary + '20',
    borderRadius: 10,
    width: '80%',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
    textAlign: 'center',
  },
  // Web-specific styles
  webWheelContainer: {
    width: 280,
    height: 280,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
  },
  webWheel: {
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: colors.card,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 2,
    borderColor: colors.border,
  },
  webSegment: {
    position: 'absolute',
    width: '50%',
    height: '50%',
    left: '50%',
    top: 0,
    transformOrigin: 'bottom left',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: 10,
  },
  webSegmentText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.background,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 10,
    marginTop: 15,
    overflow: 'hidden',
  },
  webCenterPin: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.border,
    zIndex: 10,
    left: '50%',
    top: '50%',
    marginLeft: -25,
    marginTop: -25,
  },
  webCenterText: {
    color: colors.background,
    fontWeight: 'bold',
  }
});