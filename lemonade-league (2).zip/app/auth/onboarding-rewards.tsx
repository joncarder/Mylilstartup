import React from 'react';
import { View, Image, StyleSheet, Dimensions } from 'react-native';
import OnboardingLayout from '@/components/OnboardingLayout';

const { width } = Dimensions.get('window');

export default function OnboardingRewards() {
  return (
    <OnboardingLayout
      title="Earn Rockets"
      description="Complete tasks to earn rockets. Use rockets to unlock special features and rewards!"
      currentStep={2}
      totalSteps={6}
      nextScreen="/auth/onboarding-levels"
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1636819488524-1f019c4e1c44?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
          style={styles.image}
          resizeMode="contain"
        />
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  imageContainer: {
    width: width * 0.8,
    height: width * 0.8,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#6366F1',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});