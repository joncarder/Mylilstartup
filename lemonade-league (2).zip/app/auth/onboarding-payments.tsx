import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import OnboardingLayout from '@/components/OnboardingLayout';

const { width } = Dimensions.get('window');

export default function OnboardingPaymentsScreen() {
  return (
    <OnboardingLayout
      title="Accept Payments Anywhere!"
      description="Now you can accept debit, credit cards, Apple Pay and Google Pay when selling your products. Just tap a card to your phone and get paid instantly!"
      currentStep={1}
      totalSteps={6}
      nextScreen="/auth/onboarding-rewards"
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=1000&auto=format&fit=crop' }}
          style={styles.image}
          contentFit="cover"
        />
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  imageContainer: {
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#6366F1',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});