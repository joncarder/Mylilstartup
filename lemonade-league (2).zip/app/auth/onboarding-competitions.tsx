import React from 'react';
import { View, Image, StyleSheet, Dimensions, Text } from 'react-native';
import OnboardingLayout from '@/components/OnboardingLayout';
import { Trophy } from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function OnboardingCompetitions() {
  return (
    <OnboardingLayout
      title="Weekly Competitions"
      description="Compete with other kids in weekly saving challenges to win rockets and climb the leaderboard!"
      currentStep={4}
      totalSteps={6}
      nextScreen="/auth/onboarding-challenges"
    >
      <View style={styles.imageContainer}>
        <View style={styles.leaderboardContainer}>
          <View style={styles.podiumContainer}>
            <View style={styles.podiumItem}>
              <View style={styles.avatarContainer}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
                  style={styles.avatar}
                />
              </View>
              <View style={[styles.podiumPlatform, styles.secondPlace]}>
                <Text style={styles.podiumText}>2nd</Text>
              </View>
            </View>
            
            <View style={styles.podiumItem}>
              <View style={styles.avatarContainer}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
                  style={styles.avatar}
                />
                <View style={styles.trophyContainer}>
                  <Trophy size={24} color="#FFD700" />
                </View>
              </View>
              <View style={[styles.podiumPlatform, styles.firstPlace]}>
                <Text style={styles.podiumText}>1st</Text>
              </View>
            </View>
            
            <View style={styles.podiumItem}>
              <View style={styles.avatarContainer}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80' }}
                  style={styles.avatar}
                />
              </View>
              <View style={[styles.podiumPlatform, styles.thirdPlace]}>
                <Text style={styles.podiumText}>3rd</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.leaderboardHeader}>
            <Text style={styles.leaderboardTitle}>Weekly Leaderboard</Text>
            <Text style={styles.leaderboardSubtitle}>Most Rockets Earned</Text>
          </View>
        </View>
      </View>
    </OnboardingLayout>
  );
}

const styles = StyleSheet.create({
  imageContainer: {
    width: width * 0.9,
    height: width * 0.8,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#6366F1',
    backgroundColor: '#F8FAFC',
  },
  leaderboardContainer: {
    width: '100%',
    height: '100%',
    padding: 16,
    justifyContent: 'space-between',
  },
  leaderboardHeader: {
    alignItems: 'center',
    marginBottom: 16,
  },
  leaderboardTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E293B',
  },
  leaderboardSubtitle: {
    fontSize: 14,
    color: '#64748B',
  },
  podiumContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
    height: '70%',
  },
  podiumItem: {
    alignItems: 'center',
    marginHorizontal: 8,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 8,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: 'white',
  },
  trophyContainer: {
    position: 'absolute',
    top: -10,
    right: -10,
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 2,
    borderWidth: 1,
    borderColor: '#FFD700',
  },
  podiumPlatform: {
    width: 70,
    alignItems: 'center',
    justifyContent: 'center',
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  firstPlace: {
    height: 80,
    backgroundColor: '#FFD700',
  },
  secondPlace: {
    height: 60,
    backgroundColor: '#C0C0C0',
  },
  thirdPlace: {
    height: 40,
    backgroundColor: '#CD7F32',
  },
  podiumText: {
    fontWeight: 'bold',
    color: '#1E293B',
  }
});