import { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Modal,
  TextInput,
  Alert,
  Platform,
  ActivityIndicator,
  RefreshControl,
  FlatList,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  DollarSign, 
  TrendingUp, 
  Rocket, 
  X, 
  CreditCard, 
  Smartphone, 
  Plus, 
  Minus, 
  Check, 
  Tag, 
  Info, 
  Share2,
  Coins,
  Filter,
  Globe,
  MapPin,
  Calendar,
  ArrowLeft,
  AlertTriangle,
  Search,
  Flame
} from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { useUserStore } from '@/store/user-store';
import { useGlobalSalesStore } from '@/store/global-sales-store';
import ConfettiAnimation from '@/components/ConfettiAnimation';
import MoneyMouthIcon from '@/components/MoneyMouthIcon';
import SimpleConfetti from '@/components/SimpleConfetti';
import GlobalSaleItem from '@/components/GlobalSaleItem';
import SalesHistoryItem from '@/components/SalesHistoryItem';

export default function SalesScreen() {
  const { 
    profile, 
    sales, 
    getLevelInfo, 
    getRocketsToNextLevel,
    addSale,
    refundSale
  } = useUserStore();
  
  const {
    sales: globalSales,
    isLoading: isLoadingGlobalSales,
    filter: salesFilter,
    setFilter: setSalesFilter,
    fetchGlobalSales,
    giveHighFive
  } = useGlobalSalesStore();
  
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [showRocketsInfoModal, setShowRocketsInfoModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showSalesHistoryModal, setShowSalesHistoryModal] = useState(false);
  const [showRefundConfirmModal, setShowRefundConfirmModal] = useState(false);
  const [showStreakInfoModal, setShowStreakInfoModal] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [processingPayment, setProcessingPayment] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [lastSaleAmount, setLastSaleAmount] = useState(0);
  const [rocketsEarned, setRocketsEarned] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [salesHistoryPage, setSalesHistoryPage] = useState(1);
  const [isLoadingMoreSales, setIsLoadingMoreSales] = useState(false);
  const [selectedSaleForRefund, setSelectedSaleForRefund] = useState(null);
  const [processingRefund, setProcessingRefund] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Payment method state
  const [paymentMethod, setPaymentMethod] = useState('electronic'); // 'electronic' or 'cash'
  const [cashReceived, setCashReceived] = useState('');
  
  // New product form state
  const [newProductName, setNewProductName] = useState('');
  const [newProductPrice, setNewProductPrice] = useState('');
  const [productOptions, setProductOptions] = useState([
    { id: '1', name: 'Lemonade', price: 2 },
    { id: '2', name: 'Slime', price: 5 },
    { id: '3', name: 'Cookies', price: 2 },
  ]);
  
  // Set initial selected product
  useEffect(() => {
    if (productOptions.length > 0 && !selectedProduct) {
      setSelectedProduct(productOptions[0].name);
    }
  }, [productOptions, selectedProduct]);
  
  // Fetch global sales on mount
  useEffect(() => {
    fetchGlobalSales();
  }, [fetchGlobalSales]);
  
  const { level, progress, title } = getLevelInfo();
  const rocketsToNextLevel = getRocketsToNextLevel();
  
  // Get selected product price
  const getProductPrice = () => {
    const product = productOptions.find(p => p.name === selectedProduct);
    return product ? product.price : 0;
  };
  
  // Calculate total amount
  const calculateTotal = () => {
    return (getProductPrice() * quantity).toFixed(2);
  };
  
  // Calculate change for cash payments
  const calculateChange = () => {
    const total = parseFloat(calculateTotal());
    const received = parseFloat(cashReceived);
    
    if (isNaN(received) || received < total) {
      return '0.00';
    }
    
    return (received - total).toFixed(2);
  };
  
  // Get today's sales
  const today = new Date().toISOString().split('T')[0];
  const todaySales = sales
    .filter(sale => sale.date.startsWith(today) && !sale.refunded)
    .reduce((sum, sale) => sum + sale.amount, 0);
  
  // Get today's sales count
  const todaySalesCount = sales
    .filter(sale => sale.date.startsWith(today) && !sale.refunded)
    .length;
  
  // Calculate rockets earned today
  const rocketsEarnedToday = Math.floor(todaySales / 2);
  
  // Handle payment reception
  const handleReceivePayment = () => {
    setShowPaymentModal(true);
    setQuantity(1);
    setPaymentMethod('electronic');
    setCashReceived('');
    if (productOptions.length > 0) {
      setSelectedProduct(productOptions[0].name);
    }
  };

  const handleCloseModal = () => {
    setShowPaymentModal(false);
    setPaymentAmount('');
    setProcessingPayment(false);
    setCashReceived('');
  };

  const handleCloseSuccessModal = () => {
    setShowSuccessModal(false);
    setShowConfetti(false);
  };

  const handleProcessPayment = () => {
    // Get amount from product and quantity
    const amount = parseFloat(calculateTotal());
    
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid payment amount.');
      return;
    }

    // For cash payments, validate cash received
    if (paymentMethod === 'cash') {
      const received = parseFloat(cashReceived);
      if (isNaN(received) || received < amount) {
        Alert.alert('Invalid Cash Amount', 'Please enter a valid cash amount that covers the total.');
        return;
      }
    }

    // Simulate payment processing
    setProcessingPayment(true);
    
    // Simulate a delay for the payment process
    setTimeout(() => {
      // Add the sale with payment method
      const paymentMethodName = paymentMethod === 'electronic' ? 'Electronic Payment' : 'Cash Payment';
      const sale = addSale(amount, paymentMethodName, selectedProduct);
      
      // Calculate rockets earned (only for electronic payments)
      let rockets = 0;
      let bonusRockets = 0;
      
      if (paymentMethod === 'electronic') {
        // 1 rocket per $2
        rockets = Math.floor(amount / 2);
        bonusRockets = sale.rewardEarned ? 5 : 0;
      }
      
      const totalRocketsEarned = rockets + bonusRockets;
      
      setLastSaleAmount(amount);
      setRocketsEarned(totalRocketsEarned);
      
      // Close payment modal and show success modal with confetti
      setShowPaymentModal(false);
      setProcessingPayment(false);
      setShowSuccessModal(true);
      
      // Only show confetti for electronic payments that earn rockets
      if (paymentMethod === 'electronic') {
        setShowConfetti(true);
      }
      
      // Refresh global sales to include the new sale
      fetchGlobalSales();
    }, 1500);
  };

  const handleIncreaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const handleDecreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const handleAddProduct = () => {
    // Validate inputs
    if (!newProductName.trim()) {
      Alert.alert('Missing Information', 'Please enter a product name.');
      return;
    }

    const price = parseFloat(newProductPrice);
    if (isNaN(price) || price <= 0) {
      Alert.alert('Invalid Price', 'Please enter a valid price greater than 0.');
      return;
    }

    // Check if product name already exists
    if (productOptions.some(p => p.name.toLowerCase() === newProductName.trim().toLowerCase())) {
      Alert.alert('Duplicate Product', 'A product with this name already exists.');
      return;
    }

    // Generate a unique ID for the new product
    const newId = Date.now().toString();

    // Add new product
    const newProduct = {
      id: newId,
      name: newProductName.trim(),
      price: price
    };

    const updatedProducts = [...productOptions, newProduct];
    setProductOptions(updatedProducts);
    setSelectedProduct(newProduct.name);
    
    // Reset form and close modal
    setNewProductName('');
    setNewProductPrice('');
    setShowAddProductModal(false);
  };

  // Delete product function
  const handleDeleteProduct = (productId) => {
    // Don't allow deleting if there's only one product left
    if (productOptions.length <= 1) {
      Alert.alert(
        "Cannot Delete",
        "You need to have at least one product available."
      );
      return;
    }

    // Find the product to delete
    const productToDelete = productOptions.find(p => p.id === productId);
    
    if (!productToDelete) {
      console.error('Product not found');
      return;
    }
    
    // Create a new array without the deleted product
    const updatedProducts = productOptions.filter(p => p.id !== productId);
    
    // If the deleted product was selected, select the first available product
    if (selectedProduct === productToDelete.name) {
      setSelectedProduct(updatedProducts[0].name);
    }
    
    // Update state with the new array
    setProductOptions(updatedProducts);
  };

  const handleShowRocketsInfo = () => {
    setShowRocketsInfoModal(true);
  };

  const handleShareReferral = async () => {
    try {
      if (Platform.OS === 'web') {
        Alert.alert(
          "Share Referral Code",
          `Your referral code is ${profile.referralCode}. Share this with friends to earn 500 rockets!`
        );
      } else {
        // This would use the native share functionality on mobile
        Alert.alert(
          "Share Referral Code",
          `Your referral code is ${profile.referralCode}. Share this with friends to earn 500 rockets!`
        );
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const handleToggleSalesFilter = () => {
    const newFilter = salesFilter === 'nationwide' ? 'city' : 'nationwide';
    setSalesFilter(newFilter);
  };

  const handleHighFive = (saleId, isRemoving = false) => {
    giveHighFive(saleId, isRemoving);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchGlobalSales();
    setRefreshing(false);
  };

  const handleShowSalesHistory = () => {
    setShowSalesHistoryModal(true);
    setSalesHistoryPage(1);
    setSearchQuery('');
  };

  const handleLoadMoreSales = () => {
    // In a real app, you would fetch more sales from the API
    // For this demo, we'll just simulate a loading state
    setIsLoadingMoreSales(true);
    
    // Simulate API delay
    setTimeout(() => {
      setSalesHistoryPage(prev => prev + 1);
      setIsLoadingMoreSales(false);
    }, 1000);
  };

  // Handle refund request
  const handleRefundRequest = (sale) => {
    setSelectedSaleForRefund(sale);
    setShowRefundConfirmModal(true);
  };

  // Process refund
  const handleProcessRefund = async () => {
    if (!selectedSaleForRefund) return;
    
    setProcessingRefund(true);
    
    try {
      await refundSale(selectedSaleForRefund.id);
      
      // Show success message
      Alert.alert(
        "Refund Processed",
        `Refund of $${selectedSaleForRefund.amount.toFixed(2)} to ${selectedSaleForRefund.customerName || 'customer'} has been processed successfully.`
      );
      
      // Close modals
      setShowRefundConfirmModal(false);
      setProcessingRefund(false);
      setSelectedSaleForRefund(null);
    } catch (error) {
      Alert.alert("Error", "Failed to process refund. Please try again.");
      setProcessingRefund(false);
    }
  };

  // Filter sales based on search query
  const getFilteredSales = useCallback(() => {
    if (!searchQuery.trim()) {
      return [...sales].sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      );
    }
    
    const query = searchQuery.toLowerCase().trim();
    return [...sales]
      .filter(sale => {
        // Search by customer name
        const customerName = (sale.customerName || '').toLowerCase();
        // Search by product
        const product = (sale.product || '').toLowerCase();
        // Search by amount
        const amount = sale.amount.toString();
        
        return customerName.includes(query) || 
               product.includes(query) || 
               amount.includes(query);
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [sales, searchQuery]);

  // Clear search
  const handleClearSearch = () => {
    setSearchQuery('');
  };

  // Render footer for sales history list
  const renderFooter = () => {
    if (!isLoadingMoreSales) return null;
    
    return (
      <View style={styles.loadingFooter}>
        <ActivityIndicator size="small" color={colors.primary} />
        <Text style={styles.loadingFooterText}>Loading more sales...</Text>
      </View>
    );
  };

  // Handle showing streak info modal
  const handleShowStreakInfo = () => {
    setShowStreakInfoModal(true);
  };

  return (
    <ScrollView 
      style={styles.container}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh}
          colors={[colors.primary, colors.secondary]}
          tintColor={colors.primary}
        />
      }
    >
      {/* Welcome Banner */}
      <LinearGradient
        colors={[colors.primary, colors.secondary]}
        style={styles.welcomeBanner}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.welcomeContent}>
          <MoneyMouthIcon size={50} color={colors.background} style={styles.welcomeIcon} />
          <Text style={styles.welcomeTitle}>Ready to Sell?</Text>
          <Text style={styles.welcomeSubtitle}>Show me the money!</Text>
        </View>
      </LinearGradient>

      {/* Core Business Section */}
      <View style={styles.businessSection}>
        {/* Today's Sales Card */}
        <TouchableOpacity 
          style={styles.salesCard}
          onPress={handleShowSalesHistory}
        >
          <Text style={styles.salesAmount}>${todaySales.toFixed(2)}</Text>
          <View style={styles.salesLabelContainer}>
            <Text style={styles.salesLabel}>{todaySalesCount} sales today</Text>
            <Info size={16} color={colors.textLight} />
          </View>
        </TouchableOpacity>
        
        {/* Payment Button */}
        <TouchableOpacity 
          style={styles.paymentButton}
          onPress={handleReceivePayment}
        >
          <View style={styles.paymentContent}>
            <DollarSign color={colors.background} size={24} />
            <Text style={styles.paymentText}>Tap to Receive Payment</Text>
          </View>
          <Text style={styles.paymentSubtext}>
            Hold phones together to complete sale
          </Text>
        </TouchableOpacity>
      </View>

      {/* Stats Section */}
      <View style={styles.statsContainer}>
        <TouchableOpacity 
          style={styles.statCard}
          onPress={handleShowStreakInfo}
        >
          <Flame color={colors.primary} size={24} />
          <Text style={styles.statValue}>5</Text>
          <View style={styles.statLabelContainer}>
            <Text style={styles.statLabel}>Weekly Streak</Text>
            <Info size={14} color={colors.textLight} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.statCard}
          onPress={handleShowRocketsInfo}
        >
          <Rocket color={colors.primary} size={24} />
          <Text style={styles.statValue}>{rocketsEarnedToday}</Text>
          <View style={styles.statLabelContainer}>
            <Text style={styles.statLabel}>Rockets Today</Text>
            <Info size={14} color={colors.textLight} />
          </View>
        </TouchableOpacity>
      </View>

      {/* Refer a Friend Button */}
      <TouchableOpacity 
        style={styles.referFriendButton}
        onPress={() => setShowReferralModal(true)}
      >
        <Share2 size={18} color={colors.background} />
        <Text style={styles.referFriendText}>Refer a Friend & Earn 500 Rockets</Text>
      </TouchableOpacity>

      {/* Global Sales Feed */}
      <View style={styles.globalSalesContainer}>
        <View style={styles.globalSalesHeader}>
          <Text style={styles.sectionTitle}>Kidpreneur Sales</Text>
          <TouchableOpacity 
            style={styles.filterButton}
            onPress={handleToggleSalesFilter}
          >
            {salesFilter === 'nationwide' ? (
              <>
                <Globe size={16} color={colors.text} />
                <Text style={styles.filterButtonText}>Nationwide</Text>
              </>
            ) : (
              <>
                <MapPin size={16} color={colors.text} />
                <Text style={styles.filterButtonText}>{profile.city}</Text>
              </>
            )}
            <Filter size={14} color={colors.text} />
          </TouchableOpacity>
        </View>
        
        {isLoadingGlobalSales ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={styles.loadingText}>Loading sales...</Text>
          </View>
        ) : globalSales.length === 0 ? (
          <View style={styles.emptyStateContainer}>
            <Text style={styles.emptyStateText}>No sales found</Text>
            {salesFilter === 'city' && (
              <TouchableOpacity onPress={handleToggleSalesFilter}>
                <Text style={styles.emptyStateAction}>View nationwide sales</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          globalSales.map((sale) => (
            <GlobalSaleItem 
              key={sale.id} 
              sale={sale} 
              onHighFive={handleHighFive}
            />
          ))
        )}
      </View>

      {/* Payment Modal */}
      <Modal
        visible={showPaymentModal}
        transparent={true}
        animationType="slide"
        onRequestClose={handleCloseModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Receive Payment</Text>
              <TouchableOpacity onPress={handleCloseModal} style={styles.closeButton}>
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              {/* Payment Method Selection */}
              <Text style={styles.modalLabel}>Payment Method:</Text>
              <View style={styles.paymentMethodContainer}>
                <TouchableOpacity
                  style={[
                    styles.paymentMethodOption,
                    paymentMethod === 'electronic' && styles.paymentMethodSelected
                  ]}
                  onPress={() => setPaymentMethod('electronic')}
                >
                  <CreditCard 
                    size={20} 
                    color={paymentMethod === 'electronic' ? colors.primary : colors.text} 
                  />
                  <Text 
                    style={[
                      styles.paymentMethodText,
                      paymentMethod === 'electronic' && styles.paymentMethodTextSelected
                    ]}
                  >
                    Credit/Debit/Mobile
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.paymentMethodOption,
                    paymentMethod === 'cash' && styles.paymentMethodSelected
                  ]}
                  onPress={() => setPaymentMethod('cash')}
                >
                  <Coins 
                    size={20} 
                    color={paymentMethod === 'cash' ? colors.primary : colors.text} 
                  />
                  <Text 
                    style={[
                      styles.paymentMethodText,
                      paymentMethod === 'cash' && styles.paymentMethodTextSelected
                    ]}
                  >
                    Cash
                  </Text>
                </TouchableOpacity>
              </View>

              {/* Product Selection */}
              <View style={styles.sectionHeaderRow}>
                <Text style={styles.modalLabel}>Select Product:</Text>
                <TouchableOpacity 
                  style={styles.addProductButton}
                  onPress={() => setShowAddProductModal(true)}
                >
                  <Plus size={16} color={colors.background} />
                  <Text style={styles.addProductText}>Add Product</Text>
                </TouchableOpacity>
              </View>
              
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.productScrollView}>
                <View style={styles.productSelector}>
                  {productOptions.map((product) => (
                    <View key={product.id} style={styles.productRow}>
                      <TouchableOpacity
                        style={[
                          styles.productOption,
                          selectedProduct === product.name && styles.productOptionSelected
                        ]}
                        onPress={() => setSelectedProduct(product.name)}
                      >
                        <Text style={[
                          styles.productOptionText,
                          selectedProduct === product.name && styles.productOptionTextSelected
                        ]}>
                          {product.name} (${product.price.toFixed(2)})
                        </Text>
                      </TouchableOpacity>
                      
                      {productOptions.length > 1 && (
                        <TouchableOpacity 
                          style={styles.deleteProductButton}
                          onPress={() => handleDeleteProduct(product.id)}
                        >
                          <X size={18} color={colors.error} />
                        </TouchableOpacity>
                      )}
                    </View>
                  ))}
                </View>
              </ScrollView>

              {/* Quantity Selector */}
              <Text style={styles.modalLabel}>Quantity:</Text>
              <View style={styles.quantitySelector}>
                <TouchableOpacity 
                  style={styles.quantityButton}
                  onPress={handleDecreaseQuantity}
                  disabled={quantity <= 1}
                >
                  <Minus size={20} color={quantity <= 1 ? colors.textLight : colors.text} />
                </TouchableOpacity>
                <Text style={styles.quantityText}>{quantity}</Text>
                <TouchableOpacity 
                  style={styles.quantityButton}
                  onPress={handleIncreaseQuantity}
                >
                  <Plus size={20} color={colors.text} />
                </TouchableOpacity>
              </View>

              {/* Total Amount */}
              <View style={styles.totalContainer}>
                <Text style={styles.totalLabel}>Total:</Text>
                <Text style={styles.totalAmount}>${calculateTotal()}</Text>
              </View>

              {/* Cash Payment Section */}
              {paymentMethod === 'cash' && (
                <View style={styles.cashPaymentSection}>
                  <Text style={styles.modalLabel}>Cash Received:</Text>
                  <View style={styles.cashInputContainer}>
                    <Text style={styles.cashInputPrefix}>$</Text>
                    <TextInput
                      style={styles.cashInput}
                      value={cashReceived}
                      onChangeText={setCashReceived}
                      placeholder="0.00"
                      placeholderTextColor={colors.textLight}
                      keyboardType="decimal-pad"
                    />
                  </View>
                  
                  <View style={styles.changeContainer}>
                    <Text style={styles.changeLabel}>Change to Give:</Text>
                    <Text style={styles.changeAmount}>${calculateChange()}</Text>
                  </View>
                  
                  <View style={styles.cashNoticeContainer}>
                    <Info size={16} color={colors.textLight} />
                    <Text style={styles.cashNoticeText}>
                      Cash payments don't earn rockets or count towards competitions.
                    </Text>
                  </View>
                </View>
              )}

              {paymentMethod === 'electronic' && (
                <View style={styles.instructionsContainer}>
                  <Text style={styles.instructionsTitle}>Instructions:</Text>
                  <Text style={styles.instructionsText}>
                    1. Select product and quantity
                    2. Tap "Process Payment" to complete the sale
                    3. Hold phones together to complete the transaction
                  </Text>
                </View>
              )}
            </View>

            <TouchableOpacity
              style={[
                styles.processButton,
                processingPayment && styles.processButtonDisabled
              ]}
              onPress={handleProcessPayment}
              disabled={processingPayment}
            >
              <Text style={styles.processButtonText}>
                {processingPayment ? 'Processing...' : 'Process Payment'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Add Product Modal */}
      <Modal
        visible={showAddProductModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowAddProductModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.addProductModalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add New Product</Text>
              <TouchableOpacity 
                onPress={() => setShowAddProductModal(false)} 
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Product Name:</Text>
              <TextInput
                style={styles.formInput}
                value={newProductName}
                onChangeText={setNewProductName}
                placeholder="Enter product name"
                placeholderTextColor={colors.textLight}
              />
            </View>

            <View style={styles.formGroup}>
              <Text style={styles.formLabel}>Price ($):</Text>
              <TextInput
                style={styles.formInput}
                value={newProductPrice}
                onChangeText={setNewProductPrice}
                placeholder="Enter price"
                placeholderTextColor={colors.textLight}
                keyboardType="decimal-pad"
              />
            </View>

            <TouchableOpacity
              style={styles.addButton}
              onPress={handleAddProduct}
            >
              <Text style={styles.addButtonText}>Add Product</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Success Modal with Confetti */}
      <Modal
        visible={showSuccessModal}
        transparent={true}
        animationType="fade"
        onRequestClose={handleCloseSuccessModal}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.successModalContainer}>
            {/* Use SimpleConfetti for web to avoid stack overflow */}
            {showConfetti && Platform.OS === 'web' && (
              <SimpleConfetti count={30} duration={3000} />
            )}
            
            {/* Use ConfettiAnimation for native platforms */}
            {showConfetti && Platform.OS !== 'web' && (
              <ConfettiAnimation 
                duration={3000}
                pieces={50}
                density="medium"
              />
            )}
            
            <View style={styles.successHeader}>
              <LinearGradient
                colors={[colors.primary, colors.secondary]}
                style={styles.successIconContainer}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Check size={40} color={colors.background} style={styles.successIcon} />
              </LinearGradient>
              <Text style={styles.congratsText}>
                Congratulations!
              </Text>
              <Text style={styles.successAmount}>
                You just earned ${lastSaleAmount.toFixed(2)}
              </Text>
            </View>

            {rocketsEarned > 0 && (
              <View style={styles.rocketsEarnedContainer}>
                <Rocket size={24} color={colors.secondary} />
                <Text style={styles.rocketsEarnedText}>
                  {rocketsEarned} Rockets Earned
                </Text>
              </View>
            )}

            <TouchableOpacity
              style={styles.closeSuccessButton}
              onPress={handleCloseSuccessModal}
            >
              <Text style={styles.closeSuccessButtonText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Rockets Info Modal */}
      <Modal
        visible={showRocketsInfoModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowRocketsInfoModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.rocketsInfoModalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>About Rockets</Text>
              <TouchableOpacity 
                onPress={() => setShowRocketsInfoModal(false)} 
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.rocketsInfoContent}>
              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>What are Rockets?</Text>
                <Text style={styles.rocketsInfoText}>
                  Rockets are rewards you earn for your sales. They get you discounts, free shipping, and even free products at MyLilStartup.com!
                </Text>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Earn Rockets</Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <DollarSign size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Sales:</Text> Earn 1 rocket for every $2 in electronic payments
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Tag size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Lucky Sales:</Text> 20% chance to earn 5 bonus rockets on any electronic sale
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Rocket size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Level Up:</Text> Spin the wheel to win rockets each time you level up
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Globe size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Competitions:</Text> Win rockets by ranking in weekly competitions
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Share2 size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Referrals:</Text> Win 500 rockets for each friend you refer
                  </Text>
                </View>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Redeem Rockets</Text>
                <Text style={styles.rocketsInfoText}>
                  Visit MyLilStartup.com and use your rockets at checkout for:
                </Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Discounts on products</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Free shipping</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Special items only available with rockets</Text>
                </View>
              </View>

              <TouchableOpacity 
                style={styles.referFriendsButton}
                onPress={() => {
                  setShowRocketsInfoModal(false);
                  setShowReferralModal(true);
                }}
              >
                <Text style={styles.referFriendsButtonText}>Refer Friends & Earn 500 Rockets</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Referral Modal */}
      <Modal
        visible={showReferralModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowReferralModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.referralModalContainer}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowReferralModal(false)}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <View style={styles.referralModalHeader}>
              <View style={styles.referralIconContainer}>
                <Share2 size={40} color={colors.primary} />
              </View>
              <Text style={styles.referralModalTitle}>Refer Friends</Text>
              <Text style={styles.referralModalSubtitle}>
                Share your code with friends - you get 500 rockets and they get $5 off their first order!
              </Text>
            </View>
            
            <View style={styles.referralCodeContainer}>
              <Text style={styles.referralCodeLabel}>Your Referral Code</Text>
              <View style={styles.referralCodeBox}>
                <Text style={styles.referralCodeText}>{profile.referralCode}</Text>
              </View>
            </View>
            
            <View style={styles.referralStepsContainer}>
              <Text style={styles.referralStepsTitle}>How it works:</Text>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>1</Text>
                </View>
                <Text style={styles.referralStepText}>
                  Share your unique code with friends
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>2</Text>
                </View>
                <Text style={styles.referralStepText}>
                  They enter your code when signing up
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>3</Text>
                </View>
                <Text style={styles.referralStepText}>
                  You get 500 rockets and they get $5 off their first order!
                </Text>
              </View>
            </View>
            
            <TouchableOpacity 
              style={styles.shareReferralButton}
              onPress={handleShareReferral}
            >
              <Share2 size={20} color={colors.background} />
              <Text style={styles.shareReferralButtonText}>Share Your Code</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Sales History Modal */}
      <Modal
        visible={showSalesHistoryModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowSalesHistoryModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.salesHistoryModalContainer}>
            <View style={styles.salesHistoryHeader}>
              <TouchableOpacity 
                style={styles.backButton}
                onPress={() => setShowSalesHistoryModal(false)}
              >
                <ArrowLeft size={24} color={colors.text} />
              </TouchableOpacity>
              <Text style={styles.salesHistoryTitle}>Your Sales History</Text>
              <View style={{ width: 24 }} />
            </View>

            {/* Search Box */}
            <View style={styles.searchContainer}>
              <View style={styles.searchInputContainer}>
                <Search size={18} color={colors.textLight} style={styles.searchIcon} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search by customer name..."
                  placeholderTextColor={colors.textLight}
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  returnKeyType="search"
                />
                {searchQuery.length > 0 && (
                  <TouchableOpacity onPress={handleClearSearch} style={styles.clearSearchButton}>
                    <X size={18} color={colors.textLight} />
                  </TouchableOpacity>
                )}
              </View>
            </View>

            <View style={styles.salesHistoryFilterContainer}>
              <View style={styles.salesHistoryFilter}>
                <Calendar size={16} color={colors.primary} />
                <Text style={styles.salesHistoryFilterText}>All Sales</Text>
              </View>
            </View>

            <FlatList
              data={getFilteredSales()}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <SalesHistoryItem 
                  sale={item} 
                  onRefund={handleRefundRequest}
                  highlight={searchQuery.length > 0}
                  searchTerm={searchQuery}
                />
              )}
              contentContainerStyle={styles.salesHistoryList}
              ListEmptyComponent={
                <View style={styles.emptyStateContainer}>
                  <Text style={styles.emptyStateText}>
                    {searchQuery.length > 0 
                      ? `No sales found matching "${searchQuery}"`
                      : "No sales found"}
                  </Text>
                  {searchQuery.length > 0 && (
                    <TouchableOpacity onPress={handleClearSearch}>
                      <Text style={styles.emptyStateAction}>Clear search</Text>
                    </TouchableOpacity>
                  )}
                </View>
              }
              onEndReached={handleLoadMoreSales}
              onEndReachedThreshold={0.5}
              ListFooterComponent={renderFooter}
            />
          </View>
        </View>
      </Modal>

      {/* Refund Confirmation Modal */}
      <Modal
        visible={showRefundConfirmModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowRefundConfirmModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.refundConfirmModalContainer}>
            <View style={styles.refundConfirmHeader}>
              <AlertTriangle size={40} color={colors.error} />
              <Text style={styles.refundConfirmTitle}>Confirm Refund</Text>
              <Text style={styles.refundConfirmText}>
                Are you sure you want to issue a refund to{' '}
                <Text style={styles.refundConfirmHighlight}>
                  {selectedSaleForRefund?.customerName || 'Jane Z'}
                </Text>{' '}
                for{' '}
                <Text style={styles.refundConfirmHighlight}>
                  ${selectedSaleForRefund?.amount.toFixed(2) || '0.00'}
                </Text>?
              </Text>
              <Text style={styles.refundConfirmSubtext}>
                This will remove any rockets earned from this sale.
              </Text>
            </View>
            
            <View style={styles.refundConfirmButtons}>
              <TouchableOpacity 
                style={styles.refundCancelButton}
                onPress={() => {
                  setShowRefundConfirmModal(false);
                  setSelectedSaleForRefund(null);
                }}
                disabled={processingRefund}
              >
                <Text style={styles.refundCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.refundConfirmButton,
                  processingRefund && styles.refundConfirmButtonDisabled
                ]}
                onPress={handleProcessRefund}
                disabled={processingRefund}
              >
                {processingRefund ? (
                  <ActivityIndicator size="small" color={colors.background} />
                ) : (
                  <Text style={styles.refundConfirmButtonText}>Process Refund</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Weekly Streak Info Modal */}
      <Modal
        visible={showStreakInfoModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowStreakInfoModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.streakInfoModalContainer}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowStreakInfoModal(false)}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <LinearGradient
              colors={[colors.primary, colors.secondary]}
              style={styles.streakHeaderGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.streakIconContainer}>
                <Flame size={40} color="#FFFFFF" />
              </View>
              <Text style={styles.streakTitle}>Weekly Streak: 5</Text>
              <Text style={styles.streakSubtitle}>
                Number of weeks you've sold at least one item
              </Text>
            </LinearGradient>
            
            <View style={styles.streakContent}>
              <View style={styles.streakInfoSection}>
                <Text style={styles.streakInfoTitle}>How Streaks Work</Text>
                <Text style={styles.streakInfoText}>
                  Your streak increases by 1 each week when you make at least one sale. If you don't make any sales in a week, your streak resets to 0.
                </Text>
              </View>
              
              <View style={styles.streakRewardsSection}>
                <Text style={styles.streakRewardsTitle}>Streak Rewards</Text>
                
                <View style={styles.streakRewardItem}>
                  <View style={styles.streakRewardBadge}>
                    <Text style={styles.streakRewardBadgeText}>1</Text>
                  </View>
                  <View style={styles.streakRewardContent}>
                    <Text style={styles.streakRewardTitle}>First Week</Text>
                    <Text style={styles.streakRewardDescription}>10 bonus rockets</Text>
                  </View>
                </View>
                
                <View style={styles.streakRewardItem}>
                  <View style={styles.streakRewardBadge}>
                    <Text style={styles.streakRewardBadgeText}>4</Text>
                  </View>
                  <View style={styles.streakRewardContent}>
                    <Text style={styles.streakRewardTitle}>One Month</Text>
                    <Text style={styles.streakRewardDescription}>50 bonus rockets + Month Milestone badge</Text>
                  </View>
                </View>
                
                <View style={[styles.streakRewardItem, styles.streakRewardItemActive]}>
                  <View style={[styles.streakRewardBadge, styles.streakRewardBadgeActive]}>
                    <Text style={styles.streakRewardBadgeText}>5</Text>
                  </View>
                  <View style={styles.streakRewardContent}>
                    <Text style={styles.streakRewardTitle}>Five Weeks</Text>
                    <Text style={styles.streakRewardDescription}>25 bonus rockets</Text>
                  </View>
                </View>
                
                <View style={styles.streakRewardItem}>
                  <View style={styles.streakRewardBadge}>
                    <Text style={styles.streakRewardBadgeText}>8</Text>
                  </View>
                  <View style={styles.streakRewardContent}>
                    <Text style={styles.streakRewardTitle}>Two Months</Text>
                    <Text style={styles.streakRewardDescription}>100 bonus rockets + Consistency badge</Text>
                  </View>
                </View>
                
                <View style={styles.streakRewardItem}>
                  <View style={styles.streakRewardBadge}>
                    <Text style={styles.streakRewardBadgeText}>12</Text>
                  </View>
                  <View style={styles.streakRewardContent}>
                    <Text style={styles.streakRewardTitle}>Three Months</Text>
                    <Text style={styles.streakRewardDescription}>250 bonus rockets + Golden Ticket</Text>
                  </View>
                </View>
              </View>
              
              <View style={styles.streakTipContainer}>
                <Info size={20} color={colors.primary} />
                <Text style={styles.streakTipText}>
                  Keep your streak going! Make at least one sale this week to reach 6 weeks.
                </Text>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  welcomeBanner: {
    height: 160,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeContent: {
    alignItems: 'center',
  },
  welcomeIcon: {
    marginBottom: 8,
  },
  welcomeTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.background,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.background,
    opacity: 0.9,
    marginTop: 4,
  },
  businessSection: {
    padding: 20,
    marginTop: -40,
  },
  salesCard: {
    backgroundColor: colors.card,
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  salesAmount: {
    fontSize: 42,
    fontWeight: 'bold',
    color: colors.text,
  },
  salesLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
    gap: 6,
  },
  salesLabel: {
    fontSize: 16,
    color: colors.textLight,
  },
  paymentButton: {
    backgroundColor: colors.accent,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  paymentContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  paymentText: {
    color: colors.background,
    fontSize: 18,
    fontWeight: '600',
  },
  paymentSubtext: {
    color: colors.background,
    opacity: 0.8,
    marginTop: 4,
    fontSize: 13,
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 20,
    paddingTop: 0,
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  statLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  referFriendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.secondary,
    marginHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
    marginBottom: 20,
  },
  referFriendText: {
    color: colors.background,
    fontWeight: '600',
    fontSize: 15,
  },
  // Global Sales Feed
  globalSalesContainer: {
    padding: 20,
    paddingTop: 0,
  },
  globalSalesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  filterButtonText: {
    fontSize: 14,
    color: colors.text,
    marginRight: 4,
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: colors.textLight,
  },
  emptyStateContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: colors.card,
    borderRadius: 12,
  },
  emptyStateText: {
    fontSize: 16,
    color: colors.textLight,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyStateAction: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '500',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '100%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeButton: {
    padding: 5,
  },
  modalBody: {
    marginBottom: 20,
  },
  // Payment Method Styles
  paymentMethodContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    gap: 12,
  },
  paymentMethodOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.card,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  paymentMethodSelected: {
    backgroundColor: colors.primary + '15',
    borderColor: colors.primary,
  },
  paymentMethodText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  paymentMethodTextSelected: {
    color: colors.primary,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalLabel: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 8,
  },
  addProductButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 4,
  },
  addProductText: {
    color: colors.background,
    fontSize: 14,
    fontWeight: '500',
  },
  productScrollView: {
    marginBottom: 16,
  },
  productSelector: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    paddingBottom: 5,
  },
  productRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },
  productOption: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  productOptionSelected: {
    backgroundColor: colors.primary + '20',
    borderColor: colors.primary,
  },
  productOptionText: {
    color: colors.text,
    fontWeight: '500',
  },
  productOptionTextSelected: {
    color: colors.secondary,
  },
  deleteProductButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.error + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
    borderWidth: 1,
    borderColor: colors.error + '30',
  },
  quantitySelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  quantityButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quantityText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginHorizontal: 20,
    color: colors.text,
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  totalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  // Cash Payment Styles
  cashPaymentSection: {
    marginBottom: 20,
  },
  cashInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cashInputPrefix: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginRight: 8,
  },
  cashInput: {
    flex: 1,
    fontSize: 20,
    color: colors.text,
  },
  changeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.primary + '15',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  changeLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  changeAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.primary,
  },
  cashNoticeContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.backgroundDark + '15',
    padding: 12,
    borderRadius: 12,
    gap: 8,
  },
  cashNoticeText: {
    flex: 1,
    fontSize: 14,
    color: colors.textLight,
    lineHeight: 20,
  },
  instructionsContainer: {
    backgroundColor: colors.backgroundDark + '15',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  instructionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  instructionsText: {
    fontSize: 14,
    color: colors.text,
    lineHeight: 22,
  },
  processButton: {
    backgroundColor: colors.accent,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  processButtonDisabled: {
    backgroundColor: colors.textLight,
    opacity: 0.7,
  },
  processButtonText: {
    color: colors.background,
    fontSize: 18,
    fontWeight: '600',
  },
  // Add Product Modal Styles
  addProductModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  formGroup: {
    marginBottom: 16,
  },
  formLabel: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 8,
  },
  formInput: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
  },
  addButton: {
    backgroundColor: colors.primary,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  addButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Success Modal Styles
  successModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    overflow: 'hidden', // Important for confetti
  },
  successHeader: {
    alignItems: 'center',
    marginBottom: 24,
    zIndex: 2, // Above confetti
  },
  successIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
  },
  successIcon: {
    // No additional styling needed as it's inside the gradient container
  },
  congratsText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  successAmount: {
    fontSize: 22,
    color: colors.text,
    fontWeight: '600',
  },
  rocketsEarnedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.secondary + '20',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginBottom: 20,
    gap: 8,
    zIndex: 2, // Above confetti
  },
  rocketsEarnedText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.secondary,
  },
  totalRocketsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
    gap: 8,
    zIndex: 2, // Above confetti
  },
  totalRocketsLabel: {
    fontSize: 16,
    color: colors.text,
  },
  totalRocketsValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeSuccessButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 32,
    paddingVertical: 14,
    borderRadius: 30,
    zIndex: 2, // Above confetti
  },
  closeSuccessButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Rockets Info Modal Styles
  rocketsInfoModalContainer: {
    width: '90%',
    maxHeight: '80%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  rocketsInfoContent: {
    maxHeight: 500,
  },
  rocketsInfoSection: {
    marginBottom: 20,
  },
  rocketsInfoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 10,
  },
  rocketsInfoText: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 22,
    marginBottom: 10,
  },
  rocketsInfoItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
    gap: 10,
  },
  rocketsInfoBullet: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  rocketsInfoItemText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
    lineHeight: 22,
  },
  rocketsInfoBold: {
    fontWeight: 'bold',
    color: colors.secondary,
  },
  referFriendsButton: {
    backgroundColor: colors.accent,
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
  },
  referFriendsButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Referral Modal Styles
  referralModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  referralModalHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  referralIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  referralModalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  referralModalSubtitle: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 22,
  },
  referralCodeContainer: {
    marginBottom: 20,
  },
  referralCodeLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  referralCodeBox: {
    backgroundColor: colors.primary + '20',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  referralCodeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.secondary,
    letterSpacing: 2,
  },
  referralStepsContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  referralStepsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  referralStep: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  referralStepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  referralStepNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.background,
  },
  referralStepText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  shareReferralButton: {
    backgroundColor: colors.accent,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  shareReferralButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Sales History Modal Styles
  salesHistoryModalContainer: {
    flex: 1,
    width: '100%',
    backgroundColor: colors.background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    overflow: 'hidden',
  },
  salesHistoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: {
    padding: 4,
  },
  salesHistoryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  // Search Box Styles
  searchContainer: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
    paddingVertical: 4,
  },
  clearSearchButton: {
    padding: 4,
  },
  salesHistoryFilterContainer: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  salesHistoryFilter: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    alignSelf: 'flex-start',
    gap: 6,
  },
  salesHistoryFilterText: {
    fontSize: 14,
    color: colors.primary,
    fontWeight: '500',
  },
  salesHistoryList: {
    padding: 16,
    paddingBottom: 40,
  },
  loadingFooter: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    gap: 8,
  },
  loadingFooterText: {
    fontSize: 14,
    color: colors.textLight,
  },
  // Refund Confirmation Modal Styles
  refundConfirmModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  refundConfirmHeader: {
    alignItems: 'center',
    marginBottom: 24,
  },
  refundConfirmTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 12,
    marginBottom: 16,
  },
  refundConfirmText: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 22,
  },
  refundConfirmSubtext: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    marginTop: 8,
  },
  refundConfirmHighlight: {
    fontWeight: 'bold',
    color: colors.secondary,
  },
  refundConfirmButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  refundCancelButton: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  refundCancelButtonText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
  },
  refundConfirmButton: {
    flex: 1,
    backgroundColor: colors.error,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  refundConfirmButtonDisabled: {
    backgroundColor: colors.textLight,
    opacity: 0.7,
  },
  refundConfirmButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Weekly Streak Modal Styles
  streakInfoModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    maxHeight: '80%',
  },
  streakHeaderGradient: {
    padding: 24,
    alignItems: 'center',
  },
  streakIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  streakTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  streakSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 0.5, height: 0.5 },
    textShadowRadius: 1,
  },
  streakContent: {
    padding: 20,
  },
  streakInfoSection: {
    marginBottom: 20,
  },
  streakInfoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 10,
  },
  streakInfoText: {
    fontSize: 16,
    color: colors.text,
    lineHeight: 22,
  },
  streakRewardsSection: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  streakRewardsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  streakRewardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  streakRewardItemActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primary + '10',
  },
  streakRewardBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.backgroundDark,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  streakRewardBadgeActive: {
    backgroundColor: colors.primary,
  },
  streakRewardBadgeText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.background,
  },
  streakRewardContent: {
    flex: 1,
  },
  streakRewardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 2,
  },
  streakRewardDescription: {
    fontSize: 14,
    color: colors.textLight,
  },
  streakTipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary + '15',
    padding: 16,
    borderRadius: 12,
    gap: 12,
  },
  streakTipText: {
    fontSize: 15,
    color: colors.text,
    flex: 1,
    lineHeight: 22,
  },
});