import { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Keyboard,
} from 'react-native';
import { Send, Bot, Mic, MicOff } from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { getChatResponse } from '@/lib/openai';
import { startSpeechToText, stopSpeechToText } from '@/lib/speech';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
}

// Example questions that users can quickly select
const EXAMPLE_QUESTIONS = [
  "What's the best product for a kid to sell?",
  "Where should I sell to make the most money?",
  "How do I set my prices?",
  "How can I accept digital payments?"
];

export default function CoachScreen() {
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hey there, I'm Coach Cash! 🌟 I'm here to help you become an awesome kidpreneur! What would you like to learn about first? 🚀",
      isUser: false,
    },
  ]);
  const scrollViewRef = useRef<ScrollView>(null);
  const inputRef = useRef<TextInput>(null);

  // Monitor keyboard visibility
  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setKeyboardVisible(true);
        scrollToBottom();
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setKeyboardVisible(false);
      }
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const handleSend = async () => {
    if (!message.trim() || isLoading) return;

    const userMessage = {
      id: Date.now().toString(),
      text: message,
      isUser: true,
    };

    setMessages(prev => [...prev, userMessage]);
    setMessage('');
    setIsLoading(true);
    scrollToBottom();

    try {
      const response = await getChatResponse(message);
      
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        text: response,
        isUser: false,
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Failed to get AI response:', error);
      const errorMessage = {
        id: (Date.now() + 1).toString(),
        text: "Sorry, I'm having trouble thinking right now. Can you try asking again? 🤔",
        isUser: false,
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      scrollToBottom();
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const handleExampleQuestion = (question: string) => {
    setMessage(question);
    // Use setTimeout to ensure the message is set before sending
    setTimeout(() => {
      handleSend();
    }, 50);
  };

  const toggleListening = async () => {
    if (isListening) {
      setIsListening(false);
      await stopSpeechToText();
    } else {
      // Show an alert explaining the simulation in Expo Go
      Alert.alert(
        "Voice Recognition Simulation",
        "In Expo Go, we're showing a simulation of voice recognition. In the full app, this would use your device's microphone.",
        [
          { 
            text: "Try Simulation", 
            onPress: () => startSimulatedListening() 
          },
          {
            text: "Cancel",
            style: "cancel"
          }
        ]
      );
    }
  };

  const startSimulatedListening = async () => {
    setIsListening(true);
    
    try {
      await startSpeechToText(
        (text) => {
          if (text) {
            setMessage(text);
            // Auto-send the message after a short delay
            setTimeout(() => {
              handleSend();
            }, 500);
          }
          setIsListening(false);
        },
        (simulationMessage) => {
          // Add a message from Coach Cash about the simulation
          const infoMessage = {
            id: Date.now().toString(),
            text: simulationMessage,
            isUser: false,
          };
          setMessages(prev => [...prev, infoMessage]);
        }
      );
    } catch (error) {
      console.error('Speech recognition error:', error);
      setIsListening(false);
      
      // Add a message from Coach Cash about the voice recognition issue
      const errorMessage = {
        id: Date.now().toString(),
        text: "I'm having trouble with voice recognition right now. You can type your question instead! 🙂",
        isUser: false,
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  // Ensure scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 0}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Meet Coach Cash</Text>
        <Text style={styles.subtitle}>Your guide to making your own money!</Text>
      </View>

      <ScrollView 
        ref={scrollViewRef}
        style={styles.messages} 
        contentContainerStyle={[
          styles.messagesContent,
          keyboardVisible && { paddingBottom: 80 }
        ]}
      >
        {messages.map((msg) => (
          <View
            key={msg.id}
            style={[
              styles.message,
              msg.isUser ? styles.userMessage : styles.coachMessage,
            ]}
          >
            {!msg.isUser && (
              <View style={styles.botIcon}>
                <Bot size={20} color={colors.primary} />
              </View>
            )}
            <Text
              style={[
                styles.messageText,
                msg.isUser ? styles.userMessageText : styles.coachMessageText,
              ]}
            >
              {msg.text}
            </Text>
          </View>
        ))}
        {isLoading && (
          <View style={[styles.message, styles.coachMessage]}>
            <View style={styles.botIcon}>
              <Bot size={20} color={colors.primary} />
            </View>
            <ActivityIndicator color={colors.primary} style={styles.loader} />
          </View>
        )}
      </ScrollView>

      {/* Example Questions */}
      <View style={styles.exampleQuestionsContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.exampleQuestionsContent}
        >
          {EXAMPLE_QUESTIONS.map((question, index) => (
            <TouchableOpacity
              key={index}
              style={styles.exampleQuestionButton}
              onPress={() => handleExampleQuestion(question)}
              disabled={isLoading}
            >
              <Text style={styles.exampleQuestionText}>{question}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          ref={inputRef}
          style={styles.input}
          value={message}
          onChangeText={setMessage}
          placeholder="Ask Coach Cash..."
          placeholderTextColor={colors.textLight}
          multiline
          editable={!isLoading}
          onFocus={scrollToBottom}
        />
        <TouchableOpacity
          style={[styles.voiceInputButton, isListening && styles.voiceInputActive]}
          onPress={toggleListening}
          disabled={isLoading}
        >
          {isListening ? (
            <MicOff size={20} color={colors.error} />
          ) : (
            <Mic size={20} color={colors.textLight} />
          )}
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!message.trim() || isLoading) && styles.sendButtonDisabled,
          ]}
          onPress={handleSend}
          disabled={!message.trim() || isLoading}
        >
          <Send
            size={20}
            color={message.trim() && !isLoading ? colors.background : colors.textLight}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    padding: 20,
    paddingTop: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textLight,
    marginTop: 4,
  },
  messages: {
    flex: 1,
  },
  messagesContent: {
    padding: 20,
    gap: 16,
    paddingBottom: 40,
  },
  message: {
    maxWidth: '80%',
    borderRadius: 16,
    padding: 12,
  },
  userMessage: {
    backgroundColor: colors.primary,
    alignSelf: 'flex-end',
  },
  coachMessage: {
    backgroundColor: colors.card,
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  botIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
  },
  userMessageText: {
    color: colors.text,
  },
  coachMessageText: {
    color: colors.text,
    flex: 1,
  },
  exampleQuestionsContainer: {
    paddingHorizontal: 16,
    marginBottom: 8,
  },
  exampleQuestionsContent: {
    gap: 8,
    paddingVertical: 4,
  },
  exampleQuestionButton: {
    backgroundColor: colors.secondary + '20',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 8,
  },
  exampleQuestionText: {
    color: colors.secondary,
    fontSize: 14,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.background,
  },
  input: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
    maxHeight: 100,
  },
  voiceInputButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },
  voiceInputActive: {
    backgroundColor: colors.error + '20',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: colors.card,
  },
  loader: {
    padding: 8,
  },
});