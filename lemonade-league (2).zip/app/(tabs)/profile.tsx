import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Modal,
  Alert,
  ActivityIndicator,
  Switch,
} from 'react-native';
import { 
  User, 
  Award, 
  DollarSign, 
  Share2, 
  Settings, 
  ChevronRight,
  Rocket,
  Clock,
  Calendar,
  CreditCard,
  Check,
  Plus,
  X,
  ArrowDown,
  Eye,
  Trophy,
  LogOut,
  Edit,
  Star,
  Link,
  Unlink,
} from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { useUserStore } from '@/store/user-store';
import { useAuthStore } from '@/store/auth-store';
import { useSmileRewardsStore } from '@/store/smile-rewards-store';
import { badges } from '@/constants/badges';
import { linkedBankAccounts } from '@/constants/banks';
import { useRouter } from 'expo-router';
import SmileRewardsCard from '@/components/SmileRewardsCard';

interface Deposit {
  id: string;
  amount: number;
  date: string;
  bankId: string;
  description: string;
}

// Sample deposits data
const sampleDeposits: Deposit[] = [
  {
    id: 'dep_1',
    amount: 25.50,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    bankId: 'bank_1',
    description: 'Weekly transfer'
  },
  {
    id: 'dep_2',
    amount: 42.75,
    date: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000).toISOString(), // 9 days ago
    bankId: 'bank_1',
    description: 'Sales deposit'
  },
  {
    id: 'dep_3',
    amount: 18.25,
    date: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000).toISOString(), // 16 days ago
    bankId: 'bank_2',
    description: 'Sales deposit'
  },
  {
    id: 'dep_4',
    amount: 35.00,
    date: new Date(Date.now() - 23 * 24 * 60 * 60 * 1000).toISOString(), // 23 days ago
    bankId: 'bank_3',
    description: 'Weekly transfer'
  },
];

export default function ProfileScreen() {
  const router = useRouter();
  const { profile, getLevelInfo, sales } = useUserStore();
  const { user, logout, isLoading } = useAuthStore();
  const { 
    isInitialized: isSmileInitialized, 
    pointsBalance, 
    initializeSmileCustomer 
  } = useSmileRewardsStore();
  
  const { level, title } = getLevelInfo();
  
  const [showDepositsModal, setShowDepositsModal] = useState(false);
  const [showLogoutConfirmModal, setShowLogoutConfirmModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showSmileSettingsModal, setShowSmileSettingsModal] = useState(false);
  const [smileConnected, setSmileConnected] = useState(isSmileInitialized);
  const [autoSync, setAutoSync] = useState(false);
  
  // Update smile connected state when initialized status changes
  useEffect(() => {
    setSmileConnected(isSmileInitialized);
  }, [isSmileInitialized]);
  
  // Calculate stats
  const totalSales = profile.totalSales;
  const totalTransactions = profile.salesCount;
  const avgSaleAmount = totalSales / (totalTransactions || 1);
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  // Get bank name by ID
  const getBankName = (bankId: string) => {
    const bank = linkedBankAccounts.find(account => account.id === bankId);
    return bank ? bank.bankName : 'Unknown Bank';
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      // Router redirect is handled by the auth check in _layout.tsx
    } catch (error) {
      console.error('Logout error:', error);
      Alert.alert('Logout Failed', 'Please try again.');
    }
  };

  const handleShareReferral = async () => {
    try {
      Alert.alert(
        "Share Referral Code",
        `Your referral code is ${profile.referralCode}. Share this with friends - you get 500 rockets and they get $5 off their first order!`
      );
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };
  
  const handleConnectSmile = async () => {
    try {
      await initializeSmileCustomer(profile.name, profile.name);
      setSmileConnected(true);
      Alert.alert(
        'Success',
        'Your account has been connected to Smile Rewards!'
      );
    } catch (error) {
      Alert.alert(
        'Connection Failed',
        'Failed to connect to Smile Rewards. Please try again.'
      );
    }
  };
  
  const handleDisconnectSmile = () => {
    Alert.alert(
      'Disconnect Smile Rewards',
      'Are you sure you want to disconnect your Smile Rewards account? Your points will not be lost, but you will need to reconnect to access them.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Disconnect', 
          style: 'destructive',
          onPress: () => {
            // In a real app, we would call an API to disconnect
            setSmileConnected(false);
            setAutoSync(false);
          }
        }
      ]
    );
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.profileInfo}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1588533588400-9f2b1e5bc8c5?w=120&h=120&q=80' }}
            style={styles.avatar}
          />
          <View style={styles.nameContainer}>
            <Text style={styles.name}>{profile.name}</Text>
            <View style={styles.levelBadge}>
              <Rocket size={14} color={colors.primary} />
              <Text style={styles.levelText}>{title}</Text>
            </View>
          </View>
        </View>
        
        <TouchableOpacity style={styles.editButton}>
          <Settings size={18} color={colors.textLight} />
          <Text style={styles.editButtonText}>Edit Profile</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>${totalSales.toFixed(2)}</Text>
          <Text style={styles.statLabel}>Total Sales</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{profile.rockets}</Text>
          <Text style={styles.statLabel}>Rockets</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{profile.goldenTickets}</Text>
          <Text style={styles.statLabel}>Golden Tickets</Text>
        </View>
      </View>
      
      {/* Smile Rewards Card (Compact) */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Star size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Smile Rewards</Text>
        </View>
        
        {smileConnected ? (
          <>
            <SmileRewardsCard compact />
            <TouchableOpacity 
              style={styles.smileSettingsButton}
              onPress={() => setShowSmileSettingsModal(true)}
            >
              <Settings size={16} color={colors.textLight} />
              <Text style={styles.smileSettingsText}>Manage Smile Rewards</Text>
            </TouchableOpacity>
          </>
        ) : (
          <View style={styles.connectSmileContainer}>
            <Text style={styles.connectSmileText}>
              Connect to Smile Rewards to earn additional benefits and exclusive rewards!
            </Text>
            <TouchableOpacity 
              style={styles.connectSmileButton}
              onPress={handleConnectSmile}
            >
              <Link size={16} color={colors.background} />
              <Text style={styles.connectSmileButtonText}>Connect to Smile Rewards</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
      
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <CreditCard size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Linked Bank Accounts</Text>
        </View>
        
        <View style={styles.bankAccountsContainer}>
          {linkedBankAccounts.map(account => (
            <View key={account.id} style={styles.bankAccountItem}>
              <Image 
                source={{ uri: account.logoUrl }}
                style={styles.bankLogo}
              />
              <View style={styles.bankDetails}>
                <Text style={styles.bankName}>{account.bankName}</Text>
                <Text style={styles.accountInfo}>
                  {account.accountType.charAt(0).toUpperCase() + account.accountType.slice(1)} •••• {account.lastFourDigits}
                </Text>
              </View>
              {account.isDefault && (
                <View style={styles.defaultBadge}>
                  <Check size={12} color={colors.primary} />
                  <Text style={styles.defaultText}>Default</Text>
                </View>
              )}
            </View>
          ))}
          
          <View style={styles.bankButtonsContainer}>
            <TouchableOpacity 
              style={styles.seeDepositsButton}
              onPress={() => setShowDepositsModal(true)}
            >
              <ArrowDown size={16} color={colors.secondary} />
              <Text style={styles.seeDepositsText}>See Deposits</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.addBankButton}>
              <Plus size={16} color={colors.secondary} />
              <Text style={styles.addBankText}>Link New Account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <DollarSign size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Sales Stats</Text>
        </View>
        
        <View style={styles.detailsContainer}>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Total Transactions</Text>
            <Text style={styles.detailValue}>{totalTransactions}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Average Sale</Text>
            <Text style={styles.detailValue}>${avgSaleAmount.toFixed(2)}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>City</Text>
            <Text style={styles.detailValue}>{profile.city}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Member Since</Text>
            <Text style={styles.detailValue}>{formatDate(profile.joinDate)}</Text>
          </View>
        </View>
      </View>
      
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Share2 size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Refer a Friend</Text>
        </View>
        
        <View style={styles.referralContainer}>
          <Text style={styles.referralText}>
            Share your code with friends - you get 500 rockets and they get $5 off their first order!
          </Text>
          <View style={styles.referralCode}>
            <Text style={styles.referralCodeText}>{profile.referralCode}</Text>
          </View>
          <TouchableOpacity 
            style={styles.shareButton}
            onPress={() => setShowReferralModal(true)}
          >
            <Text style={styles.shareButtonText}>Share Your Code</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Clock size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Recent Activity</Text>
        </View>
        
        <View style={styles.activityContainer}>
          {sales.slice(0, 5).map(sale => (
            <View key={sale.id} style={styles.activityItem}>
              <View style={styles.activityIconContainer}>
                <DollarSign size={16} color={colors.primary} />
              </View>
              <View style={styles.activityDetails}>
                <Text style={styles.activityTitle}>Sale Completed</Text>
                <Text style={styles.activitySubtitle}>
                  ${sale.amount.toFixed(2)} at {sale.location}
                </Text>
              </View>
              <Text style={styles.activityTime}>
                {new Date(sale.date).toLocaleDateString()}
              </Text>
            </View>
          ))}
        </View>
      </View>
      
      {/* Account Section with Logout */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <User size={20} color={colors.primary} />
          <Text style={styles.sectionTitle}>Account</Text>
        </View>
        
        <View style={styles.accountContainer}>
          <TouchableOpacity style={styles.accountOption}>
            <View style={styles.accountOptionIcon}>
              <Edit size={20} color={colors.secondary} />
            </View>
            <Text style={styles.accountOptionText}>Edit Profile</Text>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.accountOption}
            onPress={() => setShowLogoutConfirmModal(true)}
          >
            <View style={[styles.accountOptionIcon, styles.logoutIcon]}>
              <LogOut size={20} color={colors.error} />
            </View>
            <Text style={styles.logoutText}>Log Out</Text>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Deposits Modal */}
      <Modal
        visible={showDepositsModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowDepositsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Bank Deposits</Text>
              <TouchableOpacity 
                onPress={() => setShowDepositsModal(false)}
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.depositsContainer}>
              {sampleDeposits.map(deposit => (
                <View key={deposit.id} style={styles.depositItem}>
                  <View style={styles.depositIconContainer}>
                    <ArrowDown size={16} color={colors.primary} />
                  </View>
                  <View style={styles.depositDetails}>
                    <Text style={styles.depositAmount}>${deposit.amount.toFixed(2)}</Text>
                    <Text style={styles.depositDescription}>{deposit.description}</Text>
                    <View style={styles.depositMeta}>
                      <Text style={styles.depositBank}>{getBankName(deposit.bankId)}</Text>
                      <Text style={styles.depositDate}>{formatDate(deposit.date)}</Text>
                    </View>
                  </View>
                </View>
              ))}
              
              {sampleDeposits.length === 0 && (
                <View style={styles.emptyDeposits}>
                  <Text style={styles.emptyDepositsText}>No deposits found</Text>
                </View>
              )}
            </ScrollView>
            
            <TouchableOpacity 
              style={styles.closeModalButton}
              onPress={() => setShowDepositsModal(false)}
            >
              <Text style={styles.closeModalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      
      {/* Logout Confirmation Modal */}
      <Modal
        visible={showLogoutConfirmModal}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setShowLogoutConfirmModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.confirmModalContainer}>
            <View style={styles.confirmModalHeader}>
              <LogOut size={40} color={colors.error} />
              <Text style={styles.confirmModalTitle}>Log Out</Text>
              <Text style={styles.confirmModalMessage}>
                Are you sure you want to log out of your account?
              </Text>
            </View>
            
            <View style={styles.confirmModalButtons}>
              <TouchableOpacity 
                style={styles.cancelButton}
                onPress={() => setShowLogoutConfirmModal(false)}
                disabled={isLoading}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.logoutButton}
                onPress={handleLogout}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color={colors.background} size="small" />
                ) : (
                  <Text style={styles.logoutButtonText}>Log Out</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Referral Modal */}
      <Modal
        visible={showReferralModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowReferralModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.referralModalContainer}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowReferralModal(false)}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <View style={styles.referralModalHeader}>
              <View style={styles.referralIconContainer}>
                <Share2 size={40} color={colors.primary} />
              </View>
              <Text style={styles.referralModalTitle}>Refer Friends</Text>
              <Text style={styles.referralModalSubtitle}>
                Share your code with friends - you get 500 rockets and they get $5 off their first order!
              </Text>
            </View>
            
            <View style={styles.referralCodeContainer}>
              <Text style={styles.referralCodeLabel}>Your Referral Code</Text>
              <View style={styles.referralCodeBox}>
                <Text style={styles.referralCodeText}>{profile.referralCode}</Text>
              </View>
            </View>
            
            <View style={styles.referralStepsContainer}>
              <Text style={styles.referralStepsTitle}>How it works:</Text>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>1</Text>
                </View>
                <Text style={styles.referralStepText}>
                  Share your unique code with friends
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>2</Text>
                </View>
                <Text style={styles.referralStepText}>
                  They enter your code when signing up
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>3</Text>
                </View>
                <Text style={styles.referralStepText}>
                  You get 500 rockets and they get $5 off their first order!
                </Text>
              </View>
            </View>
            
            <TouchableOpacity 
              style={styles.shareReferralButton}
              onPress={handleShareReferral}
            >
              <Share2 size={20} color={colors.background} />
              <Text style={styles.shareReferralButtonText}>Share Your Code</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      
      {/* Smile Settings Modal */}
      <Modal
        visible={showSmileSettingsModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowSmileSettingsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Smile Rewards Settings</Text>
              <TouchableOpacity 
                onPress={() => setShowSmileSettingsModal(false)}
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.smileSettingsContent}>
              <View style={styles.smileSettingsSection}>
                <Text style={styles.smileSettingsSectionTitle}>
                  Account Connection
                </Text>
                <View style={styles.smileConnectionStatus}>
                  <View style={styles.smileConnectionStatusIcon}>
                    <Check size={20} color={colors.background} />
                  </View>
                  <Text style={styles.smileConnectionStatusText}>
                    Your account is connected to Smile Rewards
                  </Text>
                </View>
                
                <View style={styles.smileSettingsOption}>
                  <Text style={styles.smileSettingsOptionLabel}>
                    Auto-sync App Rockets with Smile Points
                  </Text>
                  <Switch
                    value={autoSync}
                    onValueChange={setAutoSync}
                    trackColor={{ false: colors.border, true: colors.primary + '80' }}
                    thumbColor={autoSync ? colors.primary : colors.textLight}
                  />
                </View>
                
                <Text style={styles.smileSettingsDescription}>
                  When auto-sync is enabled, your app rockets will automatically be converted to Smile points (1 rocket = 10 points).
                </Text>
              </View>
              
              <View style={styles.smileSettingsSection}>
                <Text style={styles.smileSettingsSectionTitle}>
                  Points Summary
                </Text>
                <View style={styles.smilePointsRow}>
                  <Text style={styles.smilePointsLabel}>Current Points Balance:</Text>
                  <Text style={styles.smilePointsValue}>{pointsBalance}</Text>
                </View>
                <View style={styles.smilePointsRow}>
                  <Text style={styles.smilePointsLabel}>Lifetime Points Earned:</Text>
                  <Text style={styles.smilePointsValue}>{pointsBalance + 500}</Text>
                </View>
                <View style={styles.smilePointsRow}>
                  <Text style={styles.smilePointsLabel}>Points from App Rockets:</Text>
                  <Text style={styles.smilePointsValue}>{profile.rockets * 10}</Text>
                </View>
              </View>
              
              <TouchableOpacity 
                style={styles.disconnectSmileButton}
                onPress={handleDisconnectSmile}
              >
                <Unlink size={16} color={colors.error} />
                <Text style={styles.disconnectSmileText}>
                  Disconnect from Smile Rewards
                </Text>
              </TouchableOpacity>
            </ScrollView>
            
            <TouchableOpacity 
              style={styles.closeModalButton}
              onPress={() => setShowSmileSettingsModal(false)}
            >
              <Text style={styles.closeModalButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 2,
    borderColor: colors.primary,
  },
  nameContainer: {
    marginLeft: 16,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 4,
    alignSelf: 'flex-start',
    gap: 4,
  },
  levelText: {
    fontSize: 12,
    color: colors.secondary,
    fontWeight: '500',
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  editButtonText: {
    color: colors.textLight,
    fontSize: 14,
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 20,
    paddingTop: 0,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textLight,
    marginTop: 4,
  },
  section: {
    margin: 20,
    marginTop: 0,
    marginBottom: 20,
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    shadowColor: colors.text,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  badgesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  badgeItem: {
    alignItems: 'center',
    width: 70,
  },
  badgeIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  badgeEmoji: {
    fontSize: 24,
  },
  badgeName: {
    fontSize: 12,
    color: colors.text,
    textAlign: 'center',
  },
  emptyText: {
    color: colors.textLight,
    fontStyle: 'italic',
    textAlign: 'center',
    padding: 10,
  },
  bankAccountsContainer: {
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
  },
  bankAccountItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  bankLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: 12,
  },
  bankDetails: {
    flex: 1,
  },
  bankName: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  accountInfo: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 2,
  },
  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  defaultText: {
    fontSize: 12,
    color: colors.secondary,
    fontWeight: '500',
  },
  bankButtonsContainer: {
    flexDirection: 'column',
    marginTop: 16,
    gap: 12,
  },
  addBankButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: colors.backgroundDark + '15',
    borderRadius: 12,
    gap: 8,
  },
  addBankText: {
    color: colors.secondary,
    fontWeight: '500',
  },
  seeDepositsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    backgroundColor: colors.primary + '15',
    borderRadius: 12,
    gap: 8,
  },
  seeDepositsText: {
    color: colors.secondary,
    fontWeight: '500',
  },
  detailsContainer: {
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  detailLabel: {
    fontSize: 14,
    color: colors.textLight,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  referralContainer: {
    alignItems: 'center',
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
  },
  referralText: {
    fontSize: 14,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 16,
  },
  referralCode: {
    backgroundColor: colors.primary + '20',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  referralCodeText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.secondary,
    letterSpacing: 1,
  },
  shareButton: {
    backgroundColor: colors.accent,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  shareButtonText: {
    color: colors.background,
    fontWeight: '500',
  },
  activityContainer: {
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 8,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  activityIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  activityDetails: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
  },
  activitySubtitle: {
    fontSize: 12,
    color: colors.textLight,
  },
  activityTime: {
    fontSize: 12,
    color: colors.textLight,
  },
  // Account section styles
  accountContainer: {
    backgroundColor: colors.background,
    borderRadius: 12,
    overflow: 'hidden',
  },
  accountOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  accountOptionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  logoutIcon: {
    backgroundColor: colors.error + '20',
  },
  accountOptionText: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  logoutText: {
    flex: 1,
    fontSize: 16,
    color: colors.error,
    fontWeight: '500',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    width: '90%',
    maxHeight: '80%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: colors.text,
  },
  closeButton: {
    padding: 5,
  },
  depositsContainer: {
    maxHeight: 400,
  },
  depositItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  depositIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  depositDetails: {
    flex: 1,
  },
  depositAmount: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  depositDescription: {
    fontSize: 14,
    color: colors.text,
    marginTop: 2,
  },
  depositMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  depositBank: {
    fontSize: 12,
    color: colors.secondary,
  },
  depositDate: {
    fontSize: 12,
    color: colors.textLight,
  },
  emptyDeposits: {
    padding: 30,
    alignItems: 'center',
  },
  emptyDepositsText: {
    color: colors.textLight,
    fontStyle: 'italic',
  },
  closeModalButton: {
    backgroundColor: colors.accent,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
  },
  closeModalButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Logout confirmation modal
  confirmModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  confirmModalHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  confirmModalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  confirmModalMessage: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 22,
  },
  confirmModalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: colors.card,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '500',
  },
  logoutButton: {
    flex: 1,
    backgroundColor: colors.error,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  logoutButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '500',
  },
  // Referral Modal Styles
  referralModalContainer: {
    width: '90%',
    backgroundColor: colors.background,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  referralModalHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  referralIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  referralModalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  referralModalSubtitle: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    lineHeight: 22,
  },
  referralCodeContainer: {
    marginBottom: 20,
  },
  referralCodeLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
  },
  referralCodeBox: {
    backgroundColor: colors.primary + '20',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
  },
  referralCodeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.secondary,
    letterSpacing: 2,
  },
  referralStepsContainer: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  referralStepsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  referralStep: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  referralStepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  referralStepNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.background,
  },
  referralStepText: {
    fontSize: 16,
    color: colors.text,
    flex: 1,
  },
  shareReferralButton: {
    backgroundColor: colors.accent,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 12,
    gap: 8,
  },
  shareReferralButtonText: {
    color: colors.background,
    fontSize: 16,
    fontWeight: '600',
  },
  // Smile Rewards styles
  smileSettingsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 8,
    marginTop: 8,
  },
  smileSettingsText: {
    color: colors.textLight,
    fontSize: 14,
  },
  connectSmileContainer: {
    backgroundColor: colors.background,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  connectSmileText: {
    fontSize: 14,
    color: colors.text,
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 20,
  },
  connectSmileButton: {
    backgroundColor: colors.accent,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    gap: 8,
  },
  connectSmileButtonText: {
    color: colors.background,
    fontWeight: '500',
  },
  // Smile Settings Modal
  smileSettingsContent: {
    maxHeight: 400,
  },
  smileSettingsSection: {
    marginBottom: 20,
  },
  smileSettingsSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  smileConnectionStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.primary + '20',
    padding: 12,
    borderRadius: 12,
    marginBottom: 16,
    gap: 12,
  },
  smileConnectionStatusIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  smileConnectionStatusText: {
    fontSize: 14,
    color: colors.secondary,
    flex: 1,
  },
  smileSettingsOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  smileSettingsOptionLabel: {
    fontSize: 14,
    color: colors.text,
    flex: 1,
    marginRight: 12,
  },
  smileSettingsDescription: {
    fontSize: 12,
    color: colors.textLight,
    marginBottom: 16,
  },
  smilePointsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  smilePointsLabel: {
    fontSize: 14,
    color: colors.textLight,
  },
  smilePointsValue: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  disconnectSmileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.error + '20',
    padding: 12,
    borderRadius: 12,
    marginTop: 16,
    gap: 8,
  },
  disconnectSmileText: {
    color: colors.error,
    fontWeight: '500',
  },
});