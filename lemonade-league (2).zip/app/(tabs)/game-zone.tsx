import { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
  Animated,
  Linking,
  Platform,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { 
  MapPin, 
  Medal, 
  Clock, 
  Star, 
  Plus, 
  X, 
  Gift, 
  Filter, 
  Ticket, 
  ExternalLink, 
  DollarSign, 
  ArrowRight, 
  Share2, 
  Rocket, 
  CircleDot, 
  Sparkles, 
  Award, 
  Info, 
  CheckCircle, 
  Calendar, 
  Trophy,
  Users,
  Check,
  Lock,
  TrendingUp,
  Zap,
  ChevronRight
} from 'lucide-react-native';
import { colors } from '@/constants/colors';
import { badges, Badge } from '@/constants/badges';
import { useUserStore } from '@/store/user-store';
import { useRewardsStore } from '@/store/rewards-store';
import { competitionRewards, cityRewards } from '@/constants/rewards';
import SpinWheel from '@/components/SpinWheel';
import BadgeDetailModal from '@/components/BadgeDetailModal';
import LevelProgressBar from '@/components/LevelProgressBar';
import CityVsCity from '@/components/CityVsCity';
import PastCityChallengeCard from '@/components/PastCityChallengeCard';
import type { LeaderboardEntry } from '@/types/sales';
import { currentCityChallenge, pastCityChallenges } from '@/constants/city-challenges';

const MOCK_LEADERS: LeaderboardEntry[] = [
  {
    id: '1',
    name: 'Emma S.',
    avatar: 'https://images.unsplash.com/photo-1588533588400-9f2b1e5bc8c5?w=120&h=120&q=80',
    totalRockets: 456,
    dailyRockets: 45,
    city: 'San Francisco',
    rank: 1,
    badges: ['weekend_warrior', 'top_seller']
  },
  {
    id: '2',
    name: 'Lucas M.',
    avatar: 'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?w=120&h=120&q=80',
    totalRockets: 389,
    dailyRockets: 32,
    city: 'New York',
    rank: 2,
    badges: ['rising_star']
  },
  {
    id: '3',
    name: 'Sophia K.',
    avatar: 'https://images.unsplash.com/photo-1599577180698-a91a7d795d68?w=120&h=120&q=80',
    totalRockets: 367,
    dailyRockets: 28,
    city: 'Chicago',
    rank: 3,
    badges: ['consistent_seller']
  },
  {
    id: '4',
    name: 'Oliver P.',
    avatar: 'https://images.unsplash.com/photo-1599812754751-087153ce5e45?w=120&h=120&q=80',
    totalRockets: 298,
    dailyRockets: 24,
    city: 'Los Angeles',
    rank: 4,
    badges: ['newcomer']
  },
  {
    id: '5',
    name: 'Ava R.',
    avatar: 'https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=120&h=120&q=80',
    totalRockets: 276,
    dailyRockets: 22,
    city: 'Miami',
    rank: 5,
    badges: ['quick_learner']
  },
];

// Extended mock data for ranks 6-20
const EXTENDED_LEADERS: LeaderboardEntry[] = [
  {
    id: '6',
    name: 'Noah T.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
    totalRockets: 254,
    dailyRockets: 20,
    city: 'Boston',
    rank: 6,
    badges: ['consistent_seller']
  },
  {
    id: '7',
    name: 'Isabella J.',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&q=80',
    totalRockets: 243,
    dailyRockets: 19,
    city: 'Seattle',
    rank: 7,
    badges: ['weekend_warrior']
  },
  {
    id: '8',
    name: 'Ethan L.',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&h=120&q=80',
    totalRockets: 231,
    dailyRockets: 18,
    city: 'Denver',
    rank: 8,
    badges: ['rising_star']
  },
  {
    id: '9',
    name: 'Mia C.',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&h=120&q=80',
    totalRockets: 219,
    dailyRockets: 17,
    city: 'Austin',
    rank: 9,
    badges: ['quick_learner']
  },
  {
    id: '10',
    name: 'James W.',
    avatar: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?w=120&h=120&q=80',
    totalRockets: 208,
    dailyRockets: 16,
    city: 'Portland',
    rank: 10,
    badges: ['newcomer']
  },
  {
    id: '11',
    name: 'Charlotte B.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
    totalRockets: 197,
    dailyRockets: 15,
    city: 'Atlanta',
    rank: 11,
    badges: ['consistent_seller']
  },
  {
    id: '12',
    name: 'Benjamin H.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&h=120&q=80',
    totalRockets: 186,
    dailyRockets: 14,
    city: 'Philadelphia',
    rank: 12,
    badges: ['weekend_warrior']
  },
  {
    id: '13',
    name: 'Amelia G.',
    avatar: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=120&h=120&q=80',
    totalRockets: 175,
    dailyRockets: 13,
    city: 'San Diego',
    rank: 13,
    badges: ['rising_star']
  },
  {
    id: '14',
    name: 'Henry F.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=120&h=120&q=80',
    totalRockets: 164,
    dailyRockets: 12,
    city: 'Dallas',
    rank: 14,
    badges: ['quick_learner']
  },
  {
    id: '15',
    name: 'Evelyn D.',
    avatar: 'https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?w=120&h=120&q=80',
    totalRockets: 153,
    dailyRockets: 11,
    city: 'Houston',
    rank: 15,
    badges: ['newcomer']
  },
  {
    id: '16',
    name: 'Alexander S.',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&h=120&q=80',
    totalRockets: 142,
    dailyRockets: 10,
    city: 'Phoenix',
    rank: 16,
    badges: ['consistent_seller']
  },
  {
    id: '17',
    name: 'Harper R.',
    avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=120&h=120&q=80',
    totalRockets: 131,
    dailyRockets: 9,
    city: 'Las Vegas',
    rank: 17,
    badges: ['weekend_warrior']
  },
  {
    id: '18',
    name: 'Michael Q.',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&h=120&q=80',
    totalRockets: 120,
    dailyRockets: 8,
    city: 'Nashville',
    rank: 18,
    badges: ['rising_star']
  },
  {
    id: '19',
    name: 'Abigail P.',
    avatar: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=120&h=120&q=80',
    totalRockets: 109,
    dailyRockets: 7,
    city: 'New Orleans',
    rank: 19,
    badges: ['quick_learner']
  },
  {
    id: '20',
    name: 'Daniel O.',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=120&h=120&q=80',
    totalRockets: 98,
    dailyRockets: 6,
    city: 'Salt Lake City',
    rank: 20,
    badges: ['newcomer']
  },
];

// Combine the original leaders with the extended leaders
const ALL_LEADERS = [...MOCK_LEADERS, ...EXTENDED_LEADERS];

type TabType = 'rewards' | 'competition' | 'challenges';
type BadgeFilterType = 'all' | 'earned' | 'locked' | 'milestone' | 'achievement' | 'special';

export default function GameZoneScreen() {
  const [activeTab, setActiveTab] = useState<TabType>('rewards');
  const [badgeFilter, setBadgeFilter] = useState<BadgeFilterType>('all');
  const [leaders] = useState<LeaderboardEntry[]>(ALL_LEADERS);
  const [showWheelModal, setShowWheelModal] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState('');
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);
  const [showBadgeModal, setShowBadgeModal] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);
  const [showRocketsInfoModal, setShowRocketsInfoModal] = useState(false);
  const [showGoldenTicketInfoModal, setShowGoldenTicketInfoModal] = useState(false);
  const [showRedeemModal, setShowRedeemModal] = useState(false);
  
  const { 
    profile, 
    getLevelInfo,
    getRocketsToNextLevel,
    addRockets 
  } = useUserStore();
  
  const { wheelSpinsAvailable, spinWheel } = useRewardsStore();
  
  const { level, title, progress } = getLevelInfo();
  const rocketsToNextLevel = getRocketsToNextLevel();
  const earnedBadgeIds = profile.badges;
  
  // Calculate total rockets earned (current + spent)
  // Ensure rocketsSpent is a number with a fallback to 0 if undefined
  const totalRocketsEarned = profile.rockets + (profile.rocketsSpent || 0);
  
  // Find user's rank in the competition
  const userRank = 89; // Mocked rank, would come from API
  
  // Calculate city battle potential rewards
  const cityBattleMaxReward = 300;
  
  // Calculate weekly competition potential rewards
  const weeklyCompMaxReward = 2500;
  
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const rocketsScaleAnim = useRef(new Animated.Value(1)).current;
  const ticketScaleAnim = useRef(new Animated.Value(1)).current;
  const wheelAnimationRef = useRef<Animated.CompositeAnimation | null>(null);
  const rocketsAnimationRef = useRef<Animated.CompositeAnimation | null>(null);
  const ticketAnimationRef = useRef<Animated.CompositeAnimation | null>(null);
  
  // Pulse animation for rockets
  useEffect(() => {
    const pulseAnimation = Animated.sequence([
      Animated.timing(rocketsScaleAnim, {
        toValue: 1.05,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(rocketsScaleAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      })
    ]);
    
    rocketsAnimationRef.current = Animated.loop(pulseAnimation);
    rocketsAnimationRef.current.start();
    
    return () => {
      if (rocketsAnimationRef.current) {
        rocketsAnimationRef.current.stop();
        rocketsAnimationRef.current = null;
      }
      rocketsScaleAnim.stopAnimation();
    };
  }, []);
  
  // Pulse animation for golden ticket
  useEffect(() => {
    const ticketPulseAnimation = Animated.sequence([
      Animated.timing(ticketScaleAnim, {
        toValue: 1.1,
        duration: 1200,
        useNativeDriver: true,
      }),
      Animated.timing(ticketScaleAnim, {
        toValue: 1,
        duration: 1200,
        useNativeDriver: true,
      })
    ]);
    
    ticketAnimationRef.current = Animated.loop(ticketPulseAnimation);
    ticketAnimationRef.current.start();
    
    return () => {
      if (ticketAnimationRef.current) {
        ticketAnimationRef.current.stop();
        ticketAnimationRef.current = null;
      }
      ticketScaleAnim.stopAnimation();
    };
  }, []);
  
  // Calculate time remaining until Sunday midnight with seconds
  useEffect(() => {
    const calculateTimeRemaining = () => {
      const now = new Date();
      const daysUntilSunday = 7 - now.getDay();
      const nextSunday = new Date(now);
      
      // If today is Sunday, we want next Sunday, not today
      nextSunday.setDate(now.getDate() + (daysUntilSunday === 0 ? 7 : daysUntilSunday));
      nextSunday.setHours(23, 59, 59, 999);
      
      const diffMs = nextSunday.getTime() - now.getTime();
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      const diffHrs = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      const diffSecs = Math.floor((diffMs % (1000 * 60)) / 1000);
      
      return `${diffDays}d ${diffHrs}h ${diffMins}m ${diffSecs}s`;
    };
    
    // Update time remaining every second
    const updateTimeRemaining = () => {
      setTimeRemaining(calculateTimeRemaining());
    };
    
    updateTimeRemaining();
    const interval = setInterval(updateTimeRemaining, 1000); // Update every second
    
    return () => clearInterval(interval);
  }, []);
  
  const handleSpinWheel = () => {
    // Fade out animation
    wheelAnimationRef.current = Animated.timing(fadeAnim, {
      toValue: 0.3,
      duration: 300,
      useNativeDriver: true,
    });
    wheelAnimationRef.current.start();
  };
  
  const handleRewardSelected = (rewardIndex: number) => {
    // Get the reward from the spin
    const reward = spinWheel();
    
    // Add rockets if rockets reward
    if (reward.type === 'rockets') {
      addRockets(reward.value as number, 'wheel_spin');
    }
    
    // Fade back in animation
    if (wheelAnimationRef.current) {
      wheelAnimationRef.current.stop();
    }
    
    wheelAnimationRef.current = Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    });
    wheelAnimationRef.current.start();
  };

  const handleBadgePress = (badge: Badge) => {
    setSelectedBadge(badge);
    setShowBadgeModal(true);
  };

  const isBadgeUnlocked = (badge: Badge) => {
    return earnedBadgeIds.includes(badge.id);
  };

  const getFilteredBadges = () => {
    let filteredBadges = [...badges];
    
    switch (badgeFilter) {
      case 'earned':
        filteredBadges = filteredBadges.filter(badge => earnedBadgeIds.includes(badge.id));
        break;
      case 'locked':
        filteredBadges = filteredBadges.filter(badge => !earnedBadgeIds.includes(badge.id));
        break;
      case 'milestone':
      case 'achievement':
      case 'special':
        filteredBadges = filteredBadges.filter(badge => badge.type === badgeFilter);
        break;
    }
    
    return filteredBadges;
  };

  const handleOpenStore = () => {
    Linking.openURL('https://mylilstartup.com');
  };

  const handleShareReferral = async () => {
    try {
      if (Platform.OS === 'web') {
        Alert.alert(
          "Share Referral Code",
          `Your referral code is ${profile.referralCode}. Share this with friends to earn 500 rockets!`
        );
      } else {
        // This would use the native share functionality on mobile
        Alert.alert(
          "Share Referral Code",
          `Your referral code is ${profile.referralCode}. Share this with friends to earn 500 rockets!`
        );
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };
  
  // Clean up animations when component unmounts
  useEffect(() => {
    return () => {
      if (wheelAnimationRef.current) {
        wheelAnimationRef.current.stop();
        wheelAnimationRef.current = null;
      }
      if (rocketsAnimationRef.current) {
        rocketsAnimationRef.current.stop();
        rocketsAnimationRef.current = null;
      }
      if (ticketAnimationRef.current) {
        ticketAnimationRef.current.stop();
        ticketAnimationRef.current = null;
      }
      fadeAnim.stopAnimation();
      rocketsScaleAnim.stopAnimation();
      ticketScaleAnim.stopAnimation();
    };
  }, []);
  
  const TopThreeSellers = () => (
    <View style={styles.topSellers}>
      {/* Second Place */}
      <View style={[styles.topSellerCard, styles.secondPlace]}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: leaders[1].avatar }}
            style={styles.avatar}
            defaultSource={require('@/assets/images/icon.png')}
          />
          <View style={[styles.badge, styles.badgeSilver]}>
            <Text style={styles.badgeText}>2</Text>
          </View>
        </View>
        <Text style={styles.sellerName}>{leaders[1].name}</Text>
        <View style={styles.rocketCountContainer}>
          <Rocket size={16} color={colors.primary} />
          <Text style={styles.sellerAmount}>{leaders[1].totalRockets}</Text>
        </View>
        <View style={styles.prizeContainer}>
          <Rocket size={14} color={colors.primary} />
          <Text style={styles.prizeText}>
            {`${competitionRewards.national[1].value} Rockets`}
          </Text>
        </View>
      </View>

      {/* First Place */}
      <View style={[styles.topSellerCard, styles.firstPlace]}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: leaders[0].avatar }}
            style={[styles.avatar, styles.avatarLarge]}
            defaultSource={require('@/assets/images/icon.png')}
          />
          <View style={[styles.badge, styles.badgeGold]}>
            <Text style={styles.badgeText}>1</Text>
          </View>
        </View>
        <Text style={[styles.sellerName, styles.firstPlaceName]}>{leaders[0].name}</Text>
        <View style={styles.rocketCountContainer}>
          <Rocket size={18} color={colors.primary} />
          <Text style={[styles.sellerAmount, styles.firstPlaceAmount]}>{leaders[0].totalRockets}</Text>
        </View>
        <View style={styles.firstPlacePrizes}>
          <View style={[styles.prizeContainer, styles.firstPrizeContainer]}>
            <Ticket size={16} color={colors.primary} />
            <Text style={[styles.prizeText, styles.firstPrizeText]}>
              Golden Ticket
            </Text>
          </View>
          <View style={[styles.prizeContainer, styles.firstPrizeContainer]}>
            <Rocket size={16} color={colors.primary} />
            <Text style={[styles.prizeText, styles.firstPrizeText]}>
              2500 Rockets
            </Text>
          </View>
        </View>
      </View>

      {/* Third Place */}
      <View style={[styles.topSellerCard, styles.thirdPlace]}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: leaders[2].avatar }}
            style={styles.avatar}
            defaultSource={require('@/assets/images/icon.png')}
          />
          <View style={[styles.badge, styles.badgeBronze]}>
            <Text style={styles.badgeText}>3</Text>
          </View>
        </View>
        <Text style={styles.sellerName}>{leaders[2].name}</Text>
        <View style={styles.rocketCountContainer}>
          <Rocket size={16} color={colors.primary} />
          <Text style={styles.sellerAmount}>{leaders[2].totalRockets}</Text>
        </View>
        <View style={styles.prizeContainer}>
          <Rocket size={14} color={colors.primary} />
          <Text style={styles.prizeText}>
            {`${competitionRewards.national[2].value} Rockets`}
          </Text>
        </View>
      </View>
    </View>
  );
  
  const renderCompetitionTab = () => (
    <>
      <View style={styles.competitionHeader}>
        <Text style={styles.competitionTitle}>Weekly Rockets Competition</Text>
        <View style={styles.countdownContainer}>
          <Clock size={16} color={colors.primary} />
          <Text style={styles.countdownText}>
            Ends in: {timeRemaining}
          </Text>
        </View>
      </View>

      <TopThreeSellers />

      <View style={styles.listContainer}>
        <Text style={styles.listTitle}>All Competitors</Text>
        
        {/* Show ranks 4-20 */}
        {leaders.slice(3, 20).map((seller) => (
          <View key={seller.id} style={styles.listItem}>
            <Text style={styles.rank}>#{seller.rank}</Text>
            <Image
              source={{ uri: seller.avatar }}
              style={styles.listAvatar}
              defaultSource={require('@/assets/images/icon.png')}
            />
            <View style={styles.sellerInfo}>
              <Text style={styles.listName}>{seller.name}</Text>
              <View style={styles.location}>
                <MapPin size={12} color={colors.textLight} />
                <Text style={styles.cityText}>{seller.city}</Text>
              </View>
            </View>
            <View style={styles.rocketCountRow}>
              <Rocket size={16} color={colors.primary} />
              <Text style={styles.amount}>{seller.totalRockets}</Text>
            </View>
          </View>
        ))}
        
        {/* Divider between top 20 and user's rank */}
        <View style={styles.rankDivider}>
          <View style={styles.rankDividerLine} />
          <Text style={styles.rankDividerText}>• • •</Text>
          <View style={styles.rankDividerLine} />
        </View>
        
        {/* User's rank at 89 */}
        <View style={styles.listItem} key="user-rank">
          <Text style={[styles.rank, styles.userRank]}>#{userRank}</Text>
          <Image
            source={{ uri: profile.avatar || 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=120&h=120&q=80' }}
            style={[styles.listAvatar, styles.userAvatar]}
            defaultSource={require('@/assets/images/icon.png')}
          />
          <View style={styles.sellerInfo}>
            <Text style={[styles.listName, styles.userName]}>You</Text>
            <View style={styles.location}>
              <MapPin size={12} color={colors.textLight} />
              <Text style={styles.cityText}>{profile.city || 'San Diego'}</Text>
            </View>
          </View>
          <View style={styles.rocketCountRow}>
            <Rocket size={16} color={colors.primary} />
            <Text style={styles.amount}>{profile.rockets}</Text>
          </View>
        </View>
      </View>
    </>
  );
  
  const renderChallengesTab = () => (
    <View style={styles.challengesContainer}>
      {/* Current City Challenge */}
      <CityVsCity 
        challenge={currentCityChallenge}
        timeRemaining={timeRemaining}
      />
      
      {/* Past Challenges */}
      <View style={styles.pastChallengesContainer}>
        <Text style={styles.pastChallengesTitle}>Past City Battles</Text>
        {pastCityChallenges.map(challenge => (
          <PastCityChallengeCard 
            key={challenge.id}
            challenge={challenge}
          />
        ))}
      </View>
    </View>
  );
  
  const renderRewardsTab = () => (
    <>
      {/* New Rockets Header */}
      <LinearGradient
        colors={[colors.primary, colors.secondary]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.rocketsHeader}
      >
        <View style={styles.rocketsHeaderContent}>
          <View style={styles.rocketsIconContainer}>
            <Rocket size={40} color="#FFFFFF" />
          </View>
          
          <Text style={styles.rocketsHeaderTitle}>Rockets</Text>
          
          <View style={styles.rocketsCountContainer}>
            <Text style={styles.rocketsCount}>{profile.rockets}</Text>
            <Text style={styles.rocketsAvailable}>available</Text>
          </View>
          
          <View style={styles.rocketsDescriptionRow}>
            <Text style={styles.rocketsDescription}>
              Redeem rockets for discounts and exclusive items
            </Text>
            
            <TouchableOpacity 
              style={styles.visitStoreButton}
              onPress={handleOpenStore}
            >
              <Text style={styles.visitStoreButtonText}>Visit Store</Text>
              <ExternalLink size={18} color={colors.background} />
            </TouchableOpacity>
          </View>
        </View>
      </LinearGradient>
      
      <View style={styles.rewardsHeader}>
        {/* Ways to Earn Rockets Section */}
        <View style={styles.waysToEarnContainer}>
          <Text style={styles.waysToEarnTitle}>Ways to Earn Rockets</Text>
          
          {/* 1. Level Up & Spin the Wheel */}
          <TouchableOpacity 
            style={styles.earnMethodCard}
            onPress={() => setShowWheelModal(true)}
            activeOpacity={0.8}
          >
            <View style={styles.earnMethodIconContainer}>
              <CircleDot size={28} color={colors.primary} />
            </View>
            <View style={styles.earnMethodContent}>
              <View style={styles.earnMethodHeader}>
                <Text style={styles.earnMethodTitle}>Level Up & Spin the Wheel</Text>
                <View style={styles.earnMethodReward}>
                  <Rocket size={14} color={colors.accent} />
                  <Text style={styles.earnMethodRewardText}>Win up to 25</Text>
                </View>
              </View>
              
              <View style={styles.earnMethodProgressContainer}>
                <View style={styles.earnMethodProgressBar}>
                  <View 
                    style={[
                      styles.earnMethodProgressFill, 
                      { width: `${progress * 100}%` }
                    ]} 
                  />
                </View>
                <View style={styles.earnMethodProgressInfo}>
                  <Text style={styles.earnMethodProgressText}>
                    Level {level} • {Math.round(progress * 100)}%
                  </Text>
                  <Text style={styles.earnMethodProgressRockets}>
                    <Rocket size={12} color={colors.textLight} /> {rocketsToNextLevel} to next level
                  </Text>
                </View>
              </View>
            </View>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
          
          {/* 2. City Battles */}
          <TouchableOpacity 
            style={styles.earnMethodCard}
            onPress={() => setActiveTab('challenges')}
            activeOpacity={0.8}
          >
            <View style={styles.earnMethodIconContainer}>
              <Trophy size={28} color={colors.primary} />
            </View>
            <View style={styles.earnMethodContent}>
              <View style={styles.earnMethodHeader}>
                <Text style={styles.earnMethodTitle}>City Battles</Text>
                <View style={styles.earnMethodReward}>
                  <Rocket size={14} color={colors.accent} />
                  <Text style={styles.earnMethodRewardText}>Win up to {cityBattleMaxReward}</Text>
                </View>
              </View>
              
              <View style={styles.cityBattleStatus}>
                <View style={styles.cityBattleTeams}>
                  <View style={styles.cityBattleTeam}>
                    <Text style={styles.cityBattleTeamName}>
                      {currentCityChallenge.city1.id === 'san_diego' ? 'Your City' : currentCityChallenge.city1.name}
                    </Text>
                    <View style={styles.cityBattleRockets}>
                      <Rocket size={12} color={colors.primary} />
                      <Text style={styles.cityBattleRocketsText}>
                        {currentCityChallenge.city1.totalRockets}
                      </Text>
                    </View>
                  </View>
                  
                  <Text style={styles.cityBattleVs}>vs</Text>
                  
                  <View style={styles.cityBattleTeam}>
                    <Text style={styles.cityBattleTeamName}>
                      {currentCityChallenge.city2.id === 'san_diego' ? 'Your City' : currentCityChallenge.city2.name}
                    </Text>
                    <View style={styles.cityBattleRockets}>
                      <Rocket size={12} color={colors.primary} />
                      <Text style={styles.cityBattleRocketsText}>
                        {currentCityChallenge.city2.totalRockets}
                      </Text>
                    </View>
                  </View>
                </View>
                
                <View style={styles.cityBattleTimeRemaining}>
                  <Clock size={14} color={colors.textLight} />
                  <Text style={styles.cityBattleTimeText}>
                    {timeRemaining}
                  </Text>
                </View>
              </View>
            </View>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
          
          {/* 3. Weekly Rocket Competition */}
          <TouchableOpacity 
            style={styles.earnMethodCard}
            onPress={() => setActiveTab('competition')}
            activeOpacity={0.8}
          >
            <View style={styles.earnMethodIconContainer}>
              <Medal size={28} color={colors.primary} />
            </View>
            <View style={styles.earnMethodContent}>
              <View style={styles.earnMethodHeader}>
                <Text style={styles.earnMethodTitle}>Weekly Rocket Competition</Text>
                <View style={styles.earnMethodReward}>
                  <Rocket size={14} color={colors.accent} />
                  <Text style={styles.earnMethodRewardText}>Win up to {weeklyCompMaxReward}</Text>
                </View>
              </View>
              
              <View style={styles.competitionStatus}>
                <View style={styles.competitionRank}>
                  <View style={styles.competitionRankBadge}>
                    <Text style={styles.competitionRankText}>#{userRank}</Text>
                  </View>
                  <Text style={styles.competitionRankLabel}>Your Rank</Text>
                </View>
                
                <View style={styles.competitionTopThree}>
                  {leaders.slice(0, 3).map((leader, index) => (
                    <View key={leader.id} style={styles.competitionTopUser}>
                      <Image 
                        source={{ uri: leader.avatar }}
                        style={styles.competitionTopUserAvatar}
                      />
                      <View style={[
                        styles.competitionTopUserRank,
                        index === 0 ? styles.rankGold : 
                        index === 1 ? styles.rankSilver : 
                        styles.rankBronze
                      ]}>
                        <Text style={styles.competitionTopUserRankText}>{index + 1}</Text>
                      </View>
                    </View>
                  ))}
                </View>
                
                <View style={styles.competitionTimeRemaining}>
                  <Clock size={14} color={colors.textLight} />
                  <Text style={styles.competitionTimeText}>
                    {timeRemaining}
                  </Text>
                </View>
              </View>
            </View>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
          
          {/* 4. Refer a Friend */}
          <TouchableOpacity 
            style={styles.earnMethodCard}
            onPress={() => setShowReferralModal(true)}
            activeOpacity={0.8}
          >
            <View style={styles.earnMethodIconContainer}>
              <Share2 size={28} color={colors.primary} />
            </View>
            <View style={styles.earnMethodContent}>
              <View style={styles.earnMethodHeader}>
                <Text style={styles.earnMethodTitle}>Refer a Friend</Text>
                <View style={styles.earnMethodReward}>
                  <Rocket size={14} color={colors.accent} />
                  <Text style={styles.earnMethodRewardText}>Win 500 per referral</Text>
                </View>
              </View>
              
              <View style={styles.referralCodeContainer}>
                <Text style={styles.referralCodeLabel}>Your code:</Text>
                <View style={styles.referralCode}>
                  <Text style={styles.referralCodeText}>{profile.referralCode}</Text>
                  <TouchableOpacity 
                    style={styles.referralShareButton}
                    onPress={handleShareReferral}
                  >
                    <Share2 size={16} color={colors.background} />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <ChevronRight size={20} color={colors.textLight} />
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
  
  return (
    <View style={styles.container}>
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'rewards' && styles.activeTab]}
          onPress={() => setActiveTab('rewards')}
        >
          <Gift 
            size={20} 
            color={activeTab === 'rewards' ? colors.primary : colors.textLight} 
          />
          <Text style={[
            styles.tabText,
            activeTab === 'rewards' && styles.activeTabText
          ]}>
            Rewards
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'competition' && styles.activeTab]}
          onPress={() => setActiveTab('competition')}
        >
          <Medal 
            size={20} 
            color={activeTab === 'competition' ? colors.primary : colors.textLight} 
          />
          <Text style={[
            styles.tabText,
            activeTab === 'competition' && styles.activeTabText
          ]}>
            Competition
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'challenges' && styles.activeTab]}
          onPress={() => setActiveTab('challenges')}
        >
          <Trophy 
            size={20} 
            color={activeTab === 'challenges' ? colors.primary : colors.textLight} 
          />
          <Text style={[
            styles.tabText,
            activeTab === 'challenges' && styles.activeTabText
          ]}>
            City Battles
          </Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'rewards' && renderRewardsTab()}
        {activeTab === 'competition' && renderCompetitionTab()}
        {activeTab === 'challenges' && renderChallengesTab()}
      </ScrollView>
      
      {/* Spin Wheel Modal */}
      <Modal
        visible={showWheelModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowWheelModal(false)}
      >
        <View style={styles.modalOverlay}>
          <Animated.View 
            style={[
              styles.wheelModalContainer,
              { opacity: fadeAnim }
            ]}
          >
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => {
                // Stop any ongoing animations
                if (wheelAnimationRef.current) {
                  wheelAnimationRef.current.stop();
                  wheelAnimationRef.current = null;
                }
                fadeAnim.setValue(1);
                setShowWheelModal(false);
              }}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <SpinWheel 
              onSpin={handleSpinWheel}
              onRewardSelected={handleRewardSelected}
              spinsAvailable={wheelSpinsAvailable}
            />
          </Animated.View>
        </View>
      </Modal>
      
      {/* Badge Detail Modal */}
      <BadgeDetailModal 
        visible={showBadgeModal}
        badge={selectedBadge}
        isUnlocked={selectedBadge ? isBadgeUnlocked(selectedBadge) : false}
        onClose={() => setShowBadgeModal(false)}
      />
      
      {/* Referral Modal */}
      <Modal
        visible={showReferralModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowReferralModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.referralModalContainer}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowReferralModal(false)}
            >
              <X size={24} color={colors.text} />
            </TouchableOpacity>
            
            <View style={styles.referralModalHeader}>
              <View style={styles.referralIconContainer}>
                <Share2 size={40} color={colors.primary} />
              </View>
              <Text style={styles.referralModalTitle}>Refer Friends</Text>
              <Text style={styles.referralModalSubtitle}>
                Share your code with friends - you get 500 rockets and they get $5 off their first order!
              </Text>
            </View>
            
            <View style={styles.referralCodeContainer}>
              <Text style={styles.referralCodeLabel}>Your Referral Code</Text>
              <View style={styles.referralCodeBox}>
                <Text style={styles.referralCodeText}>{profile.referralCode}</Text>
              </View>
            </View>
            
            <View style={styles.referralStepsContainer}>
              <Text style={styles.referralStepsTitle}>How it works:</Text>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>1</Text>
                </View>
                <Text style={styles.referralStepText}>
                  Share your unique code with friends
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>2</Text>
                </View>
                <Text style={styles.referralStepText}>
                  They enter your code when signing up
                </Text>
              </View>
              <View style={styles.referralStep}>
                <View style={styles.referralStepNumber}>
                  <Text style={styles.referralStepNumberText}>3</Text>
                </View>
                <Text style={styles.referralStepText}>
                  You get 500 rockets and they get $5 off their first order!
                </Text>
              </View>
            </View>
            
            <TouchableOpacity 
              style={styles.shareReferralButton}
              onPress={handleShareReferral}
            >
              <Share2 size={20} color={colors.background} />
              <Text style={styles.shareReferralButtonText}>Share Your Code</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      
      {/* Rockets Info Modal */}
      <Modal
        visible={showRocketsInfoModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowRocketsInfoModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.rocketsInfoModalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>About Rockets</Text>
              <TouchableOpacity 
                onPress={() => setShowRocketsInfoModal(false)} 
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.rocketsInfoContent}>
              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>What are Rockets?</Text>
                <Text style={styles.rocketsInfoText}>
                  Rockets are rewards you earn for your sales. They get you discounts, free shipping, and even free products at MyLilStartup.com!
                </Text>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Earn Rockets</Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <DollarSign size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Sales:</Text> Earn 1 rocket for every $2 in sales
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Star size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Lucky Sales:</Text> 20% chance to earn 5 bonus rockets on any sale
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <CircleDot size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Level Up:</Text> Spin the wheel to win rockets each time you level up
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Award size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Competitions:</Text> Win rockets by ranking in weekly competitions
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Trophy size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>City Battles:</Text> Win rockets when your city wins in weekly city battles
                  </Text>
                </View>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Redeem Rockets</Text>
                <Text style={styles.rocketsInfoText}>
                  Visit MyLilStartup.com and use your rockets at checkout for:
                </Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Discounts on products</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Free shipping</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color={colors.primary} />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Special items only available with rockets</Text>
                </View>
              </View>

              <TouchableOpacity 
                style={styles.referFriendsButton}
                onPress={() => {
                  setShowRocketsInfoModal(false);
                  setShowReferralModal(true);
                }}
              >
                <Text style={styles.referFriendsButtonText}>Refer Friends & Earn 500 Rockets</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Golden Ticket Info Modal */}
      <Modal
        visible={showGoldenTicketInfoModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowGoldenTicketInfoModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.rocketsInfoModalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Golden Tickets</Text>
              <TouchableOpacity 
                onPress={() => setShowGoldenTicketInfoModal(false)} 
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.rocketsInfoContent}>
              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>What are Golden Tickets?</Text>
                <Text style={styles.rocketsInfoText}>
                  Golden Tickets are special rewards that can be redeemed for premium items in the My Lil Startup store!
                </Text>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Earn Golden Tickets</Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Medal size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Competition:</Text> Win 1st place in the nationwide weekly competition
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Award size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Special Events:</Text> Participate in special seasonal events
                  </Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Star size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>
                    <Text style={styles.rocketsInfoBold}>Wheel Spins:</Text> Rare chance to win from the prize wheel
                  </Text>
                </View>
              </View>

              <View style={styles.rocketsInfoSection}>
                <Text style={styles.rocketsInfoTitle}>How to Redeem Golden Tickets</Text>
                <Text style={styles.rocketsInfoText}>
                  Visit MyLilStartup.com and use your Golden Tickets for:
                </Text>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Exclusive premium products</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>Special limited edition items</Text>
                </View>
                
                <View style={styles.rocketsInfoItem}>
                  <View style={styles.rocketsInfoBullet}>
                    <Check size={16} color="#FFD700" />
                  </View>
                  <Text style={styles.rocketsInfoItemText}>VIP experiences and events</Text>
                </View>
              </View>

              <TouchableOpacity 
                style={styles.storeVisitButton}
                onPress={handleOpenStore}
              >
                <Text style={styles.storeVisitButtonText}>Visit Store to Redeem</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Redeem Rockets Modal */}
      <Modal
        visible={showRedeemModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowRedeemModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.redeemModalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Redeem Your Rockets</Text>
              <TouchableOpacity 
                onPress={() => setShowRedeemModal(false)} 
                style={styles.closeButton}
              >
                <X size={24} color={colors.text} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.redeemModalContent}>
              <View style={styles.redeemRocketsBalance}>
                <Rocket size={24} color={colors.primary} />
                <Text style={styles.redeemRocketsBalanceText}>
                  {profile.rockets} Rockets Available
                </Text>
              </View>

              <Text style={styles.redeemOptionsTitle}>Redeem Options</Text>

              <TouchableOpacity style={styles.redeemOption} onPress={handleOpenStore}>
                <View style={styles.redeemOptionIconContainer}>
                  <DollarSign size={24} color={colors.background} />
                </View>
                <View style={styles.redeemOptionContent}>
                  <Text style={styles.redeemOptionTitle}>$5 Off Your Order</Text>
                  <Text style={styles.redeemOptionDescription}>
                    Get $5 off your next purchase at MyLilStartup.com
                  </Text>
                  <View style={styles.redeemOptionCost}>
                    <Rocket size={14} color={colors.primary} />
                    <Text style={styles.redeemOptionCostText}>100 Rockets</Text>
                  </View>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.redeemOption} onPress={handleOpenStore}>
                <View style={[styles.redeemOptionIconContainer, { backgroundColor: colors.secondary }]}>
                  <TrendingUp size={24} color={colors.background} />
                </View>
                <View style={styles.redeemOptionContent}>
                  <Text style={styles.redeemOptionTitle}>$10 Off Your Order</Text>
                  <Text style={styles.redeemOptionDescription}>
                    Get $10 off your next purchase at MyLilStartup.com
                  </Text>
                  <View style={styles.redeemOptionCost}>
                    <Rocket size={14} color={colors.primary} />
                    <Text style={styles.redeemOptionCostText}>200 Rockets</Text>
                  </View>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.redeemOption} onPress={handleOpenStore}>
                <View style={[styles.redeemOptionIconContainer, { backgroundColor: colors.accent }]}>
                  <Gift size={24} color={colors.background} />
                </View>
                <View style={styles.redeemOptionContent}>
                  <Text style={styles.redeemOptionTitle}>Free Shipping</Text>
                  <Text style={styles.redeemOptionDescription}>
                    Get free shipping on your next order at MyLilStartup.com
                  </Text>
                  <View style={styles.redeemOptionCost}>
                    <Rocket size={14} color={colors.primary} />
                    <Text style={styles.redeemOptionCostText}>150 Rockets</Text>
                  </View>
                </View>
              </TouchableOpacity>

              <TouchableOpacity style={styles.redeemOption} onPress={handleOpenStore}>
                <View style={[styles.redeemOptionIconContainer, { backgroundColor: '#FFD700' }]}>
                  <Award size={24} color={colors.background} />
                </View>
                <View style={styles.redeemOptionContent}>
                  <Text style={styles.redeemOptionTitle}>Exclusive Product</Text>
                  <Text style={styles.redeemOptionDescription}>
                    Unlock an exclusive product only available with rockets
                  </Text>
                  <View style={styles.redeemOptionCost}>
                    <Rocket size={14} color={colors.primary} />
                    <Text style={styles.redeemOptionCostText}>500 Rockets</Text>
                  </View>
                </View>
              </TouchableOpacity>

              <Text style={styles.redeemNote}>
                Visit MyLilStartup.com to see all available redemption options. Rockets can be redeemed at checkout.
              </Text>

              <TouchableOpacity 
                style={styles.visitStoreButton}
                onPress={handleOpenStore}
              >
                <Text style={styles.visitStoreButtonText}>Visit Store</Text>
                <ExternalLink size={18} color={colors.background} />
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: colors.primary,
  },
  tabText: {
    fontSize: 14,
    color: colors.textLight,
    fontWeight: '500',
  },
  activeTabText: {
    color: colors.primary,
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  // New Rockets Header Styles
  rocketsHeader: {
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    overflow: 'hidden',
  },
  rocketsHeaderContent: {
    padding: 20, // Reduced padding to make header smaller
    alignItems: 'center',
  },
  rocketsIconContainer: {
    width: 70, // Slightly smaller icon container
    height: 70,
    borderRadius: 35,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12, // Reduced margin
  },
  rocketsHeaderTitle: {
    fontSize: 22, // Slightly smaller font
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 6, // Reduced margin
  },
  rocketsCountContainer: {
    alignItems: 'center',
    marginBottom: 12, // Reduced margin
  },
  rocketsCount: {
    fontSize: 32, // Slightly smaller font
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  rocketsAvailable: {
    fontSize: 14, // Slightly smaller font
    color: 'rgba(255, 255, 255, 0.8)',
  },
  rocketsDescriptionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 10,
  },
  rocketsDescription: {
    fontSize: 14, // Slightly smaller font
    color: '#FFFFFF',
    flex: 1,
    marginRight: 10,
  },
  visitStoreButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    gap: 6,
  },
  visitStoreButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.primary,
  },
  // Rewards Tab Styles
  rewardsHeader: {
    padding: 16,
  },
  waysToEarnContainer: {
    marginBottom: 24,
  },
  waysToEarnTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  earnMethodCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  earnMethodIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: colors.cardLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  earnMethodContent: {
    flex: 1,
    marginRight: 8,
  },
  earnMethodHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  earnMethodTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    flex: 1,
  },
  earnMethodReward: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.cardLight,
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 12,
    gap: 4,
  },
  earnMethodRewardText: {
    fontSize: 12,
    color: colors.text,
    fontWeight: '500',
  },
  earnMethodProgressContainer: {
    marginTop: 4,
  },
  earnMethodProgressBar: {
    height: 8,
    backgroundColor: colors.cardLight,
    borderRadius: 4,
    marginBottom: 8,
    overflow: 'hidden',
  },
  earnMethodProgressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 4,
  },
  earnMethodProgressInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  earnMethodProgressText: {
    fontSize: 12,
    color: colors.textLight,
  },
  earnMethodProgressRockets: {
    fontSize: 12,
    color: colors.textLight,
  },
  cityBattleStatus: {
    marginTop: 8,
  },
  cityBattleTeams: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  cityBattleTeam: {
    flex: 1,
  },
  cityBattleTeamName: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 4,
  },
  cityBattleRockets: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  cityBattleRocketsText: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '600',
  },
  cityBattleVs: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.textLight,
    marginHorizontal: 12,
  },
  cityBattleTimeRemaining: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  cityBattleTimeText: {
    fontSize: 12,
    color: colors.textLight,
  },
  competitionStatus: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  competitionRank: {
    alignItems: 'center',
  },
  competitionRankBadge: {
    backgroundColor: colors.cardLight,
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 12,
    marginBottom: 4,
  },
  competitionRankText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.text,
  },
  competitionRankLabel: {
    fontSize: 12,
    color: colors.textLight,
  },
  competitionTopThree: {
    flexDirection: 'row',
    gap: 8,
  },
  competitionTopUser: {
    position: 'relative',
  },
  competitionTopUserAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  competitionTopUserRank: {
    position: 'absolute',
    bottom: -4,
    right: -4,
    width: 16,
    height: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.background,
  },
  rankGold: {
    backgroundColor: '#FFD700',
  },
  rankSilver: {
    backgroundColor: '#C0C0C0',
  },
  rankBronze: {
    backgroundColor: '#CD7F32',
  },
  competitionTopUserRankText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.background,
  },
  competitionTimeRemaining: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  competitionTimeText: {
    fontSize: 12,
    color: colors.textLight,
  },
  referralCodeContainer: {
    marginTop: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  referralCodeLabel: {
    fontSize: 14,
    color: colors.textLight,
  },
  referralCode: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.cardLight,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  referralCodeText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  referralShareButton: {
    backgroundColor: colors.primary,
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  // Competition Tab Styles
  competitionHeader: {
    padding: 16,
    backgroundColor: colors.card,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  competitionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  countdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  countdownText: {
    fontSize: 14,
    color: colors.textLight,
    fontWeight: '500',
  },
  topSellers: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'flex-end',
    padding: 16,
    backgroundColor: colors.background,
  },
  topSellerCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  firstPlace: {
    height: 220,
    width: 140,
    zIndex: 3,
    marginHorizontal: -8,
    borderWidth: 2,
    borderColor: '#FFD700',
  },
  secondPlace: {
    height: 180,
    width: 120,
    zIndex: 2,
  },
  thirdPlace: {
    height: 180,
    width: 120,
    zIndex: 1,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  badge: {
    position: 'absolute',
    bottom: -5,
    right: -5,
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.card,
  },
  badgeGold: {
    backgroundColor: '#FFD700',
  },
  badgeSilver: {
    backgroundColor: '#C0C0C0',
  },
  badgeBronze: {
    backgroundColor: '#CD7F32',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.background,
  },
  sellerName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  firstPlaceName: {
    fontSize: 16,
  },
  rocketCountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  sellerAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  firstPlaceAmount: {
    fontSize: 20,
  },
  prizeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.cardLight,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
    gap: 6,
  },
  prizeText: {
    fontSize: 12,
    color: colors.text,
    fontWeight: '500',
  },
  firstPlacePrizes: {
    gap: 8,
  },
  firstPrizeContainer: {
    backgroundColor: 'rgba(255, 215, 0, 0.2)',
  },
  firstPrizeText: {
    fontWeight: '600',
  },
  listContainer: {
    padding: 16,
  },
  listTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  rank: {
    width: 40,
    fontSize: 14,
    fontWeight: '600',
    color: colors.textLight,
  },
  userRank: {
    color: colors.primary,
  },
  listAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  userAvatar: {
    borderWidth: 2,
    borderColor: colors.primary,
  },
  sellerInfo: {
    flex: 1,
  },
  listName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 4,
  },
  userName: {
    color: colors.primary,
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  cityText: {
    fontSize: 12,
    color: colors.textLight,
  },
  rocketCountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  amount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
  },
  rankDivider: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  rankDividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  rankDividerText: {
    paddingHorizontal: 16,
    color: colors.textLight,
    fontSize: 16,
  },
  // Challenges Tab Styles
  challengesContainer: {
    padding: 16,
  },
  pastChallengesContainer: {
    marginTop: 24,
  },
  pastChallengesTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  wheelModalContainer: {
    width: '90%',
    maxWidth: 360,
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 10,
  },
  referralModalContainer: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: colors.card,
    borderRadius: 20,
    padding: 24,
    maxHeight: '80%',
  },
  referralModalHeader: {
    alignItems: 'center',
    marginBottom: 24,
  },
  referralIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.cardLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  referralModalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
    textAlign: 'center',
  },
  referralModalSubtitle: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    marginBottom: 8,
  },
  referralCodeBox: {
    backgroundColor: colors.cardLight,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 24,
  },
  referralStepsContainer: {
    marginBottom: 24,
  },
  referralStepsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  referralStep: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  referralStepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  referralStepNumberText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.background,
  },
  referralStepText: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
  },
  shareReferralButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  shareReferralButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.background,
  },
  rocketsInfoModalContainer: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: colors.card,
    borderRadius: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.text,
  },
  rocketsInfoContent: {
    padding: 20,
  },
  rocketsInfoSection: {
    marginBottom: 24,
  },
  rocketsInfoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 12,
  },
  rocketsInfoText: {
    fontSize: 16,
    color: colors.text,
    marginBottom: 16,
    lineHeight: 24,
  },
  rocketsInfoItem: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  rocketsInfoBullet: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.cardLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  rocketsInfoItemText: {
    flex: 1,
    fontSize: 16,
    color: colors.text,
    lineHeight: 24,
  },
  rocketsInfoBold: {
    fontWeight: 'bold',
  },
  referFriendsButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  referFriendsButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.background,
  },
  storeVisitButton: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  storeVisitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.background,
  },
  redeemModalContainer: {
    width: '90%',
    maxWidth: 400,
    backgroundColor: colors.card,
    borderRadius: 20,
    maxHeight: '80%',
  },
  redeemModalContent: {
    padding: 20,
  },
  redeemRocketsBalance: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.cardLight,
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    gap: 12,
  },
  redeemRocketsBalanceText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
  },
  redeemOptionsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 16,
  },
  redeemOption: {
    flexDirection: 'row',
    backgroundColor: colors.cardLight,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  redeemOptionIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  redeemOptionContent: {
    flex: 1,
  },
  redeemOptionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 4,
  },
  redeemOptionDescription: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 8,
  },
  redeemOptionCost: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  redeemOptionCostText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.text,
  },
  redeemNote: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 16,
    marginBottom: 24,
    textAlign: 'center',
    lineHeight: 20,
  },
});