import FontAwesome from "@expo/vector-icons/FontAwesome";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import { Platform } from "react-native";
import { ErrorBoundary } from "./error-boundary";
import { useAuthStore } from "@/store/auth-store";

export const unstable_settings = {
  initialRouteName: "(tabs)",
};

SplashScreen.preventAutoHideAsync();

// Auth check component
function AuthCheck({ children }: { children: React.ReactNode }) {
  const { user, setUser } = useAuthStore();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    // Hide splash screen after auth check
    SplashScreen.hideAsync();
  }, []);

  useEffect(() => {
    const inAuthGroup = segments[0] === 'auth';
    
    if (!user && !inAuthGroup) {
      // If not logged in and not in auth group, redirect to login
      router.replace('/auth/login');
    } else if (user && inAuthGroup) {
      // If logged in and in auth group, redirect to home
      router.replace('/(tabs)');
    }
  }, [user, segments]);

  return <>{children}</>;
}

export default function RootLayout() {
  return (
    <ErrorBoundary>
      <AuthCheck>
        <RootLayoutNav />
      </AuthCheck>
    </ErrorBoundary>
  );
}

function RootLayoutNav() {
  return (
    <Stack>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="modal" options={{ presentation: "modal" }} />
      <Stack.Screen name="auth" options={{ headerShown: false }} />
    </Stack>
  );
}