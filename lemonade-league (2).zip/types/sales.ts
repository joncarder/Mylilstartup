export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  totalRockets: number;
  dailyRockets?: number;
  city: string;
  rank: number;
  badges: string[];
}