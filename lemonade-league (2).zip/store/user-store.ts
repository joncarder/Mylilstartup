import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getLevelForRockets, getLevelProgress } from '@/constants/levels';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  city?: string;
  state?: string;
  rockets: number;
  rocketsSpent: number;
  totalSales: number;
  dailySales: number;
  badges: string[];
  goldenTickets: number;
  referralCode: string;
  referrals: number;
  joinDate: string;
  createdAt: string;
  updatedAt: string;
}

interface Sale {
  id: string;
  amount: number;
  customer: string;
  location: string;
  date: string;
  rocketsEarned: number;
}

interface UserState {
  profile: UserProfile;
  sales: Sale[];
  isLoading: boolean;
  error: string | null;
  // Actions
  fetchProfile: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  addRockets: (amount: number, source: string) => void;
  spendRockets: (amount: number, reason: string) => void;
  addBadge: (badgeId: string) => void;
  addGoldenTicket: () => void;
  useGoldenTicket: () => void;
  addReferral: () => void;
  // Helpers
  getLevelInfo: () => { level: number; title: string; progress: number };
  getRocketsToNextLevel: () => number;
  clearError: () => void;
}

// Sample sales data
const sampleSales: Sale[] = [
  {
    id: 'sale_1',
    amount: 125.99,
    customer: 'Jane Smith',
    location: 'Downtown Store',
    date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
    rocketsEarned: 63
  },
  {
    id: 'sale_2',
    amount: 49.99,
    customer: 'Bob Johnson',
    location: 'Online',
    date: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
    rocketsEarned: 25
  },
  {
    id: 'sale_3',
    amount: 199.99,
    customer: 'Alice Brown',
    location: 'Mall Kiosk',
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
    rocketsEarned: 100
  },
];

// Default profile for new users
const defaultProfile: UserProfile = {
  id: 'user_1',
  name: 'John Doe',
  email: 'john.doe@example.com',
  phone: '+1 (555) 123-4567',
  avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=120&h=120&q=80',
  city: 'San Diego',
  state: 'CA',
  rockets: 1375,
  rocketsSpent: 250,
  totalSales: 12500,
  dailySales: 750,
  badges: ['first_sale', 'level_5', 'weekend_warrior'],
  goldenTickets: 1,
  referralCode: 'JOHNDOE25',
  referrals: 3,
  joinDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(), // 90 days ago
  createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString(),
  updatedAt: new Date().toISOString(),
};

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      profile: defaultProfile,
      sales: sampleSales,
      isLoading: false,
      error: null,
      
      // Fetch user profile from API
      fetchProfile: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // In a real app, this would call an API
          // const profile = await userApi.getProfile();
          
          // For now, just use the default profile
          set({ profile: defaultProfile, isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch profile',
            isLoading: false
          });
        }
      },
      
      // Update user profile
      updateProfile: async (data: Partial<UserProfile>) => {
        set({ isLoading: true, error: null });
        
        try {
          // In a real app, this would call an API
          // const updatedProfile = await userApi.updateProfile(data);
          
          // For now, just update the profile locally
          set(state => ({
            profile: {
              ...state.profile,
              ...data,
              updatedAt: new Date().toISOString()
            },
            isLoading: false
          }));
        } catch (error: any) {
          set({
            error: error.message || 'Failed to update profile',
            isLoading: false
          });
        }
      },
      
      // Add rockets to user's account
      addRockets: (amount: number, source: string) => {
        if (amount <= 0) return;
        
        set(state => ({
          profile: {
            ...state.profile,
            rockets: state.profile.rockets + amount,
            updatedAt: new Date().toISOString()
          }
        }));
        
        // In a real app, we would also log this transaction to the backend
        console.log(`Added ${amount} rockets from ${source}`);
      },
      
      // Spend rockets from user's account
      spendRockets: (amount: number, reason: string) => {
        const { profile } = get();
        
        if (amount <= 0) return;
        if (profile.rockets < amount) {
          set({ error: 'Not enough rockets' });
          return;
        }
        
        set(state => ({
          profile: {
            ...state.profile,
            rockets: state.profile.rockets - amount,
            rocketsSpent: (state.profile.rocketsSpent || 0) + amount,
            updatedAt: new Date().toISOString()
          }
        }));
        
        // In a real app, we would also log this transaction to the backend
        console.log(`Spent ${amount} rockets for ${reason}`);
      },
      
      // Add a badge to user's collection
      addBadge: (badgeId: string) => {
        const { profile } = get();
        
        // Check if user already has this badge
        if (profile.badges.includes(badgeId)) return;
        
        set(state => ({
          profile: {
            ...state.profile,
            badges: [...state.profile.badges, badgeId],
            updatedAt: new Date().toISOString()
          }
        }));
      },
      
      // Add a golden ticket to user's account
      addGoldenTicket: () => {
        set(state => ({
          profile: {
            ...state.profile,
            goldenTickets: state.profile.goldenTickets + 1,
            updatedAt: new Date().toISOString()
          }
        }));
      },
      
      // Use a golden ticket
      useGoldenTicket: () => {
        const { profile } = get();
        
        if (profile.goldenTickets <= 0) {
          set({ error: 'No golden tickets available' });
          return;
        }
        
        set(state => ({
          profile: {
            ...state.profile,
            goldenTickets: state.profile.goldenTickets - 1,
            updatedAt: new Date().toISOString()
          }
        }));
      },
      
      // Add a referral
      addReferral: () => {
        set(state => ({
          profile: {
            ...state.profile,
            referrals: state.profile.referrals + 1,
            updatedAt: new Date().toISOString()
          }
        }));
        
        // Also add rockets for the referral
        get().addRockets(500, 'referral');
      },
      
      // Get user's level info
      getLevelInfo: () => {
        const { rockets } = get().profile;
        const level = getLevelForRockets(rockets);
        const progress = getLevelProgress(rockets);
        
        // Level titles
        const titles = [
          'Rookie',
          'Apprentice',
          'Associate',
          'Specialist',
          'Expert',
          'Master',
          'Grandmaster',
          'Legend',
          'Titan',
          'Cosmic'
        ];
        
        const title = titles[Math.min(level - 1, titles.length - 1)];
        
        return { level, title, progress };
      },
      
      // Get rockets needed to reach next level
      getRocketsToNextLevel: () => {
        const { rockets } = get().profile;
        const currentLevel = getLevelForRockets(rockets);
        const nextLevelRockets = currentLevel * 500;
        return Math.max(0, nextLevelRockets - rockets);
      },
      
      // Clear error
      clearError: () => set({ error: null })
    }),
    {
      name: 'user-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);