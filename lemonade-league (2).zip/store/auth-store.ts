import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useUserStore } from './user-store';

// Define types for our auth user
export interface AuthUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

// Define the auth state and actions
interface AuthState {
  user: AuthUser | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  signUp: (email: string, password: string, displayName: string) => Promise<any>;
  signIn: (email: string, password: string) => Promise<any>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateUserProfile: (displayName?: string, photoURL?: string) => Promise<void>;
  setUser: (user: any | null) => void;
  clearError: () => void;
}

// Mock auth functions for demo purposes
const mockAuth = {
  createUserWithEmailAndPassword: async (email: string, password: string) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Generate a random UID
    const uid = Math.random().toString(36).substring(2, 15);
    
    return {
      user: {
        uid,
        email,
        displayName: null,
        photoURL: null
      }
    };
  },
  
  signInWithEmailAndPassword: async (email: string, password: string) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Generate a random UID
    const uid = Math.random().toString(36).substring(2, 15);
    
    return {
      user: {
        uid,
        email,
        displayName: email.split('@')[0], // Use part of email as display name
        photoURL: null
      }
    };
  },
  
  signOut: async () => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return true;
  },
  
  sendPasswordResetEmail: async (email: string) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    return true;
  },
  
  updateProfile: async (user: any, data: any) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    return true;
  }
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isLoading: false,
      error: null,
      
      // Sign up with email and password
      signUp: async (email, password, displayName) => {
        set({ isLoading: true, error: null });
        try {
          const userCredential = await mockAuth.createUserWithEmailAndPassword(email, password);
          
          // Update profile with display name
          if (userCredential.user) {
            await mockAuth.updateProfile(userCredential.user, { displayName });
            
            // Set user in store
            set({
              user: {
                uid: userCredential.user.uid,
                email: userCredential.user.email,
                displayName: displayName,
                photoURL: userCredential.user.photoURL
              },
              isLoading: false
            });
            
            // Initialize user profile in user store
            useUserStore.getState().initializeUserProfile(userCredential.user.uid, displayName);
          }
          
          return userCredential;
        } catch (error: any) {
          set({ 
            error: error.message || 'Failed to sign up', 
            isLoading: false 
          });
          throw error;
        }
      },
      
      // Sign in with email and password
      signIn: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const userCredential = await mockAuth.signInWithEmailAndPassword(email, password);
          
          // Set user in store
          if (userCredential.user) {
            set({
              user: {
                uid: userCredential.user.uid,
                email: userCredential.user.email,
                displayName: userCredential.user.displayName,
                photoURL: userCredential.user.photoURL
              },
              isLoading: false
            });
          }
          
          return userCredential;
        } catch (error: any) {
          set({ 
            error: error.message || 'Failed to sign in', 
            isLoading: false 
          });
          throw error;
        }
      },
      
      // Sign out
      logout: async () => {
        set({ isLoading: true, error: null });
        try {
          await mockAuth.signOut();
          set({ user: null, isLoading: false });
        } catch (error: any) {
          set({ 
            error: error.message || 'Failed to sign out', 
            isLoading: false 
          });
          throw error;
        }
      },
      
      // Reset password
      resetPassword: async (email) => {
        set({ isLoading: true, error: null });
        try {
          await mockAuth.sendPasswordResetEmail(email);
          set({ isLoading: false });
        } catch (error: any) {
          set({ 
            error: error.message || 'Failed to send password reset email', 
            isLoading: false 
          });
          throw error;
        }
      },
      
      // Update user profile
      updateUserProfile: async (displayName, photoURL) => {
        set({ isLoading: true, error: null });
        try {
          const user = get().user;
          if (user) {
            const updateData: { displayName?: string; photoURL?: string } = {};
            
            if (displayName) updateData.displayName = displayName;
            if (photoURL) updateData.photoURL = photoURL;
            
            await mockAuth.updateProfile(user, updateData);
            
            // Update user in store
            set({
              user: {
                ...user,
                displayName: displayName || user.displayName,
                photoURL: photoURL || user.photoURL
              },
              isLoading: false
            });
          }
        } catch (error: any) {
          set({ 
            error: error.message || 'Failed to update profile', 
            isLoading: false 
          });
          throw error;
        }
      },
      
      // Set user (used for auth state changes)
      setUser: (firebaseUser) => {
        if (firebaseUser) {
          set({
            user: {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: firebaseUser.displayName,
              photoURL: firebaseUser.photoURL
            }
          });
        } else {
          set({ user: null });
        }
      },
      
      // Clear error
      clearError: () => set({ error: null })
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ user: state.user }) // Only persist user data
    }
  )
);