import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Reward, wheelRewards } from '@/constants/rewards';
import { rewardsApi } from '@/lib/express-api';

interface RewardHistory {
  id: string;
  rewardId: string;
  rewardName: string;
  rewardType: string;
  rewardValue: number | string;
  date: string;
  source: 'wheel' | 'sale' | 'challenge' | 'competition' | 'level' | 'referral';
}

interface RewardsState {
  history: RewardHistory[];
  wheelSpinsAvailable: number;
  isLoading: boolean;
  error: string | null;
  // Actions
  spinWheel: () => Promise<Reward>;
  addRewardToHistory: (reward: Reward, source: RewardHistory['source']) => void;
  addWheelSpin: () => Promise<void>;
  getRecentRewards: (limit?: number) => RewardHistory[];
  fetchRewards: () => Promise<void>;
  clearError: () => void;
}

export const useRewardsStore = create<RewardsState>()(
  persist(
    (set, get) => ({
      history: [],
      wheelSpinsAvailable: 3, // Start with 3 spins
      isLoading: false,
      error: null,
      
      // Fetch rewards from API
      fetchRewards: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Get reward history
          const historyData = await rewardsApi.getHistory();
          
          set({
            history: historyData.history,
            wheelSpinsAvailable: historyData.wheelSpinsAvailable || 3,
            isLoading: false
          });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch rewards',
            isLoading: false
          });
        }
      },
      
      // Spin the wheel to get a random reward
      spinWheel: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Check if spins are available
          if (get().wheelSpinsAvailable <= 0) {
            throw new Error('No wheel spins available');
          }
          
          // Call API to spin wheel
          const response = await rewardsApi.spinWheel();
          const reward = response.reward;
          
          // Update local state
          set(state => ({
            wheelSpinsAvailable: state.wheelSpinsAvailable - 1,
            isLoading: false
          }));
          
          // Add to history
          get().addRewardToHistory(reward, 'wheel');
          
          return reward;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to spin wheel',
            isLoading: false
          });
          
          // For development/demo, simulate wheel spin if API fails
          if (process.env.NODE_ENV === 'development') {
            // Reduce available spins
            set(state => ({
              wheelSpinsAvailable: state.wheelSpinsAvailable - 1
            }));
            
            // Determine reward based on probability
            const random = Math.random() * 100;
            let cumulativeProbability = 0;
            
            for (const reward of wheelRewards) {
              cumulativeProbability += reward.chance;
              if (random <= cumulativeProbability) {
                // Add to history
                get().addRewardToHistory(reward, 'wheel');
                return reward;
              }
            }
            
            // Fallback to first reward (should never happen if probabilities sum to 100)
            const fallbackReward = wheelRewards[0];
            get().addRewardToHistory(fallbackReward, 'wheel');
            return fallbackReward;
          }
          
          throw error;
        }
      },
      
      // Add a reward to history
      addRewardToHistory: (reward, source) => {
        const rewardHistory: RewardHistory = {
          id: `reward_${Date.now()}`,
          rewardId: reward.id,
          rewardName: reward.name,
          rewardType: reward.type,
          rewardValue: reward.value,
          date: new Date().toISOString(),
          source
        };
        
        set(state => ({
          history: [rewardHistory, ...state.history]
        }));
      },
      
      // Add a wheel spin
      addWheelSpin: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Call API to add wheel spin
          await rewardsApi.addWheelSpin();
          
          // Update local state
          set(state => ({
            wheelSpinsAvailable: state.wheelSpinsAvailable + 1,
            isLoading: false
          }));
        } catch (error: any) {
          set({
            error: error.message || 'Failed to add wheel spin',
            isLoading: false
          });
          
          // For development/demo, update local state if API fails
          if (process.env.NODE_ENV === 'development') {
            set(state => ({
              wheelSpinsAvailable: state.wheelSpinsAvailable + 1
            }));
          } else {
            throw error;
          }
        }
      },
      
      // Get recent rewards
      getRecentRewards: (limit = 10) => {
        return get().history.slice(0, limit);
      },
      
      // Clear error
      clearError: () => set({ error: null })
    }),
    {
      name: 'rewards-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);