import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { smileApi } from '@/lib/smile-api';
import { useUserStore } from './user-store';

export interface SmileReward {
  id: string;
  name: string;
  description: string;
  pointsCost: number;
  isAvailable: boolean;
}

export interface SmileActivity {
  id: string;
  type: 'points_earned' | 'reward_redeemed' | 'purchase' | 'referral';
  points: number;
  description: string;
  createdAt: string;
}

interface SmileRewardsState {
  isInitialized: boolean;
  pointsBalance: number;
  vipTier: string | null;
  availableRewards: SmileReward[];
  activityHistory: SmileActivity[];
  referralCode: string | null;
  referralUrl: string | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  initializeSmileCustomer: (email: string, firstName?: string, lastName?: string) => Promise<void>;
  fetchCustomerProfile: () => Promise<void>;
  fetchPointsBalance: () => Promise<number>;
  fetchAvailableRewards: () => Promise<SmileReward[]>;
  fetchActivityHistory: () => Promise<SmileActivity[]>;
  fetchReferralCode: () => Promise<{ code: string; url: string }>;
  redeemReward: (rewardId: string) => Promise<void>;
  awardPoints: (points: number, reason: string) => Promise<void>;
  recordPurchase: (orderId: string, amount: number) => Promise<void>;
  applyReferral: (referralCode: string) => Promise<void>;
  syncWithAppRewards: () => Promise<void>;
  clearError: () => void;
}

export const useSmileRewardsStore = create<SmileRewardsState>()(
  persist(
    (set, get) => ({
      isInitialized: false,
      pointsBalance: 0,
      vipTier: null,
      availableRewards: [],
      activityHistory: [],
      referralCode: null,
      referralUrl: null,
      isLoading: false,
      error: null,
      
      // Initialize a customer with Smile.io
      initializeSmileCustomer: async (email, firstName, lastName) => {
        set({ isLoading: true, error: null });
        
        try {
          const customer = await smileApi.initializeCustomer(email, firstName, lastName);
          
          set({
            isInitialized: true,
            pointsBalance: customer.points_balance || 0,
            vipTier: customer.vip_tier || null,
            isLoading: false
          });
          
          // Fetch additional data after initialization
          get().fetchAvailableRewards();
          get().fetchActivityHistory();
          get().fetchReferralCode();
        } catch (error: any) {
          set({
            error: error.message || 'Failed to initialize Smile customer',
            isLoading: false
          });
        }
      },
      
      // Fetch customer profile from Smile.io
      fetchCustomerProfile: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const profile = await smileApi.getCustomerProfile();
          
          set({
            pointsBalance: profile.points_balance || 0,
            vipTier: profile.vip_tier || null,
            isLoading: false
          });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch Smile customer profile',
            isLoading: false
          });
        }
      },
      
      // Fetch points balance
      fetchPointsBalance: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const pointsBalance = await smileApi.getPointsBalance();
          
          set({
            pointsBalance,
            isLoading: false
          });
          
          return pointsBalance;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch points balance',
            isLoading: false
          });
          return 0;
        }
      },
      
      // Fetch available rewards
      fetchAvailableRewards: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const rewardsData = await smileApi.getCustomerRewards();
          
          const rewards = rewardsData.map((reward: any) => ({
            id: reward.id,
            name: reward.name,
            description: reward.description,
            pointsCost: reward.points_cost,
            isAvailable: reward.is_available
          }));
          
          set({
            availableRewards: rewards,
            isLoading: false
          });
          
          return rewards;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch available rewards',
            isLoading: false
          });
          return [];
        }
      },
      
      // Fetch activity history
      fetchActivityHistory: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const activitiesData = await smileApi.getActivityHistory();
          
          const activities = activitiesData.map((activity: any) => ({
            id: activity.id,
            type: activity.type,
            points: activity.points,
            description: activity.description,
            createdAt: activity.created_at
          }));
          
          set({
            activityHistory: activities,
            isLoading: false
          });
          
          return activities;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch activity history',
            isLoading: false
          });
          return [];
        }
      },
      
      // Fetch referral code
      fetchReferralCode: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const referral = await smileApi.getReferralCode();
          
          set({
            referralCode: referral.code,
            referralUrl: referral.url,
            isLoading: false
          });
          
          return { code: referral.code, url: referral.url };
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch referral code',
            isLoading: false
          });
          return { code: '', url: '' };
        }
      },
      
      // Redeem a reward
      redeemReward: async (rewardId) => {
        set({ isLoading: true, error: null });
        
        try {
          const redemption = await smileApi.redeemReward(rewardId);
          
          // Update points balance after redemption
          await get().fetchPointsBalance();
          
          // Update activity history
          await get().fetchActivityHistory();
          
          set({ isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to redeem reward',
            isLoading: false
          });
        }
      },
      
      // Award points
      awardPoints: async (points, reason) => {
        set({ isLoading: true, error: null });
        
        try {
          await smileApi.awardPoints(points, reason);
          
          // Update points balance
          await get().fetchPointsBalance();
          
          // Update activity history
          await get().fetchActivityHistory();
          
          set({ isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to award points',
            isLoading: false
          });
        }
      },
      
      // Record a purchase
      recordPurchase: async (orderId, amount) => {
        set({ isLoading: true, error: null });
        
        try {
          await smileApi.recordPurchase(orderId, amount);
          
          // Update points balance
          await get().fetchPointsBalance();
          
          // Update activity history
          await get().fetchActivityHistory();
          
          set({ isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to record purchase',
            isLoading: false
          });
        }
      },
      
      // Apply a referral code
      applyReferral: async (referralCode) => {
        set({ isLoading: true, error: null });
        
        try {
          await smileApi.applyReferral(referralCode);
          
          // Update points balance
          await get().fetchPointsBalance();
          
          // Update activity history
          await get().fetchActivityHistory();
          
          set({ isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to apply referral code',
            isLoading: false
          });
        }
      },
      
      // Sync with app rewards (rockets)
      syncWithAppRewards: async () => {
        set({ isLoading: true, error: null });
        
        try {
          const { profile } = useUserStore.getState();
          const rockets = profile.rockets;
          
          await smileApi.syncWithAppRewards(rockets);
          
          // Update points balance
          await get().fetchPointsBalance();
          
          // Update activity history
          await get().fetchActivityHistory();
          
          set({ isLoading: false });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to sync with app rewards',
            isLoading: false
          });
        }
      },
      
      // Clear error
      clearError: () => set({ error: null })
    }),
    {
      name: 'smile-rewards-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);