import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Challenge, ChallengeResult, MAX_CHALLENGE_WAGER, sampleChallenges } from '@/constants/challenges';
import { challengesApi } from '@/lib/express-api';

interface ChallengesState {
  challenges: Challenge[];
  results: ChallengeResult[];
  isLoading: boolean;
  error: string | null;
  // Actions
  createChallenge: (opponentId: string, opponentName: string, wagerAmount: number, date: Date) => Promise<Challenge>;
  acceptChallenge: (challengeId: string) => Promise<void>;
  declineChallenge: (challengeId: string) => Promise<void>;
  completeChallenge: (challengeId: string, challengerSales: number, opponentSales: number) => Promise<ChallengeResult>;
  getPendingChallenges: () => Challenge[];
  getActiveChallenges: () => Challenge[];
  getCompletedChallenges: () => Challenge[];
  fetchChallenges: () => Promise<void>;
  clearError: () => void;
}

export const useChallengesStore = create<ChallengesState>()(
  persist(
    (set, get) => ({
      challenges: sampleChallenges,
      results: [],
      isLoading: false,
      error: null,
      
      // Fetch challenges from API
      fetchChallenges: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Get challenges
          const challengesData = await challengesApi.getChallenges();
          
          set({
            challenges: challengesData.challenges,
            results: challengesData.results || [],
            isLoading: false
          });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch challenges',
            isLoading: false
          });
        }
      },
      
      // Create a new challenge
      createChallenge: async (opponentId, opponentName, wagerAmount, date) => {
        set({ isLoading: true, error: null });
        
        try {
          // Ensure wager amount doesn't exceed maximum
          const validWager = Math.min(wagerAmount, MAX_CHALLENGE_WAGER);
          
          // Call API to create challenge
          const challengeData = {
            opponentId,
            opponentName,
            wagerAmount: validWager,
            startDate: date.toISOString(),
            endDate: new Date(date.getTime() + 12 * 60 * 60 * 1000).toISOString() // 12 hours after start
          };
          
          const response = await challengesApi.createChallenge(challengeData);
          const challenge = response.challenge;
          
          // Update local state
          set(state => ({
            challenges: [challenge, ...state.challenges],
            isLoading: false
          }));
          
          return challenge;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to create challenge',
            isLoading: false
          });
          
          // For development/demo, create a local challenge if API fails
          if (process.env.NODE_ENV === 'development') {
            const validWager = Math.min(wagerAmount, MAX_CHALLENGE_WAGER);
            
            const challenge: Challenge = {
              id: `challenge_${Date.now()}`,
              challengerId: 'user_1', // Current user
              challengerName: 'You',
              opponentId,
              opponentName,
              wagerAmount: validWager,
              startDate: date.toISOString(),
              endDate: new Date(date.getTime() + 12 * 60 * 60 * 1000).toISOString(), // 12 hours after start
              status: 'pending',
              createdAt: new Date().toISOString()
            };
            
            set(state => ({
              challenges: [challenge, ...state.challenges]
            }));
            
            return challenge;
          }
          
          throw error;
        }
      },
      
      // Accept a challenge
      acceptChallenge: async (challengeId) => {
        set({ isLoading: true, error: null });
        
        try {
          // Call API to accept challenge
          await challengesApi.acceptChallenge(challengeId);
          
          // Update local state
          set(state => ({
            challenges: state.challenges.map(challenge => 
              challenge.id === challengeId 
                ? { ...challenge, status: 'active' } 
                : challenge
            ),
            isLoading: false
          }));
        } catch (error: any) {
          set({
            error: error.message || 'Failed to accept challenge',
            isLoading: false
          });
          
          // For development/demo, update local state if API fails
          if (process.env.NODE_ENV === 'development') {
            set(state => ({
              challenges: state.challenges.map(challenge => 
                challenge.id === challengeId 
                  ? { ...challenge, status: 'active' } 
                  : challenge
              )
            }));
          } else {
            throw error;
          }
        }
      },
      
      // Decline a challenge
      declineChallenge: async (challengeId) => {
        set({ isLoading: true, error: null });
        
        try {
          // Call API to decline challenge
          await challengesApi.declineChallenge(challengeId);
          
          // Update local state
          set(state => ({
            challenges: state.challenges.map(challenge => 
              challenge.id === challengeId 
                ? { ...challenge, status: 'cancelled' } 
                : challenge
            ),
            isLoading: false
          }));
        } catch (error: any) {
          set({
            error: error.message || 'Failed to decline challenge',
            isLoading: false
          });
          
          // For development/demo, update local state if API fails
          if (process.env.NODE_ENV === 'development') {
            set(state => ({
              challenges: state.challenges.map(challenge => 
                challenge.id === challengeId 
                  ? { ...challenge, status: 'cancelled' } 
                  : challenge
              )
            }));
          } else {
            throw error;
          }
        }
      },
      
      // Complete a challenge
      completeChallenge: async (challengeId, challengerSales, opponentSales) => {
        set({ isLoading: true, error: null });
        
        try {
          // Call API to complete challenge
          const response = await challengesApi.completeChallenge(
            challengeId, 
            challengerSales, 
            opponentSales
          );
          
          const result = response.result;
          
          // Update local state
          set(state => ({
            challenges: state.challenges.map(c => 
              c.id === challengeId 
                ? { 
                    ...c, 
                    status: 'completed',
                    challengerSales,
                    opponentSales,
                    winnerId: result.winnerId
                  } 
                : c
            ),
            results: [result, ...state.results],
            isLoading: false
          }));
          
          return result;
        } catch (error: any) {
          set({
            error: error.message || 'Failed to complete challenge',
            isLoading: false
          });
          
          // For development/demo, update local state if API fails
          if (process.env.NODE_ENV === 'development') {
            const challenge = get().challenges.find(c => c.id === challengeId);
            
            if (!challenge) {
              throw new Error(`Challenge with ID ${challengeId} not found`);
            }
            
            // Determine winner
            const winnerId = challengerSales > opponentSales 
              ? challenge.challengerId 
              : challenge.opponentId;
            
            const winnerName = winnerId === challenge.challengerId 
              ? challenge.challengerName 
              : challenge.opponentName;
            
            // Calculate total rockets won (both wagers)
            const totalRocketsWon = challenge.wagerAmount * 2;
            
            // Create result
            const result: ChallengeResult = {
              challengeId,
              winnerId,
              winnerName,
              totalRocketsWon,
              salesDifference: Math.abs(challengerSales - opponentSales)
            };
            
            // Update challenge
            set(state => ({
              challenges: state.challenges.map(c => 
                c.id === challengeId 
                  ? { 
                      ...c, 
                      status: 'completed',
                      challengerSales,
                      opponentSales,
                      winnerId
                    } 
                  : c
              ),
              results: [result, ...state.results]
            }));
            
            return result;
          }
          
          throw error;
        }
      },
      
      // Get pending challenges
      getPendingChallenges: () => {
        return get().challenges.filter(
          challenge => challenge.status === 'pending' && 
          (challenge.challengerId === 'user_1' || challenge.opponentId === 'user_1')
        );
      },
      
      // Get active challenges
      getActiveChallenges: () => {
        return get().challenges.filter(
          challenge => challenge.status === 'active' && 
          (challenge.challengerId === 'user_1' || challenge.opponentId === 'user_1')
        );
      },
      
      // Get completed challenges
      getCompletedChallenges: () => {
        return get().challenges.filter(
          challenge => challenge.status === 'completed' && 
          (challenge.challengerId === 'user_1' || challenge.opponentId === 'user_1')
        );
      },
      
      // Clear error
      clearError: () => set({ error: null })
    }),
    {
      name: 'challenges-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);