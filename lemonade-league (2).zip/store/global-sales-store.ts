import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GlobalSale } from '@/components/GlobalSaleItem';
import { salesApi } from '@/lib/express-api';

interface GlobalSalesState {
  sales: GlobalSale[];
  isLoading: boolean;
  error: string | null;
  filter: 'nationwide' | 'city';
  highFivedSales: string[]; // IDs of sales the user has high-fived
  
  // Actions
  fetchGlobalSales: () => Promise<void>;
  giveHighFive: (saleId: string, isRemoving?: boolean) => Promise<void>;
  setFilter: (filter: 'nationwide' | 'city') => void;
  clearError: () => void;
}

// Generate sample global sales data
const generateSampleSales = (): GlobalSale[] => {
  const cities = ['San Francisco', 'New York', 'Chicago', 'Los Angeles', 'Miami', 'Seattle', 'Austin', 'Boston'];
  const names = ['Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Jackson', 'Sophia', 'Lucas', 'Isabella', 'Mason'];
  const products = ['Lemonade', 'Cookies', 'Bracelets', 'Slime', 'Keychains', 'Cupcakes', 'Bookmarks', 'Paintings'];
  const avatars = [
    'https://images.unsplash.com/photo-1491013516836-7db643ee125a?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=120&h=120&q=80',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&h=120&q=80'
  ];
  
  const sales: GlobalSale[] = [];
  const now = Date.now();
  
  // Generate 20 sample sales with unique IDs
  for (let i = 0; i < 20; i++) {
    const minutesAgo = Math.floor(Math.random() * 60 * 24); // Random time in the last 24 hours
    const date = new Date(now - (minutesAgo * 60 * 1000));
    const amount = Math.round((Math.random() * 15 + 2) * 100) / 100; // $2.00 - $17.00
    const highFives = Math.floor(Math.random() * 15);
    
    // Ensure unique IDs by using timestamp + random number + index to avoid collisions
    const uniqueId = `global_sale_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`;
    
    sales.push({
      id: uniqueId,
      userId: `user_${i}`,
      userName: names[Math.floor(Math.random() * names.length)],
      userAvatar: avatars[Math.floor(Math.random() * avatars.length)],
      city: cities[Math.floor(Math.random() * cities.length)],
      product: products[Math.floor(Math.random() * products.length)],
      amount,
      date: date.toISOString(),
      highFives,
      hasGivenHighFive: false
    });
  }
  
  // Sort by date, newest first
  return sales.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const useGlobalSalesStore = create<GlobalSalesState>()(
  persist(
    (set, get) => ({
      sales: generateSampleSales(),
      isLoading: false,
      error: null,
      filter: 'nationwide',
      highFivedSales: [],
      
      fetchGlobalSales: async () => {
        set({ isLoading: true, error: null });
        
        try {
          // Call API to get global sales
          const response = await salesApi.getGlobalSales(get().filter);
          
          // Mark sales that the user has already high-fived
          const highFivedSales = get().highFivedSales;
          const salesWithHighFiveStatus = response.sales.map(sale => ({
            ...sale,
            hasGivenHighFive: highFivedSales.includes(sale.id)
          }));
          
          set({
            sales: salesWithHighFiveStatus,
            isLoading: false
          });
        } catch (error: any) {
          set({
            error: error.message || 'Failed to fetch global sales',
            isLoading: false
          });
          
          // For development/demo, use sample data if API fails
          if (process.env.NODE_ENV === 'development') {
            const sampleSales = generateSampleSales();
            const highFivedSales = get().highFivedSales;
            
            set({
              sales: sampleSales.map(sale => ({
                ...sale,
                hasGivenHighFive: highFivedSales.includes(sale.id)
              }))
            });
          }
        }
      },
      
      giveHighFive: async (saleId, isRemoving = false) => {
        try {
          if (isRemoving) {
            // Call API to remove high five
            await salesApi.removeHighFive(saleId);
            
            // Update local state
            set(state => {
              const updatedSales = state.sales.map(sale => {
                if (sale.id === saleId) {
                  return {
                    ...sale,
                    highFives: Math.max(0, sale.highFives - 1), // Ensure we don't go below 0
                    hasGivenHighFive: false
                  };
                }
                return sale;
              });
              
              return {
                sales: updatedSales,
                highFivedSales: state.highFivedSales.filter(id => id !== saleId)
              };
            });
          } else {
            // Check if already high-fived
            if (get().highFivedSales.includes(saleId)) {
              return;
            }
            
            // Call API to give high five
            await salesApi.giveHighFive(saleId);
            
            // Update local state
            set(state => {
              const updatedSales = state.sales.map(sale => {
                if (sale.id === saleId) {
                  return {
                    ...sale,
                    highFives: sale.highFives + 1,
                    hasGivenHighFive: true
                  };
                }
                return sale;
              });
              
              return {
                sales: updatedSales,
                highFivedSales: [...state.highFivedSales, saleId]
              };
            });
          }
        } catch (error: any) {
          set({
            error: error.message || 'Failed to update high five'
          });
          
          // For development/demo, update local state if API fails
          if (process.env.NODE_ENV === 'development') {
            if (isRemoving) {
              set(state => {
                const updatedSales = state.sales.map(sale => {
                  if (sale.id === saleId) {
                    return {
                      ...sale,
                      highFives: Math.max(0, sale.highFives - 1),
                      hasGivenHighFive: false
                    };
                  }
                  return sale;
                });
                
                return {
                  sales: updatedSales,
                  highFivedSales: state.highFivedSales.filter(id => id !== saleId)
                };
              });
            } else {
              set(state => {
                const updatedSales = state.sales.map(sale => {
                  if (sale.id === saleId) {
                    return {
                      ...sale,
                      highFives: sale.highFives + 1,
                      hasGivenHighFive: true
                    };
                  }
                  return sale;
                });
                
                return {
                  sales: updatedSales,
                  highFivedSales: [...state.highFivedSales, saleId]
                };
              });
            }
          }
        }
      },
      
      setFilter: (filter) => {
        set({ filter });
        // Fetch sales with new filter
        get().fetchGlobalSales();
      },
      
      clearError: () => set({ error: null })
    }),
    {
      name: 'global-sales-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        highFivedSales: state.highFivedSales,
        filter: state.filter
      })
    }
  )
);